<?php
// test_smtp.php - Standalone SMTP Diagnostic Tool for Live Hosting
// Upload this to your hosting public_html folder and access: http://yourdomain.com/test_smtp.php
// It will test connections and print exact raw SMTP logs to diagnose issues!

header('Content-Type: text/plain; charset=UTF-8');
require_once 'config.php';

echo "==================================================================\n";
echo "   SIMKEN SMTP GMAIL DIAGNOSTIC TOOL FOR LIVE HOSTING\n";
echo "==================================================================\n\n";

if (!defined('SMTP_USER') || SMTP_USER === '' || !defined('SMTP_PASS') || SMTP_PASS === '') {
    die("❌ ERROR: SMTP_USER atau SMTP_PASS di config.php masih kosong!\nSilakan isi terlebih dahulu.");
}

echo "[+] Target Email Pengirim: " . SMTP_USER . "\n";
echo "[+] Target Email Penerima (Tes): " . SMTP_USER . "\n\n";

$tests = [
    ['host' => 'smtp.gmail.com', 'port' => 587, 'secure' => 'tls'],
    ['host' => 'smtp.gmail.com', 'port' => 465, 'secure' => 'ssl']
];

foreach ($tests as $idx => $test) {
    echo "------------------------------------------------------------------\n";
    echo "TEST #" . ($idx + 1) . ": Menghubungi " . $test['host'] . ":" . $test['port'] . " (" . strtoupper($test['secure']) . ")\n";
    echo "------------------------------------------------------------------\n";
    
    $server = ($test['secure'] === 'ssl') ? "ssl://" . $test['host'] : "tcp://" . $test['host'];
    
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ]);
    
    $t_start = microtime(true);
    $socket = @stream_socket_client($server . ":" . $test['port'], $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $context);
    $t_end = microtime(true);
    
    if (!$socket) {
        echo "❌ KONEKSI GAGAL ke port " . $test['port'] . "!\n";
        echo "   Detail Error: ($errno) $errstr\n";
        echo "   👉 KESIMPULAN: Port " . $test['port'] . " OUTBOUND DIBLOKIR oleh penyedia hosting Anda.\n";
        echo "   👉 SOLUSI: Silakan hubungi CS Hosting Anda dan minta mereka membuka port outbound " . $test['port'] . " ke smtp.gmail.com!\n\n";
        continue;
    }
    
    echo "✅ KONEKSI BERHASIL dalam " . number_format($t_end - $t_start, 3) . " detik!\n";
    
    // SMTP Protocol handshake
    function read_smtp($socket) {
        $data = "";
        while ($line = fgets($socket, 512)) {
            $data .= "S: " . $line;
            if (substr($line, 3, 1) === " ") {
                break;
            }
        }
        return $data;
    }
    
    function send_smtp($socket, $cmd) {
        echo "C: " . $cmd;
        fwrite($socket, $cmd);
        return read_smtp($socket);
    }
    
    // Read greeting
    echo read_smtp($socket);
    
    // EHLO
    echo send_smtp($socket, "EHLO localhost\r\n");
    
    if ($test['secure'] === 'tls') {
        // STARTTLS
        $res = send_smtp($socket, "STARTTLS\r\n");
        echo $res;
        if (strpos($res, '220') !== false) {
            echo "[+] Melakukan TLS Handshake (STARTTLS)...\n";
            $crypto_method = STREAM_CRYPTO_METHOD_TLS_CLIENT;
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
                $crypto_method = STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT;
            }
            if (@stream_socket_enable_crypto($socket, true, $crypto_method)) {
                echo "✅ TLS Handshake Sukses!\n";
                echo send_smtp($socket, "EHLO localhost\r\n");
            } else {
                echo "❌ TLS Handshake Gagal!\n";
                fclose($socket);
                continue;
            }
        } else {
            echo "❌ Gagal memicu STARTTLS!\n";
            fclose($socket);
            continue;
        }
    }
    
    // AUTH LOGIN
    $res = send_smtp($socket, "AUTH LOGIN\r\n");
    echo $res;
    
    // Send Username
    $res = send_smtp($socket, base64_encode(SMTP_USER) . "\r\n");
    echo $res;
    
    // Send Password
    $res = send_smtp($socket, base64_encode(SMTP_PASS) . "\r\n");
    echo $res;
    
    if (strpos($res, '235') !== false) {
        echo "\n🎉 LOGIN SMTP GMAIL SUKSES!!! Kredensial & Jaringan OK!\n";
        echo "[+] Mencoba mengirim email tes...\n";
        
        send_smtp($socket, "MAIL FROM: <" . SMTP_USER . ">\r\n");
        send_smtp($socket, "RCPT TO: <" . SMTP_USER . ">\r\n");
        send_smtp($socket, "DATA\r\n");
        
        $headers = "To: " . SMTP_USER . "\r\n" .
                   "From: SIMKEN Tes <" . SMTP_USER . ">\r\n" .
                   "Subject: Tes Koneksi SMTP Hosting SIMKEN\r\n\r\n" .
                   "Tes Koneksi Berhasil!";
        
        $res_send = send_smtp($socket, $headers . "\r\n.\r\n");
        echo $res_send;
        
        if (strpos($res_send, '250') !== false) {
            echo "🏆 EMAIL TES BERHASIL DIKIRIM! Cek inbox Gmail " . SMTP_USER . " Anda!\n";
        } else {
            echo "❌ Pengiriman DATA gagal!\n";
        }
    } else {
        echo "\n❌ LOGIN GAGAL!\n";
        echo "   👉 KESIMPULAN: Sandi Aplikasi (App Password) salah, atau Google memblokir akses karena IP Hosting mencurigakan.\n";
        echo "   👉 SOLUSI: Periksa inbox Gmail " . SMTP_USER . " Anda di HP/Browser sekarang, cari email 'Security Alert' dari Google, lalu klik 'Ya, itu saya!' untuk mengizinkan login dari hosting ini!\n\n";
    }
    
    send_smtp($socket, "QUIT\r\n");
    fclose($socket);
    break; // Exit loop if one succeeds
}

echo "\n==================================================================\n";
echo "   DIAGNOSTIC SELESAI.\n";
echo "==================================================================\n";
