-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 19 Okt 2026 pada 11.55
-- Versi server: 11.4.13-MariaDB-cll-lve-log
-- Versi PHP: 8.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Basis data: `potensib_simken`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `activities`
--

CREATE TABLE `activities` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) DEFAULT NULL,
  `plate_number` varchar(20) NOT NULL,
  `vehicle_name` varchar(100) NOT NULL,
  `pic_name` varchar(100) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `activities`
--

INSERT INTO `activities` (`id`, `vehicle_id`, `plate_number`, `vehicle_name`, `pic_name`, `action_type`, `description`, `timestamp`) VALUES
(135, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'mahdy', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Beli Minyak Solar', '2026-07-31 08:53:16'),
(136, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'mahdy', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Beli Minyak Solar', '2026-07-31 08:54:11'),
(137, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — BSI Meulaboh', '2026-07-31 09:33:38'),
(138, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: BSI Meulaboh', '2026-07-31 09:41:57'),
(139, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #35 diperbarui oleh peminjam (Sabaruddin)', '2026-07-31 09:43:35'),
(140, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #35 diperbarui oleh peminjam (Sabaruddin)', '2026-07-31 09:43:35'),
(141, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Solat jumat', '2026-07-31 12:06:22'),
(142, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Solat jumat', '2026-07-31 12:07:12'),
(143, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Mohd. Ersan Peruka', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Ke meulaboh', '2026-07-31 14:11:23'),
(144, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Mohd. Ersan Peruka', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh', '2026-07-31 14:42:15'),
(145, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Mohd. Ersan Peruka', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Mohd. Ersan Peruka, KM akhir 3.381, isi BBM Pertalite 23,1 L', '2026-07-31 15:35:19'),
(146, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'mahdy', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh mahdy, KM akhir 107.174, isi BBM Solar 36,8 L', '2026-07-31 15:38:44'),
(147, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 21.597', '2026-08-01 07:43:14'),
(148, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — ke meulaboh, antar pak bowo sakit', '2026-08-01 09:59:44'),
(149, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: ke meulaboh, antar pak bowo sakit', '2026-08-01 11:01:07'),
(150, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Teuku Safril Nizam TM, KM akhir 12.312', '2026-08-01 18:19:22'),
(151, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Abdul Karim', '2026-08-01 18:19:39'),
(152, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #38 (Abdul Karim)', '2026-08-01 18:21:11'),
(153, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #36 (Teuku Safril Nizam TM)', '2026-08-01 18:21:24'),
(154, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Ke meulaboh malam minggu perjaka mess', '2026-08-01 18:21:53'),
(155, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh malam minggu perjaka mess', '2026-08-01 23:26:56'),
(156, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — belanja kebutuhan pokok', '2026-08-02 12:08:36'),
(157, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: belanja kebutuhan pokok', '2026-08-02 12:14:45'),
(158, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 21.685, isi BBM Pertamax 4,6 L', '2026-08-02 18:51:12'),
(159, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja kebutuhan pokok/Kuala Bhee', '2026-08-03 09:25:57'),
(160, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #41 diperbarui oleh peminjam (Sabaruddin)', '2026-08-03 16:36:07'),
(161, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja kebutuhan pokok/Kuala Bhee', '2026-08-04 10:30:18'),
(162, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Balek ke mess, dan mau jajan keluar', '2026-08-04 12:02:41'),
(163, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Balek ke mess, dan mau jajan keluar', '2026-08-04 12:04:24'),
(164, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #42 diperbarui oleh peminjam (Abdul Karim)', '2026-08-04 13:20:25'),
(165, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Abdul Karim, KM akhir 15.081', '2026-08-04 13:21:12'),
(166, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — belanja', '2026-08-04 16:41:47'),
(167, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Edited', 'KM awal & foto kondisi peminjaman #43 diperbarui oleh peminjam (Harris Fadhilla Said)', '2026-08-04 19:00:50'),
(168, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: belanja', '2026-08-04 20:52:47'),
(169, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Harris Fadhilla Said, KM akhir 15.101', '2026-08-04 20:58:08'),
(170, 30, 'B 1770 PJL', 'TOYOTA FORTUNER FORTUNER2.7SRZ 4X2 AT', 'mahdy', 'Loan Request', 'Mengajukan peminjaman TOYOTA FORTUNER FORTUNER2.7SRZ 4X2 AT (B 1770 PJL) — Service dan isi BBM', '2026-08-05 11:31:42'),
(171, 30, 'B 1770 PJL', 'TOYOTA FORTUNER FORTUNER2.7SRZ 4X2 AT', 'mahdy', 'Loan Approved', 'TOYOTA FORTUNER FORTUNER2.7SRZ 4X2 AT — peminjaman disetujui untuk kegiatan: Service dan isi BBM', '2026-08-05 11:32:15'),
(172, 30, 'B 1770 PJL', 'TOYOTA FORTUNER FORTUNER2.7SRZ 4X2 AT', 'mahdy', 'Loan Completed', 'TOYOTA FORTUNER FORTUNER2.7SRZ 4X2 AT (B 1770 PJL) — dikembalikan oleh mahdy, KM akhir 80.263, isi BBM Pertamax 29,5 L', '2026-08-05 11:34:52'),
(173, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 21.726', '2026-08-05 16:23:39'),
(174, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja kebutuhan pokok Kuala Bhee', '2026-08-05 16:25:23'),
(175, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja kebutuhan pokok Kuala Bhee', '2026-08-05 16:49:56'),
(176, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 21.727', '2026-08-05 16:58:51'),
(177, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'GA Team', 'Vehicle Added', 'Kendaraan baru ditambahkan ke armada: Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB)', '2026-08-06 08:41:34'),
(178, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'mahdy', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — Antri Solar Hillux', '2026-08-06 08:43:32'),
(179, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'mahdy', 'Loan Approved', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT — peminjaman disetujui untuk kegiatan: Antri Solar Hillux', '2026-08-06 08:44:22'),
(180, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja kebutuhan pokok Meulaboh', '2026-08-06 15:46:48'),
(181, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja kebutuhan pokok Meulaboh', '2026-08-06 15:47:31'),
(182, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #47 diperbarui oleh peminjam (Sabaruddin)', '2026-08-06 16:17:42'),
(183, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #47 diperbarui oleh peminjam (Sabaruddin)', '2026-08-06 16:18:07'),
(184, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Bowo F Frandhika, KM akhir 3.737, isi BBM Pertalite 16,7 L', '2026-08-07 08:29:09'),
(185, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'mahdy', 'Loan Completed', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — dikembalikan oleh mahdy, KM akhir 108.053, isi BBM Solar 29,4 L', '2026-08-07 08:29:37'),
(186, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-08-07 17:09:59'),
(187, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-08-07 17:33:00'),
(188, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Ke kualabhee belanja', '2026-08-07 19:57:45'),
(189, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke kualabhee belanja', '2026-08-07 19:58:25'),
(190, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Abdul Karim, KM akhir 3.772, isi BBM Pertalite 15,4 L', '2026-08-07 22:14:42'),
(191, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 21.944', '2026-08-08 07:45:30'),
(192, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Belanja kebutuhan tamu dari HO, isi ulang air dll', '2026-08-08 08:52:25'),
(193, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Belanja kebutuhan tamu dari HO, isi ulang air dll', '2026-08-08 08:54:16'),
(194, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — belanja kebutuhan', '2026-08-08 15:32:30'),
(195, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Rejected', 'Peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) ditolak oleh Admin', '2026-08-08 16:10:32'),
(196, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Surya Ramadhan, KM akhir 2.637', '2026-08-08 16:11:40'),
(197, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — Ke meulaboh, ke kimia farma', '2026-08-08 19:15:45'),
(198, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT — peminjaman disetujui untuk kegiatan: Ke meulaboh, ke kimia farma', '2026-08-08 19:25:12'),
(199, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja sembako Kuala Bhee', '2026-08-09 07:06:18'),
(200, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #53 diperbarui oleh peminjam (Sabaruddin)', '2026-08-09 07:25:47'),
(201, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja sembako Kuala Bhee', '2026-08-09 08:22:56'),
(202, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — dikembalikan oleh Bowo F Frandhika, KM akhir 108.265', '2026-08-09 10:26:14'),
(203, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Abdul Karim, KM akhir 15.113', '2026-08-10 08:29:58'),
(204, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.145, isi BBM Pertamax 3,1 L', '2026-08-10 12:18:52'),
(205, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Mobil dalam Keadaan Baik', '2026-08-10 14:21:19'),
(206, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Nugroho Yulianto', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Mobil dalam Keadaan Baik', '2026-08-10 14:22:24'),
(207, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Nugroho Yulianto', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Nugroho Yulianto, KM akhir 2.652, isi BBM Pertalite 15,5 L', '2026-08-10 16:06:10'),
(208, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syukurdi Putra Yoga', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Beli nasi, makan malam tamu HO', '2026-08-10 16:08:04'),
(209, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syukurdi Putra Yoga', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Beli nasi, makan malam tamu HO', '2026-08-10 16:08:50'),
(210, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — belanja', '2026-08-10 16:43:14'),
(211, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Nugroho Yulianto', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: belanja', '2026-08-10 16:43:33'),
(212, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Nugroho Yulianto', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Nugroho Yulianto, KM akhir 22.186', '2026-08-10 17:37:06'),
(213, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syukurdi Putra Yoga', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Syukurdi Putra Yoga, KM akhir 2.722, isi BBM Pertalite 15,4 L', '2026-08-11 13:35:21'),
(214, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Surya Ramadhan', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — Isi Minyak Hilux', '2026-08-11 13:47:10'),
(215, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Surya Ramadhan', 'Loan Approved', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT — peminjaman disetujui untuk kegiatan: Isi Minyak Hilux', '2026-08-11 13:47:23'),
(216, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Surya Ramadhan', 'Loan Completed', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — dikembalikan oleh Surya Ramadhan, KM akhir 108.406, isi BBM Solar 20,0 L', '2026-08-11 14:39:36'),
(217, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — berobat', '2026-08-12 16:20:05'),
(218, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Nugroho Yulianto', 'Loan Rejected', 'Peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) ditolak oleh Admin', '2026-08-12 16:42:23'),
(219, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — berobat', '2026-08-12 17:01:54'),
(220, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Nugroho Yulianto', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: berobat', '2026-08-12 17:09:06'),
(221, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Nugroho Yulianto', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Nugroho Yulianto, KM akhir 2.869, isi BBM Pertalite 15,4 L', '2026-08-13 07:53:56'),
(222, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Antar karyawan sakit ke puskesmas kuala bhee', '2026-08-13 15:07:40'),
(223, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Antar karyawan sakit ke puskesmas kuala bhee', '2026-08-13 15:13:31'),
(224, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Ke meulaboh, makan bareng sama HO', '2026-08-13 18:37:22'),
(225, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh, makan bareng sama HO', '2026-08-13 18:59:40'),
(226, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Bowo F Frandhika, KM akhir 4.903, isi BBM Pertalite 7,7 L', '2026-08-14 10:46:08'),
(227, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Bowo F Frandhika, KM akhir 4.903', '2026-08-14 11:02:16'),
(228, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Tri Handiyanto', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Membawa karyawan ke pukesmas layung untuk berobat', '2026-08-14 11:04:37'),
(229, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Tri Handiyanto', 'Loan Edited', 'KM awal & foto kondisi peminjaman #62 diperbarui oleh peminjam (Tri Handiyanto)', '2026-08-14 12:04:51'),
(230, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Tri Handiyanto', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Membawa karyawan ke pukesmas layung untuk berobat', '2026-08-14 14:06:36'),
(231, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Tri Handiyanto', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Tri Handiyanto, KM akhir 4.925', '2026-08-14 14:07:47'),
(232, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Ahlun Nazar', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Ke bubon', '2026-08-14 16:58:07'),
(233, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan ke mbo', '2026-08-14 17:04:08'),
(234, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan ke mbo', '2026-08-14 17:04:08'),
(235, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Ahlun Nazar', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Ke bubon', '2026-08-14 19:16:40'),
(236, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan ke mbo', '2026-08-14 19:16:42'),
(237, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan ke mbo', '2026-08-14 19:16:50'),
(238, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.280, isi BBM Pertamax 3,1 L', '2026-08-14 19:26:02'),
(239, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Makan diluar', '2026-08-14 20:31:09'),
(240, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Makan diluar', '2026-08-14 20:34:22'),
(241, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Bowo F Frandhika, KM akhir 4.941', '2026-08-14 22:12:23'),
(242, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Ahlun Nazar', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Ahlun Nazar, KM akhir 3.069', '2026-08-14 23:51:54'),
(243, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Syukurdi Putra Yoga', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — Isi BBM (Solar), belanja kebutuhan HUT RI ke 81', '2026-08-15 09:07:59'),
(244, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Syukurdi Putra Yoga', 'Loan Approved', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT — peminjaman disetujui untuk kegiatan: Isi BBM (Solar), belanja kebutuhan HUT RI ke 81', '2026-08-15 09:12:12'),
(245, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'Syukurdi Putra Yoga', 'Loan Completed', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — dikembalikan oleh Syukurdi Putra Yoga, KM akhir 108.656, isi BBM Solar 25,0 L', '2026-08-15 13:40:32'),
(246, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.290, isi BBM Pertamax 3,1 L', '2026-08-15 13:59:20'),
(247, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Beli makan di luar', '2026-08-16 10:51:29'),
(248, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Beli makan di luar', '2026-08-16 11:41:58'),
(249, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Abdul Karim, KM akhir 22.345', '2026-08-17 07:30:43'),
(250, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ke dokter gigi, dan beli obat demam ke mbo.', '2026-08-17 08:01:10'),
(251, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ke dokter gigi, dan beli obat demam ke mbo.', '2026-08-18 08:22:57'),
(252, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.460, isi BBM Pertamax 2,2 L', '2026-08-18 09:00:04'),
(253, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Belanja Kepeluran GA (Isi Ulang Galon, Jemput Barang Pak Safril dll) ke meulaboh', '2026-08-18 09:55:44'),
(254, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Belanja Kepeluran GA (Isi Ulang Galon, Jemput Barang Pak Safril dll) ke meulaboh', '2026-08-18 09:55:50'),
(255, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'mahdy', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — Anti BBM Solar', '2026-08-18 09:59:14'),
(256, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'mahdy', 'Loan Approved', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT — peminjaman disetujui untuk kegiatan: Anti BBM Solar', '2026-08-18 09:59:30'),
(257, 27, 'BL 8435 EW', 'Nissan Navara Frontier 2 5 AT DC', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Nissan Navara Frontier 2 5 AT DC (BL 8435 EW) — Kegiatan antar plastik', '2026-08-18 11:05:35'),
(258, 27, 'BL 8435 EW', 'Nissan Navara Frontier 2 5 AT DC', 'Nugroho Yulianto', 'Loan Approved', 'Nissan Navara Frontier 2 5 AT DC — peminjaman disetujui untuk kegiatan: Kegiatan antar plastik', '2026-08-18 11:09:38'),
(259, 31, 'BL 8135 EB', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT', 'mahdy', 'Loan Completed', 'Toyota Hilux Solar Hilux 2.av DC 4X4 AT (BL 8135 EB) — dikembalikan oleh mahdy, KM akhir 108.939, isi BBM Solar 29,4 L', '2026-08-18 11:21:33'),
(260, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Kuala Bhee Belanja sembako', '2026-08-18 12:12:48'),
(261, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Kuala Bhee Belanja sembako', '2026-08-18 12:14:50'),
(262, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Surya Ramadhan, KM akhir 3.150, isi BBM Pertalite 15,4 L', '2026-08-18 14:05:31'),
(263, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'mahdy', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Beli pipa air karena ada kebocoran pipa air di gudang mesin pompa dekat mess', '2026-08-18 14:31:07'),
(264, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'mahdy', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Beli pipa air karena ada kebocoran pipa air di gudang mesin pompa dekat mess', '2026-08-18 14:31:53'),
(265, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #73 diperbarui oleh peminjam (Sabaruddin)', '2026-08-18 16:22:17'),
(266, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'mahdy', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh mahdy, KM akhir 3.232', '2026-08-18 16:35:40'),
(267, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Mau nnton bola di seuneubok', '2026-08-18 16:40:35'),
(268, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Mau nnton bola di seuneubok', '2026-08-18 16:43:43'),
(269, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.523', '2026-08-19 08:40:26'),
(270, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Kuala Bhee antar motor Donny Martha ke bengkel', '2026-08-19 08:41:43'),
(271, 27, 'BL 8435 EW', 'Nissan Navara Frontier 2 5 AT DC', 'Nugroho Yulianto', 'Loan Completed', 'Nissan Navara Frontier 2 5 AT DC (BL 8435 EW) — dikembalikan oleh Nugroho Yulianto, KM akhir 244.457, isi BBM Solar 13,3 L', '2026-08-19 08:41:44'),
(272, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Kuala Bhee antar motor Donny Martha ke bengkel', '2026-08-19 08:42:18'),
(273, 27, 'BL 8435 EW', 'Nissan Navara Frontier 2 5 AT DC', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Nissan Navara Frontier 2 5 AT DC (BL 8435 EW) — Kegiatan Pengantaran Plastik', '2026-08-19 09:40:29'),
(274, 27, 'BL 8435 EW', 'Nissan Navara Frontier 2 5 AT DC', 'Nugroho Yulianto', 'Loan Approved', 'Nissan Navara Frontier 2 5 AT DC — peminjaman disetujui untuk kegiatan: Kegiatan Pengantaran Plastik', '2026-08-19 09:40:34'),
(275, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.535', '2026-08-20 07:29:49'),
(276, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja kebutuhan pokok Kuala Bhee', '2026-08-20 07:31:35'),
(277, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Ibadah Jumat Kuala Bhee', '2026-08-20 07:33:37'),
(278, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Sama tiga antar ke jalur Travel', '2026-08-20 07:35:50'),
(279, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Sama tiga antar ke jalur Travel', '2026-08-20 07:51:55'),
(280, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Ibadah Jumat Kuala Bhee', '2026-08-20 07:52:12'),
(281, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja kebutuhan pokok Kuala Bhee', '2026-08-20 07:52:18'),
(282, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #78 diperbarui oleh peminjam (Sabaruddin)', '2026-08-20 16:11:11'),
(283, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.564', '2026-08-21 07:43:25'),
(284, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #75 diperbarui oleh peminjam (Abdul Karim)', '2026-08-21 07:51:31'),
(285, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Abdul Karim, KM akhir 15.221', '2026-08-21 07:52:23'),
(286, 27, 'BL 8435 EW', 'Nissan Navara Frontier 2 5 AT DC', 'Nugroho Yulianto', 'Loan Completed', 'Nissan Navara Frontier 2 5 AT DC (BL 8435 EW) — dikembalikan oleh Nugroho Yulianto, KM akhir 244.457', '2026-08-21 10:27:35'),
(287, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Solat jumat', '2026-08-21 11:52:17'),
(288, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Solat jumat', '2026-08-21 11:53:50'),
(289, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yasro S.E', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Shalat jumat', '2026-08-21 12:03:53'),
(290, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #79 diperbarui oleh peminjam (Sabaruddin)', '2026-08-21 12:06:07'),
(291, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yasro S.E', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Shalat jumat', '2026-08-21 12:08:07'),
(292, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.574', '2026-08-21 13:23:02'),
(293, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ke bank bsi meulaboh', '2026-08-21 13:23:36'),
(294, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ke bank bsi meulaboh', '2026-08-21 14:07:45'),
(295, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Teuku Safril Nizam TM, KM akhir 5.599, isi BBM Pertalite 3,8 L', '2026-08-21 14:41:26'),
(296, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yasro S.E', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yasro S.E, KM akhir 3.270', '2026-08-21 14:51:14'),
(297, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.700, isi BBM Pertamax 3,1 L', '2026-08-21 16:45:38'),
(298, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Fahlul Masri', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Beli makan malam', '2026-08-21 17:06:39'),
(299, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Donny Marta', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja ke kuala bhee', '2026-08-21 17:23:37'),
(300, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Fahlul Masri', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Beli makan malam', '2026-08-21 18:37:53'),
(301, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Donny Marta', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja ke kuala bhee', '2026-08-21 18:38:04'),
(302, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Donny Marta', 'Loan Edited', 'KM awal & foto kondisi peminjaman #85 diperbarui oleh peminjam (Donny Marta)', '2026-08-21 19:25:32'),
(303, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Donny Marta', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Donny Marta, KM akhir 22.655', '2026-08-21 19:26:29'),
(304, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Fahlul Masri', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Fahlul Masri, KM akhir 15.230', '2026-08-22 07:47:30'),
(305, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Surya Ramadhan', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Penjemputan Pak Bambang ke Bandara Iskandar Muda Banda Aceh', '2026-08-22 09:33:05'),
(306, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Surya Ramadhan', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Penjemputan Pak Bambang ke Bandara Iskandar Muda Banda Aceh', '2026-08-22 09:33:11'),
(307, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #80 diperbarui oleh peminjam (Sabaruddin)', '2026-08-22 13:08:56'),
(308, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-08-22 13:21:06'),
(309, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-08-22 14:25:47'),
(310, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.711', '2026-08-22 16:44:45'),
(311, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan di meulaboh', '2026-08-22 17:15:59'),
(312, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan di meulaboh', '2026-08-22 17:16:37'),
(313, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.775, isi BBM Pertamax 2,8 L', '2026-08-22 19:11:22'),
(314, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Donny Marta', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja', '2026-08-23 13:39:24'),
(315, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Donny Marta', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-08-23 13:41:27'),
(316, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Donny Marta', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Donny Marta, KM akhir 22.786', '2026-08-23 16:45:27'),
(317, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Nugroho Yulianto, KM akhir 15.316', '2026-08-24 07:40:46'),
(318, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ke meulaboh beli makan', '2026-08-24 11:59:23'),
(319, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ke meulaboh beli makan', '2026-08-24 12:03:39'),
(320, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Surya Ramadhan', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Surya Ramadhan, KM akhir 6.192, isi BBM Pertamax 30,7 L', '2026-08-24 12:12:08'),
(321, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Rusmanto', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Kunjungan duka ke rumah karyawan team workshop', '2026-08-24 12:18:19'),
(322, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Rusmanto', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Kunjungan duka ke rumah karyawan team workshop', '2026-08-24 12:18:29'),
(323, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Rusmanto', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Rusmanto, KM akhir 6.205', '2026-08-24 13:32:57'),
(324, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.856', '2026-08-24 18:57:17'),
(325, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Jemput Barang Warehouse (Pak Ahlun ) ke MBO', '2026-08-26 10:53:46'),
(326, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Jemput Barang Warehouse (Pak Ahlun ) ke MBO', '2026-08-26 10:53:51'),
(327, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Surya Ramadhan', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Surya Ramadhan, KM akhir 3.410', '2026-08-26 13:34:47'),
(328, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Syukurdi Putra Yoga', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Belanja ke mbo dan ukur baju team RM an Arib dan Yogie', '2026-08-27 09:43:16'),
(329, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Syukurdi Putra Yoga', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Belanja ke mbo dan ukur baju team RM an Arib dan Yogie', '2026-08-27 09:43:22'),
(330, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan di meulaboh', '2026-08-27 16:20:58'),
(331, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan di meulaboh', '2026-08-27 16:20:59'),
(332, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan di meulaboh', '2026-08-27 16:22:24'),
(333, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan di meulaboh', '2026-08-27 16:22:27'),
(334, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.927, isi BBM Pertamax 3,1 L', '2026-08-27 19:38:53'),
(335, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.865', '2026-08-28 12:27:34'),
(336, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Sholat Jum\'at Glee Siblah', '2026-08-28 12:29:05'),
(337, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #96 diperbarui oleh peminjam (Sabaruddin)', '2026-08-28 12:37:22'),
(338, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Syukurdi Putra Yoga', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Syukurdi Putra Yoga, KM akhir 6.279, isi BBM Pertalite 15,4 L', '2026-08-28 14:13:15'),
(339, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Sholat Jum\'at Glee Siblah', '2026-08-28 14:15:07'),
(340, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.935', '2026-08-28 15:24:38'),
(341, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Ke Loket Angkutan Umum antar kota', '2026-08-29 09:03:18'),
(342, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Ke Loket Angkutan Umum antar kota', '2026-08-29 09:04:22'),
(343, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #97 diperbarui oleh peminjam (Sabaruddin)', '2026-08-29 12:43:34'),
(344, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #97 diperbarui oleh peminjam (Sabaruddin)', '2026-08-29 12:44:24'),
(345, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #97 diperbarui oleh peminjam (Sabaruddin)', '2026-08-29 12:44:24'),
(346, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #97 diperbarui oleh peminjam (Sabaruddin)', '2026-08-29 12:44:24'),
(347, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #97 diperbarui oleh peminjam (Sabaruddin)', '2026-08-29 12:44:24'),
(348, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 22.938', '2026-08-29 12:45:46'),
(349, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — kondisi baik', '2026-08-29 13:06:04'),
(350, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: kondisi baik', '2026-08-29 13:07:26'),
(351, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — berobat ke klinkin', '2026-08-29 15:37:53'),
(352, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: berobat ke klinkin', '2026-08-29 15:38:55'),
(353, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Ke mbo belanja', '2026-08-29 19:09:23'),
(354, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 22.959', '2026-08-30 17:38:17'),
(355, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Nugroho Yulianto, KM akhir 15.450, isi BBM Pertamax 3,7 L', '2026-08-30 17:42:11'),
(356, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke mbo belanja', '2026-08-31 08:24:19'),
(357, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Safril Nizam TM', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Beli nasi', '2026-08-31 11:58:05'),
(358, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Safril Nizam TM', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Beli nasi', '2026-08-31 12:07:39'),
(359, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makan ke meulaboh', '2026-08-31 16:21:17'),
(360, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makan ke meulaboh', '2026-08-31 16:25:28'),
(361, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.030, isi BBM Pertamax 2,2 L', '2026-08-31 19:03:59'),
(362, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Beli peralatan pribadi ke Indomaret', '2026-08-31 19:16:35'),
(363, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Beli peralatan pribadi ke Indomaret', '2026-08-31 19:17:48'),
(364, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 23.048', '2026-08-31 21:31:01'),
(365, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Bowo F Frandhika, KM akhir 6.426', '2026-09-01 08:45:35');
INSERT INTO `activities` (`id`, `vehicle_id`, `plate_number`, `vehicle_name`, `pic_name`, `action_type`, `description`, `timestamp`) VALUES
(366, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Safril Nizam TM', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Teuku Safril Nizam TM, KM akhir 15.469', '2026-09-01 09:21:34'),
(367, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga sore', '2026-09-01 10:31:39'),
(368, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #104 (Abdul Karim)', '2026-09-01 10:50:15'),
(369, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga Sore', '2026-09-01 10:50:43'),
(370, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #105 (Abdul Karim)', '2026-09-01 11:00:39'),
(371, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga sore', '2026-09-01 11:01:10'),
(372, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #106 (Abdul Karim)', '2026-09-01 11:06:18'),
(373, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga Sore', '2026-09-01 11:07:10'),
(374, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #107 (Abdul Karim)', '2026-09-01 11:08:24'),
(375, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga Sore', '2026-09-01 11:08:44'),
(376, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #108 (Abdul Karim)', '2026-09-01 11:12:13'),
(377, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga sore', '2026-09-01 11:12:32'),
(378, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #109 (Abdul Karim)', '2026-09-01 11:13:05'),
(379, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga sore', '2026-09-01 11:13:36'),
(380, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Olahraga sore', '2026-09-01 15:30:27'),
(381, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan di mboo', '2026-09-01 16:12:30'),
(382, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan di mboo', '2026-09-01 17:31:21'),
(383, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.117', '2026-09-01 18:36:24'),
(384, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fauzi', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Antar karyawan sakit ke Puskesmas', '2026-09-02 10:06:50'),
(385, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fauzi', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Antar karyawan sakit ke Puskesmas', '2026-09-02 10:10:49'),
(386, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Beli keperluan pribadi', '2026-09-02 19:23:25'),
(387, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #113 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-09-02 19:24:21'),
(388, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #110 diperbarui oleh peminjam (Abdul Karim)', '2026-09-02 19:58:06'),
(389, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Abdul Karim, KM akhir 15.485', '2026-09-02 19:58:37'),
(390, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Beli keperluan pribadi', '2026-09-02 20:34:43'),
(391, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 23.137', '2026-09-02 20:54:24'),
(392, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fauzi', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Fauzi, KM akhir 6.556', '2026-09-03 09:34:35'),
(393, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Meulaboh', '2026-09-03 10:09:50'),
(394, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Meulaboh', '2026-09-03 10:38:34'),
(395, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Sabaruddin', '2026-09-03 11:06:16'),
(396, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Perjalanan Pribadi-Beli Obat ke Kuala Bhee', '2026-09-03 11:28:39'),
(397, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Perjalanan Pribadi-Beli Obat ke Kuala Bhee', '2026-09-03 12:28:50'),
(398, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #115 diperbarui oleh peminjam (Sabaruddin)', '2026-09-03 12:59:58'),
(399, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #115 diperbarui oleh peminjam (Sabaruddin)', '2026-09-03 13:00:04'),
(400, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #115 diperbarui oleh peminjam (Sabaruddin)', '2026-09-03 13:00:28'),
(401, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 23.154', '2026-09-03 13:25:38'),
(402, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — berobat', '2026-09-03 16:15:54'),
(403, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: berobat', '2026-09-03 16:40:15'),
(404, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Nugroho Yulianto, KM akhir 6.709', '2026-09-04 08:30:28'),
(405, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga Sore', '2026-09-04 08:31:02'),
(406, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Pembelian kebutuhan pribadi', '2026-09-04 16:02:29'),
(407, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Pembelian kebutuhan pribadi', '2026-09-04 16:02:51'),
(408, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Yogie Aditya Pratama', '2026-09-04 17:07:39'),
(409, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #117 (Abdul Karim)', '2026-09-04 17:22:57'),
(410, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Mau belanja', '2026-09-04 17:23:41'),
(411, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Mau belanja', '2026-09-04 17:27:56'),
(412, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #119 diperbarui oleh peminjam (Abdul Karim)', '2026-09-05 08:07:32'),
(413, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Abdul Karim, KM akhir 23.257', '2026-09-05 08:07:58'),
(414, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli kebutuhan makanan di mbo', '2026-09-05 13:09:23'),
(415, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-09-05 13:10:34'),
(416, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli kebutuhan makanan di mbo', '2026-09-05 13:31:11'),
(417, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-09-05 13:31:14'),
(418, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 15.524', '2026-09-05 16:38:42'),
(419, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.328, isi BBM Pertamax 3,1 L', '2026-09-05 20:25:23'),
(420, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Jalan2', '2026-09-05 21:07:58'),
(421, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Beli makan', '2026-09-05 21:08:40'),
(422, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #122 (Abdul Karim)', '2026-09-05 21:09:34'),
(423, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Beli makan', '2026-09-05 21:09:37'),
(424, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Ke meulaboh, mau belanja dan makan', '2026-09-06 18:39:43'),
(425, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh, mau belanja dan makan', '2026-09-06 18:50:47'),
(426, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #123 diperbarui oleh peminjam (Abdul Karim)', '2026-09-06 19:16:09'),
(427, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Abdul Karim, KM akhir 23.348', '2026-09-06 19:16:47'),
(428, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Kualabee', '2026-09-06 19:25:32'),
(429, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Kualabee', '2026-09-06 19:30:56'),
(430, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 15.543', '2026-09-06 21:05:13'),
(431, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Abdul Karim, KM akhir 23.348', '2026-09-07 10:09:42'),
(432, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Teuku Safril Nizam TM', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Beli makan', '2026-09-08 12:10:29'),
(433, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Ahlun Nazar', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Mendampingi tim bwss 1 aceh', '2026-09-08 12:23:18'),
(434, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Teuku Safril Nizam TM', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Beli makan', '2026-09-08 12:28:03'),
(435, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Ahlun Nazar', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Mendampingi tim bwss 1 aceh', '2026-09-08 12:28:29'),
(436, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #126 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-09-08 16:05:02'),
(437, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Teuku Safril Nizam TM', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Teuku Safril Nizam TM, KM akhir 23.367', '2026-09-08 16:05:38'),
(438, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanann', '2026-09-08 16:08:40'),
(439, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Ahlun Nazar', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Ahlun Nazar, KM akhir 6.899', '2026-09-08 16:15:09'),
(440, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — belanja', '2026-09-08 16:31:41'),
(441, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanann', '2026-09-08 16:35:27'),
(442, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: belanja', '2026-09-08 16:35:32'),
(443, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.387', '2026-09-08 19:13:46'),
(444, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — Ke meulaboh, makan', '2026-09-08 19:24:30'),
(445, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh, makan', '2026-09-08 20:49:45'),
(446, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Edited', 'KM awal & foto kondisi peminjaman #130 diperbarui oleh peminjam (Bowo F Frandhika)', '2026-09-08 20:50:29'),
(447, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'GA Team', 'Loan Deleted', 'Menghapus catatan peminjaman ID #124 (Abdul Karim)', '2026-09-08 20:51:04'),
(448, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Harris Fadhilla Said, KM akhir 15.562', '2026-09-09 07:48:16'),
(449, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Perjalanan pribadi-Puskesmas Kuala Bhee', '2026-09-09 08:16:43'),
(450, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #131 diperbarui oleh peminjam (Sabaruddin)', '2026-09-09 09:59:45'),
(451, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Bowo F Frandhika, KM akhir 6.969', '2026-09-09 10:14:28'),
(452, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-09-09 16:09:48'),
(453, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Rejected', 'Peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) ditolak oleh Admin', '2026-09-09 16:11:27'),
(454, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Rejected', 'Peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) ditolak oleh Admin', '2026-09-09 16:11:32'),
(455, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-09-09 16:12:25'),
(456, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-09-09 16:18:59'),
(457, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 15.581', '2026-09-09 17:58:12'),
(458, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ganti karet behel ke mbo', '2026-09-10 15:20:34'),
(459, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ganti karet behel ke mbo', '2026-09-10 15:33:57'),
(460, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — berobat', '2026-09-10 17:09:08'),
(461, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — berobat', '2026-09-10 17:09:10'),
(462, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Harris Fadhilla Said', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: berobat', '2026-09-10 17:13:52'),
(463, 26, 'BL 1770 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Harris Fadhilla Said', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1770 AZH) — dikembalikan oleh Harris Fadhilla Said, KM akhir 7.155', '2026-09-11 07:49:53'),
(464, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.435', '2026-09-11 07:54:17'),
(465, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Visit Supplier', '2026-09-11 09:37:17'),
(466, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'GA Team', 'Vehicle Updated', 'Data kendaraan diperbarui: Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH)', '2026-09-11 10:27:47'),
(467, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Sholat jumat', '2026-09-11 11:33:58'),
(468, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Rejected', 'Peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) ditolak oleh Admin', '2026-09-11 11:50:32'),
(469, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Visit Supplier', '2026-09-11 11:50:35'),
(470, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Harris Fadhilla Said', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: berobat', '2026-09-11 11:53:06'),
(471, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Jum\'atan', '2026-09-11 11:55:31'),
(472, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Jum\'atan', '2026-09-11 11:59:33'),
(473, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #139 diperbarui oleh peminjam (Abdul Karim)', '2026-09-11 14:10:28'),
(474, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Abdul Karim, KM akhir 23.453', '2026-09-11 14:10:48'),
(475, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Teuku Arib Multazam, KM akhir 15.635', '2026-09-11 16:53:44'),
(476, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja', '2026-09-11 17:22:49'),
(477, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-09-11 17:34:12'),
(478, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-09-11 17:37:59'),
(479, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-09-11 17:38:22'),
(480, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 15.654', '2026-09-11 22:06:04'),
(481, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #140 diperbarui oleh peminjam (Abdul Karim)', '2026-09-12 08:57:32'),
(482, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Abdul Karim, KM akhir 23.460', '2026-09-12 08:58:03'),
(483, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Visit suplier', '2026-09-12 09:22:15'),
(484, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Visit suplier', '2026-09-12 09:46:14'),
(485, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ganti karet behel dan beli makanan', '2026-09-12 11:23:19'),
(486, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Harris Fadhilla Said', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Harris Fadhilla Said, KM akhir 7.155', '2026-09-12 11:24:26'),
(487, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ganti karet behel dan beli makanan', '2026-09-12 12:05:09'),
(488, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Belanja sekaligus lihat anaknya anggota qc yang baru lahiran', '2026-09-12 13:10:15'),
(489, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Belanja sekaligus lihat anaknya anggota qc yang baru lahiran', '2026-09-12 13:13:21'),
(490, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Teuku Arib Multazam, KM akhir 157', '2026-09-12 14:02:25'),
(491, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Kualabee', '2026-09-12 14:08:26'),
(492, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #144 diperbarui oleh peminjam (Abdul Karim)', '2026-09-12 19:25:40'),
(493, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.540, isi BBM Pertamax 3,7 L', '2026-09-12 19:50:29'),
(494, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-09-13 16:07:34'),
(495, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Edited', 'KM awal & foto kondisi peminjaman #146 diperbarui oleh peminjam (Nugroho Yulianto)', '2026-09-13 16:08:27'),
(496, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-09-13 18:02:47'),
(497, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Nugroho Yulianto, KM akhir 15.754', '2026-09-13 18:38:21'),
(498, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Abdul Karim, KM akhir 44.723', '2026-09-14 07:51:59'),
(499, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — ke medan', '2026-09-14 07:57:53'),
(500, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Edited', 'KM awal & foto kondisi peminjaman #147 diperbarui oleh peminjam (Nugroho Yulianto)', '2026-09-14 07:58:52'),
(501, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Edited', 'KM awal & foto kondisi peminjaman #147 diperbarui oleh peminjam (Nugroho Yulianto)', '2026-09-14 07:58:59'),
(502, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: ke medan', '2026-09-14 08:15:58'),
(503, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Kualabee', '2026-09-14 08:15:58'),
(504, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Beli Mata Gerinda', '2026-09-14 10:16:10'),
(505, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Edited', 'KM awal & foto kondisi peminjaman #148 diperbarui oleh peminjam (Syarwani)', '2026-09-14 10:17:37'),
(506, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Beli Mata Gerinda', '2026-09-14 10:17:41'),
(507, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 15.717', '2026-09-14 10:46:28'),
(508, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Visit suplier', '2026-09-14 10:47:36'),
(509, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Visit suplier', '2026-09-14 10:48:04'),
(510, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Edited', 'KM awal & foto kondisi peminjaman #149 diperbarui oleh peminjam (Teuku Arib Multazam)', '2026-09-14 10:52:02'),
(511, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Syarwani, KM akhir 23.581', '2026-09-14 11:00:42'),
(512, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Teuku Arib Multazam, KM akhir 158, isi BBM Pertamax 1,2 L', '2026-09-14 15:07:03'),
(513, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Kualabee', '2026-09-14 18:55:53'),
(514, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Dinner', '2026-09-14 21:17:55'),
(515, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Edited', 'KM awal & foto kondisi peminjaman #151 diperbarui oleh peminjam (Harris Fadhilla Said)', '2026-09-14 21:18:59'),
(516, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #150 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-09-14 21:39:32'),
(517, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Kualabee', '2026-09-14 21:49:50'),
(518, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 23.601', '2026-09-14 21:52:19'),
(519, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Visit suplier', '2026-09-15 10:04:47'),
(520, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Ke panglong kayu', '2026-09-15 10:05:14'),
(521, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Ke panglong kayu', '2026-09-15 10:05:22'),
(522, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Edited', 'KM awal & foto kondisi peminjaman #153 diperbarui oleh peminjam (Syarwani)', '2026-09-15 10:05:44'),
(523, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Visit suplier', '2026-09-15 10:05:58'),
(524, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Syarwani, KM akhir 23.643', '2026-09-15 15:24:33'),
(525, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan ke meulaboh aceh barat', '2026-09-15 15:26:44'),
(526, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan ke meulaboh aceh barat', '2026-09-15 15:30:21'),
(527, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Teuku Arib Multazam, KM akhir 15.845', '2026-09-15 16:10:47'),
(528, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Olahraga', '2026-09-15 16:13:02'),
(529, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Olahraga', '2026-09-15 16:15:08'),
(530, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.645', '2026-09-16 05:55:42'),
(531, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #155 diperbarui oleh peminjam (Abdul Karim)', '2026-09-16 07:56:23'),
(532, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Abdul Karim', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Abdul Karim, KM akhir 15.869', '2026-09-16 07:57:10'),
(533, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Perjalanan Dinas BSI Meulaboh', '2026-09-16 10:48:37'),
(534, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Perjalanan Dinas BSI Meulaboh', '2026-09-16 10:53:29'),
(535, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Kuala bee', '2026-09-16 11:23:35'),
(536, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:37'),
(537, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:37'),
(538, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:42'),
(539, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:42'),
(540, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:42'),
(541, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:42'),
(542, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:42'),
(543, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #156 diperbarui oleh peminjam (Sabaruddin)', '2026-09-16 12:07:42'),
(544, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Kuala bee', '2026-09-16 15:18:40'),
(545, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 23.717, isi BBM Pertamax 4,0 L', '2026-09-16 16:19:09'),
(546, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #157 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-09-16 16:53:23'),
(547, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 15.907', '2026-09-16 18:53:56'),
(548, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Visit suplier', '2026-09-17 10:32:11'),
(549, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Visit suplier', '2026-09-17 10:33:05'),
(550, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ke meulaboh beli makanan', '2026-09-17 11:55:15'),
(551, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ke meulaboh beli makanan', '2026-09-17 11:56:48'),
(552, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Teuku Arib Multazam', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Teuku Arib Multazam, KM akhir 159', '2026-09-17 16:25:08'),
(553, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.746', '2026-09-18 08:27:42'),
(554, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Nugroho Yulianto, KM akhir 60.021', '2026-09-18 11:12:49'),
(555, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Solat jumat', '2026-09-18 12:04:22'),
(556, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Solat jumat', '2026-09-18 12:04:49'),
(557, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Beli keran air', '2026-09-18 14:32:46'),
(558, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Edited', 'KM awal & foto kondisi peminjaman #161 diperbarui oleh peminjam (Syarwani)', '2026-09-18 15:03:12'),
(559, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Beli keran air', '2026-09-18 15:03:14'),
(560, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Syarwani', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Syarwani, KM akhir 23.767', '2026-09-18 15:03:32'),
(561, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Antar barang ke glee siblah', '2026-09-18 15:16:21'),
(562, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Antar barang ke glee siblah', '2026-09-18 15:26:13'),
(563, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Teuku Safril Nizam TM, KM akhir 6.025', '2026-09-18 15:27:56'),
(564, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 23.767', '2026-09-18 15:28:44'),
(565, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Antar barang ke glee siblah', '2026-09-18 16:00:28'),
(566, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-09-18 17:20:58'),
(567, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Edited', 'KM awal & foto kondisi peminjaman #164 diperbarui oleh peminjam (Harris Fadhilla Said)', '2026-09-18 17:21:51'),
(568, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Antar barang ke glee siblah', '2026-09-18 18:04:07'),
(569, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-09-18 18:04:12'),
(570, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Harris Fadhilla Said', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Harris Fadhilla Said, KM akhir 15.969', '2026-09-18 19:11:11'),
(571, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #163 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-09-18 20:13:06'),
(572, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 23.794', '2026-09-18 20:13:46'),
(573, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makan ke meulaboh', '2026-09-19 08:17:26'),
(574, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makan ke meulaboh', '2026-09-19 08:29:06'),
(575, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Kuala bee', '2026-09-19 17:56:58'),
(576, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #166 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-09-19 19:30:18'),
(577, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Kuala bee', '2026-09-19 20:07:11'),
(578, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 15.987', '2026-09-19 21:21:10'),
(579, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-09-20 17:04:52'),
(580, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-09-20 17:05:25'),
(581, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Edited', 'KM awal & foto kondisi peminjaman #167 diperbarui oleh peminjam (Nugroho Yulianto)', '2026-09-20 17:05:52'),
(582, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Nugroho Yulianto, KM akhir 16.007', '2026-09-20 18:52:03'),
(583, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 23.894, isi BBM Pertamax 3,1 L', '2026-09-21 08:00:16'),
(584, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Perjalanan Dinas KTR pos Meulaboh', '2026-09-21 11:49:37'),
(585, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Perjalanan Dinas KTR pos Meulaboh', '2026-09-21 11:54:55'),
(586, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #168 diperbarui oleh peminjam (Sabaruddin)', '2026-09-21 12:02:59'),
(587, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #168 diperbarui oleh peminjam (Sabaruddin)', '2026-09-21 12:02:59'),
(588, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Rimada Natanegara', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Beli nasi', '2026-09-21 14:50:15'),
(589, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Rimada Natanegara', 'Loan Edited', 'KM awal & foto kondisi peminjaman #169 diperbarui oleh peminjam (Rimada Natanegara)', '2026-09-21 14:50:47'),
(590, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Rimada Natanegara', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Beli nasi', '2026-09-21 14:50:51'),
(591, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 23.965, isi BBM Pertamax 2,8 L', '2026-09-21 16:03:48'),
(592, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Beli makan kuala bee', '2026-09-21 16:08:46'),
(593, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #170 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-09-21 16:12:58'),
(594, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Beli makan kuala bee', '2026-09-22 08:40:28'),
(595, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 16.047', '2026-09-22 08:41:31'),
(596, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Rimada Natanegara', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Rimada Natanegara, KM akhir 4.274', '2026-09-22 12:34:58'),
(597, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — takziah kerumah duka pak Arib rekan di divisi Raw Material', '2026-09-22 13:10:50'),
(598, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: takziah kerumah duka pak Arib rekan di divisi Raw Material', '2026-09-22 14:16:22'),
(599, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Ke meulaboh,', '2026-09-22 16:48:48'),
(600, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Bowo F Frandhika', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Ke meulaboh,', '2026-09-22 17:34:00'),
(601, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 24.032', '2026-09-23 07:51:43'),
(602, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Beli makan malam tim HO', '2026-09-23 08:45:10'),
(603, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Edited', 'KM awal & foto kondisi peminjaman #173 diperbarui oleh peminjam (Syarwani)', '2026-09-23 08:45:22'),
(604, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Beli makan malam tim HO', '2026-09-23 08:45:24'),
(605, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Syarwani, KM akhir 4.344', '2026-09-23 08:45:46'),
(606, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Kuala bee', '2026-09-23 15:41:34'),
(607, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Ambil nasi di Meulaboh', '2026-09-23 15:58:03'),
(608, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Edited', 'KM awal & foto kondisi peminjaman #175 diperbarui oleh peminjam (Syarwani)', '2026-09-23 15:58:37'),
(609, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Ambil nasi di Meulaboh', '2026-09-23 15:58:39'),
(610, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Syarwani, KM akhir 4.415', '2026-09-23 15:59:08');
INSERT INTO `activities` (`id`, `vehicle_id`, `plate_number`, `vehicle_name`, `pic_name`, `action_type`, `description`, `timestamp`) VALUES
(611, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Kuala bee', '2026-09-23 15:59:11'),
(612, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #174 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-09-23 20:00:33'),
(613, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Yogie Aditya Pratama', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 24.053', '2026-09-23 20:01:07'),
(614, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — diner', '2026-09-24 18:54:57'),
(615, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Harris Fadhilla Said', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: diner', '2026-09-24 19:05:53'),
(616, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Ambil paket ke SP Gunong meuh', '2026-09-25 06:59:17'),
(617, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Ambil paket ke SP Gunong meuh', '2026-09-25 06:59:51'),
(618, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #177 diperbarui oleh peminjam (Sabaruddin)', '2026-09-25 09:52:38'),
(619, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #177 diperbarui oleh peminjam (Sabaruddin)', '2026-09-25 09:52:52'),
(620, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 24.052', '2026-09-25 09:53:27'),
(621, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Perjalanan: Undangan maulid dan belanja ke Meulaboh', '2026-09-25 14:48:25'),
(622, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Sabaruddin', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Perjalanan: Undangan maulid dan belanja ke Meulaboh', '2026-09-25 14:49:31'),
(623, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ke meulaboh beli makan', '2026-09-25 15:19:24'),
(624, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ke meulaboh beli makan', '2026-09-25 15:21:46'),
(625, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 24.247', '2026-09-25 19:26:05'),
(626, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — perbaikan kapas rem vario ke dealer di meulaboh', '2026-09-26 09:18:21'),
(627, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #178 diperbarui oleh peminjam (Sabaruddin)', '2026-09-27 09:21:26'),
(628, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #178 diperbarui oleh peminjam (Sabaruddin)', '2026-09-27 09:21:41'),
(629, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: perbaikan kapas rem vario ke dealer di meulaboh', '2026-09-27 17:25:59'),
(630, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 24.420, isi BBM Pertamax 2,8 L', '2026-09-27 17:28:22'),
(631, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Sabaruddin', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Sabaruddin, KM akhir 10.613', '2026-09-27 17:55:41'),
(632, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fahlul Masri', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Pembayaran pelaksanaan pemeriksaan dokumen rintek penyimpanan limbah B3 dan pemeriksaan substansi dokumen lingkungan ke dlhk kab. Aceh barat', '2026-09-28 10:38:29'),
(633, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fahlul Masri', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Pembayaran pelaksanaan pemeriksaan dokumen rintek penyimpanan limbah B3 dan pemeriksaan substansi dokumen lingkungan ke dlhk kab. Aceh barat', '2026-09-28 10:38:29'),
(634, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fahlul Masri', 'Loan Edited', 'KM awal & foto kondisi peminjaman #182 diperbarui oleh peminjam (Fahlul Masri)', '2026-09-28 10:40:03'),
(635, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fahlul Masri', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Pembayaran pelaksanaan pemeriksaan dokumen rintek penyimpanan limbah B3 dan pemeriksaan substansi dokumen lingkungan ke dlhk kab. Aceh barat', '2026-09-28 10:44:37'),
(636, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fahlul Masri', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Fahlul Masri, KM akhir 10.784, isi BBM Pertalite 7,7 L', '2026-09-28 14:22:51'),
(637, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Bowo F Frandhika', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Bowo F Frandhika, KM akhir 16.301', '2026-09-29 16:13:07'),
(638, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Harris Fadhilla Said', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Harris Fadhilla Said, KM akhir 4.484', '2026-09-29 16:18:26'),
(639, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fahlul Masri', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Pembayaran pelaksanaan pemeriksaan dokumen rintek penyimpanan limbah B3 dan pemeriksaan substansi dokumen lingkungan ke dlhk kab. Aceh barat', '2026-09-29 16:29:57'),
(640, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Siti Utari Amaranggana', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli galon ke kuala bhee', '2026-09-29 17:24:36'),
(641, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Siti Utari Amaranggana', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli galon ke kuala bhee', '2026-09-29 17:25:01'),
(642, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Siti Utari Amaranggana', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Siti Utari Amaranggana, KM akhir 24.442', '2026-09-29 19:06:32'),
(643, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Beli Bokar ke lapangan / ranger', '2026-09-30 08:22:38'),
(644, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Beli Bokar ke lapangan / ranger', '2026-09-30 09:02:09'),
(645, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — beli makanan ke meulaboh', '2026-09-30 15:48:32'),
(646, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: beli makanan ke meulaboh', '2026-09-30 16:01:57'),
(647, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Fahlul Masri', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Fahlul Masri, KM akhir 10.837', '2026-09-30 16:06:38'),
(648, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 24.520, isi BBM Pertamax 1,9 L', '2026-09-30 20:06:22'),
(649, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 4.697', '2026-10-01 08:27:16'),
(650, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Mapping, Ranger', '2026-10-01 08:28:11'),
(651, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #186 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-10-01 08:38:53'),
(652, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #186 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-10-01 08:38:54'),
(653, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Mapping, Ranger', '2026-10-01 16:10:45'),
(654, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Ke meulaboh', '2026-10-01 16:19:53'),
(655, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh', '2026-10-01 16:49:12'),
(656, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Dinner', '2026-10-01 17:05:16'),
(657, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 4.858', '2026-10-01 23:55:50'),
(658, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Harris Fadhilla Said, KM akhir 24.542', '2026-10-02 07:34:10'),
(659, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #187 diperbarui oleh peminjam (Abdul Karim)', '2026-10-02 08:41:28'),
(660, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Abdul Karim, KM akhir 10.910, isi BBM Pertalite 15,4 L', '2026-10-02 08:43:20'),
(661, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Jemput bokar/ranger', '2026-10-02 10:55:50'),
(662, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Jemput bokar/ranger', '2026-10-02 10:58:38'),
(663, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Shalat Jum\'at', '2026-10-02 12:46:24'),
(664, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Edited', 'KM awal & foto kondisi peminjaman #189 diperbarui oleh peminjam (Harris Fadhilla Said)', '2026-10-02 12:48:10'),
(665, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Shalat Jum\'at', '2026-10-02 13:22:17'),
(666, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Harris Fadhilla Said', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Harris Fadhilla Said, KM akhir 24.550', '2026-10-02 13:23:02'),
(667, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Solat jumat', '2026-10-02 14:09:01'),
(668, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Solat jumat', '2026-10-02 14:09:34'),
(669, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #190 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-10-02 14:11:45'),
(670, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #190 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-10-02 14:11:46'),
(671, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 10.930', '2026-10-02 14:12:19'),
(672, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #190 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-10-03 08:48:52'),
(673, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Teuku Safril Nizam TM, KM akhir 10.930', '2026-10-03 08:50:51'),
(674, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Ke melaboh jemput isteri', '2026-10-03 09:02:06'),
(675, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke melaboh jemput isteri', '2026-10-03 12:49:52'),
(676, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #191 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-10-03 12:50:15'),
(677, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 11.007', '2026-10-03 12:50:35'),
(678, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Perjalanan Dinas- Meulaboh Belanja office supplies', '2026-10-03 13:02:52'),
(679, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Perjalanan Dinas- Meulaboh Belanja office supplies', '2026-10-03 13:20:39'),
(680, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Ke meulaboh', '2026-10-03 13:22:53'),
(681, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh', '2026-10-03 13:42:19'),
(682, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Edited', 'KM awal & foto kondisi peminjaman #193 diperbarui oleh peminjam (Abdul Karim)', '2026-10-03 19:03:57'),
(683, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — ganti karet behel ke meulaboh', '2026-10-04 07:54:10'),
(684, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: ganti karet behel ke meulaboh', '2026-10-04 08:12:16'),
(685, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #192 diperbarui oleh peminjam (Sabaruddin)', '2026-10-04 11:12:45'),
(686, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #192 diperbarui oleh peminjam (Sabaruddin)', '2026-10-04 11:13:02'),
(687, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 24.647, isi BBM Pertamax 1,5 L', '2026-10-04 15:52:06'),
(688, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Sabaruddin', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Sabaruddin, KM akhir 5.011, isi BBM Pertalite 30,8 L', '2026-10-04 17:51:26'),
(689, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Abdul Karim', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Abdul Karim, KM akhir 11.008', '2026-10-05 07:53:25'),
(690, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Jemput Bokar/Ranger', '2026-10-05 08:30:34'),
(691, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Jemput Bokar/Ranger', '2026-10-05 08:36:18'),
(692, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja sembako Kuala Bhee', '2026-10-05 11:53:47'),
(693, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja sembako Kuala Bhee', '2026-10-05 11:54:22'),
(694, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #196 diperbarui oleh peminjam (Sabaruddin)', '2026-10-05 12:20:24'),
(695, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 24.655', '2026-10-05 13:10:05'),
(696, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Ke meulaboh belanja', '2026-10-05 19:11:13'),
(697, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke meulaboh belanja', '2026-10-05 19:17:23'),
(698, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama', '2026-10-06 08:06:19'),
(699, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Edited', 'KM awal & foto kondisi peminjaman #197 diperbarui oleh peminjam (Bowo F Frandhika)', '2026-10-06 08:44:37'),
(700, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Bowo F Frandhika', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Bowo F Frandhika, KM akhir 11.246, isi BBM Pertalite 15,4 L', '2026-10-06 08:45:52'),
(701, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Visit toko Baja Utama', '2026-10-06 10:05:20'),
(702, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #198 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-10-06 10:07:17'),
(703, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #198 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-10-06 13:22:03'),
(704, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Perjalanan Dinas-Meulaboh', '2026-10-06 15:58:43'),
(705, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #198 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-10-06 16:16:48'),
(706, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #199 diperbarui oleh peminjam (Sabaruddin)', '2026-10-06 16:19:03'),
(707, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Visit toko Baja Utama', '2026-10-06 17:12:44'),
(708, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Edited', 'KM awal & foto kondisi peminjaman #198 diperbarui oleh peminjam (Teuku Safril Nizam TM)', '2026-10-06 17:14:52'),
(709, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Teuku Safril Nizam TM', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Teuku Safril Nizam TM, KM akhir 11.321', '2026-10-06 17:15:08'),
(710, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Perjalanan Dinas-Meulaboh', '2026-10-06 17:19:54'),
(711, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Ke Meulaboh beli Oksigen dan Ambil barang di toko baja utama', '2026-10-07 09:45:51'),
(712, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Edited', 'KM awal & foto kondisi peminjaman #200 diperbarui oleh peminjam (Syarwani)', '2026-10-07 09:46:32'),
(713, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Ke Meulaboh beli Oksigen dan Ambil barang di toko baja utama', '2026-10-07 09:46:33'),
(714, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 24.772, isi BBM Pertamax 4,3 L', '2026-10-07 11:23:27'),
(715, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Rimada Natanegara', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Ke dinas DLHK dan beli dispenser di Meulaboh', '2026-10-07 13:26:19'),
(716, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Rimada Natanegara', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke dinas DLHK dan beli dispenser di Meulaboh', '2026-10-07 13:27:24'),
(717, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Syarwani', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Syarwani, KM akhir 5.326', '2026-10-08 07:48:24'),
(718, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Perjalanan Dinas- Smart agen BSI Kuala Bhee', '2026-10-08 09:15:07'),
(719, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Perjalanan Dinas- Smart agen BSI Kuala Bhee', '2026-10-08 09:15:18'),
(720, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Rimada Natanegara', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Rimada Natanegara, KM akhir 11.388', '2026-10-08 09:16:17'),
(721, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #202 diperbarui oleh peminjam (Sabaruddin)', '2026-10-08 10:12:56'),
(722, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 24.820', '2026-10-08 10:13:57'),
(723, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Cari bokar di aceh barat', '2026-10-08 14:16:36'),
(724, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #203 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-10-08 14:17:36'),
(725, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Belanja', '2026-10-08 19:34:13'),
(726, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-10-08 19:47:00'),
(727, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Cari bokar di aceh barat', '2026-10-08 19:47:03'),
(728, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Nugroho Yulianto', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Nugroho Yulianto, KM akhir 16.379', '2026-10-09 08:17:36'),
(729, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 16.379', '2026-10-09 08:17:47'),
(730, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Jemput bokar/ranger', '2026-10-09 11:58:52'),
(731, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #205 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-10-09 11:59:42'),
(732, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Berobat', '2026-10-09 18:01:40'),
(733, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Berobat', '2026-10-09 18:09:24'),
(734, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Nugroho Yulianto', 'Loan Completed', 'Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — dikembalikan oleh Nugroho Yulianto, KM akhir 11.657', '2026-10-10 07:54:16'),
(735, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Jemput bokar/ranger', '2026-10-10 09:00:22'),
(736, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama', '2026-10-10 12:05:46'),
(737, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Kunjungan supplier', '2026-10-10 12:07:32'),
(738, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Kunjungan supplier', '2026-10-10 12:54:54'),
(739, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama', '2026-10-10 15:30:15'),
(740, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — berobat', '2026-10-11 07:36:30'),
(741, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: berobat', '2026-10-11 07:37:20'),
(742, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 24.971, isi BBM Pertamax 1,9 L', '2026-10-11 11:07:44'),
(743, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Jemput bokar', '2026-10-12 08:28:43'),
(744, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Belanja', '2026-10-12 11:05:20'),
(745, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Jemput bokar', '2026-10-12 11:05:47'),
(746, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Belanja', '2026-10-12 11:05:48'),
(747, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 5.619', '2026-10-12 16:21:11'),
(748, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Harris Fadhilla Said', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — berobat tari', '2026-10-12 16:43:09'),
(749, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Abdul Karim', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Abdul Karim', '2026-10-13 13:58:49'),
(750, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — Perjalanan Dinas-Meulaboh', '2026-10-14 07:17:16'),
(751, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Edited', 'KM awal & foto kondisi peminjaman #212 diperbarui oleh peminjam (Sabaruddin)', '2026-10-14 07:18:22'),
(752, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: Perjalanan Dinas-Meulaboh', '2026-10-14 07:50:13'),
(753, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Syarwani', 'Loan Request', 'Mengajukan peminjaman Toyota Rush 1,5 S M/T GR SPORT (BL 1670 AZH) — Ke Banda Aceh Jemput Tim External Audit', '2026-10-14 07:51:50'),
(754, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Jemput bokar ke aceh Jaya', '2026-10-14 09:09:13'),
(755, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Edited', 'KM awal & foto kondisi peminjaman #214 diperbarui oleh peminjam (Yogie Aditya Pratama)', '2026-10-14 09:09:45'),
(756, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Rahmatillah', 'Loan Request', 'Mengajukan peminjaman Honda CRF T4G02T31L0 M/T (BL 6613 EAW) — Perjalanan pengantaran stempel PBS ke DLH Kab. Aceh Barat', '2026-10-14 10:37:21'),
(757, 28, 'BL 6613 EAW', 'Honda CRF T4G02T31L0 M/T', 'Rahmatillah', 'Loan Approved', 'Honda CRF T4G02T31L0 M/T — peminjaman disetujui untuk kegiatan: Perjalanan pengantaran stempel PBS ke DLH Kab. Aceh Barat', '2026-10-14 10:38:44'),
(758, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Jemput bokar ke aceh Jaya', '2026-10-14 10:38:47'),
(759, 26, 'BL 1670 AZH', 'Toyota Rush 1,5 S M/T GR SPORT', 'Syarwani', 'Loan Approved', 'Toyota Rush 1,5 S M/T GR SPORT — peminjaman disetujui untuk kegiatan: Ke Banda Aceh Jemput Tim External Audit', '2026-10-14 10:39:00'),
(760, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Sabaruddin', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Sabaruddin, KM akhir 25.084, isi BBM Pertamax 3,1 L', '2026-10-14 12:01:54'),
(761, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — perbaikan rekening terblokir di BSI Meulaboh', '2026-10-14 12:30:56'),
(762, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: perbaikan rekening terblokir di BSI Meulaboh', '2026-10-14 12:31:18'),
(763, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Completed', 'Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — dikembalikan oleh Yogie Aditya Pratama, KM akhir 5.833', '2026-10-14 16:08:32'),
(764, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 25.156', '2026-10-14 16:27:47'),
(765, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Request', 'Mengajukan peminjaman Toyota Hilux Rangga High 2.0 M/T (BL 1672 AZH) — Hunting bokar ke pante kuyun', '2026-10-17 14:36:59'),
(766, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Request', 'Mengajukan peminjaman HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — belanja ke meulaboh', '2026-10-18 13:33:46'),
(767, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Approved', 'HONDA VARIO 160 X1H02N32L1 A/T — peminjaman disetujui untuk kegiatan: belanja ke meulaboh', '2026-10-18 13:41:13'),
(768, 25, 'BL 1672 AZH', 'Toyota Hilux Rangga High 2.0 M/T', 'Yogie Aditya Pratama', 'Loan Approved', 'Toyota Hilux Rangga High 2.0 M/T — peminjaman disetujui untuk kegiatan: Hunting bokar ke pante kuyun', '2026-10-18 13:41:16'),
(769, 29, 'BL 6612 EAW', 'HONDA VARIO 160 X1H02N32L1 A/T', 'Hanifah Hanifah', 'Loan Completed', 'HONDA VARIO 160 X1H02N32L1 A/T (BL 6612 EAW) — dikembalikan oleh Hanifah Hanifah, KM akhir 25.264', '2026-10-19 07:52:48');

-- --------------------------------------------------------

--
-- Struktur dari tabel `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `nik` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `division` varchar(100) NOT NULL DEFAULT 'Umum'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `employees`
--

INSERT INTO `employees` (`id`, `name`, `nik`, `email`, `division`) VALUES
(1, 'Abdul Karim', 'PBS022509232', 'abdulkarim.it26@gmail.com', 'IT Supervisor'),
(2, 'Adi Mujakir', 'PBS022507210', 'adimujakir404@gmail.com', 'Operator Bubut, Las'),
(3, 'Ahlun Nazar', 'PBS027', 'ahlun.teknik@gmail.com', 'Mat Stock Warehouse Spv'),
(4, 'Amri', 'PBS 034', 'amridarulhuda07@gmail.com', 'Humas'),
(5, 'Angga Fachreza', 'PBS022507223', 'anggafachreza07@gmail.com', 'Quality Control Staff'),
(6, 'Aprizal Lesmana', 'PBS022511270', 'aprizallesmana95@gmail.com', 'Analist Laboratorium'),
(7, 'Arwi Said', 'PBS022508230', 'arwiaww@gmail.com', 'Staff Warehouse'),
(8, 'Bagus Julianto', 'PBS022508231', 'juliantobagus400@gmail.com', 'DRC Man / Juru Taksir'),
(9, 'Bambang Sebastiar', 'PBS 016', 'bambangs@potensibumisakti.co.id', 'Manager HRGA (Site)'),
(10, 'Bowo F Frandhika', 'PBS025', 'bowofrandhika@gmail.com', 'Spv Produksi'),
(11, 'Desrika Putri Ramadhani', 'PBS022508229', 'desrikambo77@gmail.com', 'Admin Workshop'),
(12, 'Donny Marta', 'PBS024', 'donnymarta3108@gmail.com', 'Spv Produksi'),
(13, 'Edward Bangun', 'PBS023', 'bangunedward@outlook.co.id', 'Production Manager'),
(14, 'Fahlul Masri', 'PBS016', 'fahlul.masri@gmail.com', 'Spv HSE'),
(15, 'Fajrawi', 'PBS022511269', 'fjrhsy@gmail.com', 'Analist Laboratorium'),
(16, 'Fatwa Namora Ritonga', 'PBS022511273', 'fatwanamorar@gmail.com', 'Analist Laboratorium'),
(17, 'Fauzi', 'PBS022507190', 'fauziglee11@gmail.com', 'Admin Produksi'),
(18, 'Fitriani', 'PBS022507222', 'cutfitriani1407@gmail.com', 'Quality Control Staff'),
(19, 'Hanifah Hanifah', 'PBS017', 'hanifah22022000@gmail.com', 'Spv Raw. Mat'),
(20, 'Harris Fadhilla Said', 'PBS018', 'saidharits97@gmail.com', 'Spv Laboratorium'),
(21, 'Khairuddin', 'PBS 025', 'khairudin012020@gmail.com', 'Mandor Listrik'),
(22, 'Lisdayanti', 'PBS022507217', 'lisdayantimbo@gmail.com', 'Enviro Staff'),
(23, 'Mahajir Surja', 'PBS022507208', 'mahajirkerja345@gmail.com', 'Analist Laboratorium'),
(24, 'mahdy', 'PBS 021', 'pdmahdi1@gmail.com', 'Driver'),
(25, 'Marliza', 'PBS022507214', 'marlizamarliza001@gmail.com', 'Operator Forklift'),
(26, 'Mohd. Ersan Peruka', 'PBS022', 'ersan.peruka@gmail.com', 'Spv Qualty Control'),
(27, 'Nizam Sutrisno', 'PBS022511271', 'nizamnizam1342@gmail.com', 'Mandor Mekanik'),
(28, 'Novi Ramadhani', 'PBS022507216', 'novi.nm0807@gmail.com', 'Analist Laboratorium'),
(29, 'Nugroho Yulianto', 'PBS022511274', 'gronug@gmail.com', 'FG Warehouse & Export Spv'),
(30, 'Rahmatillah', 'PBS022507218', 'rahmatillahrusli@gmail.com', 'Effluent Staff'),
(31, 'Ratna Dewi', 'PBS022507205', 'ratnadewi9920@gmail.com', 'Admin Quality Control'),
(32, 'Ridwantoro', 'PBS022510261', 'ridwantoro459@gmail.com', 'Mandor Traksi'),
(33, 'Rimada Natanegara', 'PBS022604278', 'madakesuma@gmail.com', 'HRGA Spv'),
(34, 'Romantika Romantika', 'PBS019', 'romantika.rt48@gmail.com', 'Spv Maintenance'),
(35, 'Rudi Hartono Kurniawan', 'PBS 017', 'rudi@potensibumisakti.co.id', 'Manager Pabrik'),
(36, 'Rusmanto', 'PBS022507211', 'rusmantoelektrik@gmail.com', 'Kepala Teknisi'),
(37, 'Sabaruddin', 'PBS 018', 'sabaruddin@arsari.co.id', 'Kepala Tata Usaha (KTU)'),
(38, 'Siti Utari Amaranggana', 'PBS022507209', 'sitiutari980@gmail.com', 'Admin Laboratorium'),
(39, 'Suhaimi Ardinata', 'PBS 035', 'ardinatasuhaimi@gmail.com', 'Staff Admin'),
(40, 'Supianto Supianto', 'PBS01260126', 'supianto488@gmail.com', 'Chief Security'),
(41, 'Surya Ramadhan', 'PBS 020', 'suryaramadan000@gmail.com', 'Driver'),
(42, 'Susanti', 'PBS 022', 'susantiyanti0506@gmail.com', 'Office Girl'),
(43, 'Syarwani', 'PBS022608286', 'hrga.pbs@arsari.co.id', 'HRGA Officer'),
(44, 'T. Nyak The', 'PBS 026', 'tnyak676@gmail.com', 'Security'),
(45, 'Teuku Safril Nizam TM', 'PBS022511275', 'tsafrilnizam@gmail.com', 'Procurement/Purchasing Site Spv'),
(46, 'Tri Handiyanto', 'PBS022511272--', 'hrgaptpbs@gmail.com', 'Operator Genset'),
(47, 'Wina Rahayu', 'PBS022508233', 'winarahayu567.z@gmail.com', 'Admin Timbang'),
(48, 'Yasro S.E', 'PBS022606038', 'yasroyas@gmail.com', 'Manager Pembelian Bokar'),
(49, 'Yogie Aditya Pratama', 'PBS022608284', 'hrgaptpbs@gmail.com', 'RM'),
(50, 'Teuku Arib Multazam', 'PBS022608285', 'teukuriprip@gmail.com', 'RAW MAT');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fuel_fillings`
--

CREATE TABLE `fuel_fillings` (
  `id` int(11) NOT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `vehicle_id` int(11) NOT NULL,
  `pic_name` varchar(100) NOT NULL,
  `liter_amount` decimal(10,2) NOT NULL,
  `price_per_liter` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `fuel_type` enum('Pertalite','Pertamax','Solar','Dex') NOT NULL DEFAULT 'Pertalite',
  `location_or_receipt` varchar(255) DEFAULT NULL,
  `receipt_photo` varchar(255) DEFAULT NULL,
  `approver_name` varchar(100) DEFAULT NULL,
  `approver_signature` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `fuel_fillings`
--

INSERT INTO `fuel_fillings` (`id`, `loan_id`, `vehicle_id`, `pic_name`, `liter_amount`, `price_per_liter`, `total_price`, `fuel_type`, `location_or_receipt`, `receipt_photo`, `approver_name`, `approver_signature`, `created_at`) VALUES
(2, 24, 26, 'Abdul Karim', 15.39, 13000, 200000, 'Pertalite', 'Pertamini reusak', NULL, 'Bambang Sebastiar', NULL, '2026-07-29 18:48:06'),
(3, 28, 30, 'mahdy', 50.00, 16650, 832500, 'Pertamax', 'SPBU Manekro', 'uploads/fuel/fuel_6a6ad4ed73210_310.jpg', 'Bambang Sebastiar', NULL, '2026-07-30 11:37:01'),
(4, 33, 29, 'Hanifah Hanifah', 3.00, 16700, 50100, 'Pertamax', 'manek ro', 'uploads/fuel/fuel_6a6b3bcce4be7_248.jpg', NULL, NULL, '2026-07-30 18:55:56'),
(5, 37, 26, 'Mohd. Ersan Peruka', 23.08, 13000, 3000000, 'Pertalite', 'Eceran', 'uploads/fuel/fuel_6a6c5e47ba7c3_913.jpg', NULL, NULL, '2026-07-31 15:35:19'),
(6, 34, 25, 'mahdy', 36.76, 6800, 249968, 'Solar', 'SPBU SUAK RAYA', 'uploads/fuel/fuel_6a6c5f1425da8_101.jpg', 'Yoga', NULL, '2026-07-31 15:38:44'),
(7, 40, 29, 'Hanifah Hanifah', 4.61, 16300, 75143, 'Pertamax', 'SPBU SUAK RAYA', 'uploads/fuel/fuel_6a6f2f308835e_331.jpg', NULL, NULL, '2026-08-02 18:51:12'),
(8, 44, 30, 'mahdy', 29.45, 16300, 480035, 'Pertamax', 'Meurebo', 'uploads/fuel/fuel_6a72bd6c71100_206.jpg', 'Yoga', NULL, '2026-08-05 11:34:52'),
(9, 39, 26, 'Bowo F Frandhika', 16.70, 12000, 200400, 'Pertalite', 'Pertamini di Toko dua bersaudara', 'uploads/fuel/fuel_6a7534e5cacf7_842.jpg', 'Bambang Sebastiar', NULL, '2026-08-07 08:29:09'),
(10, 46, 31, 'mahdy', 29.41, 6800, 199988, 'Solar', 'SPBU Manek RO', 'uploads/fuel/fuel_6a753501c6dd7_510.jpg', 'Yoga', NULL, '2026-08-07 08:29:37'),
(11, 49, 26, 'Abdul Karim', 15.40, 13000, 200200, 'Pertalite', 'Pertamini glee siblah', 'uploads/fuel/fuel_6a75f662cafaa_581.jpg', 'Bambang Sebastiar', NULL, '2026-08-07 22:14:42'),
(12, 53, 29, 'Sabaruddin', 3.07, 16300, 50041, 'Pertamax', 'SPBU Suak Raya', NULL, NULL, NULL, '2026-08-10 12:18:52'),
(13, 54, 25, 'Nugroho Yulianto', 15.50, 13000, 201500, 'Pertalite', 'Pertamini Darul Huda', 'uploads/fuel/fuel_6a7994824b01b_480.jpg', 'Yoga', NULL, '2026-08-10 16:06:10'),
(14, 55, 25, 'Syukurdi Putra Yoga', 15.40, 13000, 200200, 'Pertalite', 'Pertamini', 'uploads/fuel/fuel_6a7ac2a9ca76d_120.jpg', 'Yoga', NULL, '2026-08-11 13:35:21'),
(15, 57, 31, 'Surya Ramadhan', 20.00, 14000, 280000, 'Solar', 'Eceran di Kuala Bhee', 'uploads/fuel/fuel_6a7ad1b8ea95c_412.jpg', 'Yoga', NULL, '2026-08-11 14:39:36'),
(16, 59, 25, 'Nugroho Yulianto', 15.39, 13000, 200070, 'Pertalite', 'layung', 'uploads/fuel/fuel_6a7d15a44cc08_239.jpg', NULL, NULL, '2026-08-13 07:53:56'),
(17, 61, 26, 'Bowo F Frandhika', 7.70, 13000, 100100, 'Pertalite', 'Pertamini', NULL, 'Bambang sebastiar', NULL, '2026-08-14 10:46:08'),
(18, 65, 29, 'Hanifah Hanifah', 3.07, 16300, 50041, 'Pertamax', 'manek ro', 'uploads/fuel/fuel_6a7f095a86ad2_798.jpg', NULL, NULL, '2026-08-14 19:26:02'),
(19, 67, 31, 'Syukurdi Putra Yoga', 25.00, 12000, 300000, 'Solar', 'Enceran', 'uploads/fuel/fuel_6a8009e0dd810_978.jpg', 'Yoga', NULL, '2026-08-15 13:40:32'),
(20, 64, 29, 'Hanifah Hanifah', 3.07, 16300, 50041, 'Pertamax', 'manek ro', 'uploads/fuel/fuel_6a800e480d0f4_207.jpg', NULL, NULL, '2026-08-15 13:59:20'),
(21, 69, 29, 'Hanifah Hanifah', 2.16, 16300, 35208, 'Pertamax', 'suak raya', 'uploads/fuel/fuel_6a83bca474c77_843.jpg', NULL, NULL, '2026-08-18 09:00:04'),
(22, 71, 31, 'mahdy', 29.42, 6800, 200056, 'Solar', 'Manek Ro', 'uploads/fuel/fuel_6a83ddcd869b3_634.jpg', 'Yoga', NULL, '2026-08-18 11:21:33'),
(23, 70, 25, 'Surya Ramadhan', 15.38, 13000, 199940, 'Pertalite', 'Pertamini Eceran', 'uploads/fuel/fuel_6a84043bd6c33_257.jpg', 'Yoga', NULL, '2026-08-18 14:05:31'),
(24, 72, 27, 'Nugroho Yulianto', 13.34, 15000, 200100, 'Solar', 'Enceran Kuala Bhee', 'uploads/fuel/fuel_6a8509d8d2444_989.jpg', 'Yoga', NULL, '2026-08-19 08:41:44'),
(25, 81, 26, 'Teuku Safril Nizam TM', 3.84, 13000, 49920, 'Pertalite', 'Seunebok', 'uploads/fuel/fuel_6a880126a7e5b_825.jpg', NULL, NULL, '2026-08-21 14:41:26'),
(26, 83, 29, 'Hanifah Hanifah', 3.07, 16300, 50041, 'Pertamax', 'suak raya', 'uploads/fuel/fuel_6a881e42895b6_222.jpg', NULL, NULL, '2026-08-21 16:45:38'),
(27, 88, 29, 'Hanifah Hanifah', 2.77, 16300, 45151, 'Pertamax', NULL, 'uploads/fuel/fuel_6a8991ea94396_792.jpg', NULL, NULL, '2026-08-22 19:11:22'),
(28, 86, 26, 'Surya Ramadhan', 30.67, 16300, 499921, 'Pertamax', 'SPBU LAMNO', 'uploads/fuel/fuel_6a8bd2a8a9a83_836.jpg', 'Yoga', NULL, '2026-08-24 12:12:08'),
(29, 95, 29, 'Hanifah Hanifah', 3.07, 16300, 50041, 'Pertamax', 'suak raya', 'uploads/fuel/fuel_6a902fdd5a621_295.jpg', NULL, NULL, '2026-08-27 19:38:53'),
(30, 93, 26, 'Syukurdi Putra Yoga', 15.38, 13000, 199940, 'Pertalite', NULL, 'uploads/fuel/fuel_6a91350b7df37_730.jpg', 'Yoga', NULL, '2026-08-28 14:13:15'),
(31, 99, 28, 'Nugroho Yulianto', 3.67, 16300, 59821, 'Pertamax', 'suak raya', 'uploads/fuel/fuel_6a9409034b343_645.jpg', NULL, NULL, '2026-08-30 17:42:11'),
(32, 102, 29, 'Hanifah Hanifah', 2.16, 16300, 35208, 'Pertamax', 'manek ro', 'uploads/fuel/fuel_6a956daf1b603_239.jpg', NULL, NULL, '2026-08-31 19:03:59'),
(33, 120, 29, 'Hanifah Hanifah', 3.07, 16300, 50041, 'Pertamax', 'suak raya', 'uploads/fuel/fuel_6a9c18432cf7b_415.jpg', NULL, NULL, '2026-09-05 20:25:23'),
(34, 143, 29, 'Hanifah Hanifah', 3.69, 16300, 60147, 'Pertamax', 'manek roo', 'uploads/fuel/fuel_6aa54a95a9443_101.jpg', NULL, NULL, '2026-09-12 19:50:29'),
(35, 149, 28, 'Teuku Arib Multazam', 1.22, 16300, 19886, 'Pertamax', 'Pertashop desa deuah jln meulaboh-kuala bhee', NULL, NULL, NULL, '2026-09-14 15:07:03'),
(36, 156, 29, 'Sabaruddin', 4.00, 16300, 65200, 'Pertamax', 'SPBU Kuta Padang', 'uploads/fuel/fuel_6aaa5f0dd70db_168.jpg', NULL, NULL, '2026-09-16 16:19:09'),
(37, 165, 29, 'Hanifah Hanifah', 3.07, 16300, 50041, 'Pertamax', 'suak raya', 'uploads/fuel/fuel_6ab081a01d90b_269.jpg', NULL, NULL, '2026-09-21 08:00:16'),
(38, 168, 29, 'Sabaruddin', 2.77, 16300, 45151, 'Pertamax', 'SPBU Suak Raya', 'uploads/fuel/fuel_6ab0f2f4a9004_884.jpg', NULL, NULL, '2026-09-21 16:03:48'),
(39, 180, 29, 'Hanifah Hanifah', 2.77, 16300, 45151, 'Pertamax', 'SPBU Suak Raya', 'uploads/fuel/fuel_6ab8efc63e80d_181.jpg', NULL, NULL, '2026-09-27 17:28:22'),
(40, 181, 26, 'Fahlul Masri', 7.70, 13000, 100100, 'Pertalite', 'SPBU mini/lokal', 'uploads/fuel/fuel_6aba15cb20fb0_407.jpg', NULL, NULL, '2026-09-28 14:22:51'),
(41, 185, 29, 'Hanifah Hanifah', 1.85, 16300, 30155, 'Pertamax', 'SPBU SUAK RAYA', NULL, NULL, NULL, '2026-09-30 20:06:22'),
(42, 187, 26, 'Abdul Karim', 15.39, 13000, 200070, 'Pertalite', 'Pertamini reusak', 'uploads/fuel/fuel_6abf0c38ecb52_138.jpg', 'Bambang Sebastiara', NULL, '2026-10-02 08:43:20'),
(43, 194, 29, 'Hanifah Hanifah', 1.54, 16300, 25102, 'Pertamax', 'MANEK ROO', NULL, NULL, NULL, '2026-10-04 15:52:06'),
(44, 192, 25, 'Sabaruddin', 30.77, 13000, 400010, 'Pertalite', 'Pertamini SP Kuwait', NULL, NULL, NULL, '2026-10-04 17:51:26'),
(45, 197, 26, 'Bowo F Frandhika', 15.39, 13000, 200070, 'Pertalite', 'Pertamini reusak', 'uploads/fuel/fuel_6ac452d06a1c5_518.jpg', NULL, NULL, '2026-10-06 08:45:52'),
(46, 199, 29, 'Sabaruddin', 4.30, 16300, 70090, 'Pertamax', 'SPBU Suak Raya', NULL, NULL, NULL, '2026-10-07 11:23:27'),
(47, 208, 29, 'Hanifah Hanifah', 1.85, 16300, 30155, 'Pertamax', NULL, 'uploads/fuel/fuel_6acb0b909f4ab_556.jpg', NULL, NULL, '2026-10-11 11:07:44'),
(48, 212, 29, 'Sabaruddin', 3.07, 16300, 50041, 'Pertamax', 'Pertashop Deah', 'uploads/fuel/fuel_6acf0cc2a5e65_443.jpg', NULL, NULL, '2026-10-14 12:01:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ga_users`
--

CREATE TABLE `ga_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `ga_users`
--

INSERT INTO `ga_users` (`id`, `username`, `password`, `name`, `phone`, `email`) VALUES
(4, 'syarwani', '$2y$10$.gcsopfQ.oLVgT.sdo8RIOwYI50LHOw19rGNWweBUjqtpEsrwCDc.', 'Syarwani (GA)', '082165645355', 'hrd.pbs@arsari.co.id'),
(5, 'rimada', '$2y$10$kVAMfYDUO2pJ9UbO/RXnMOlHZJCAJ8Aufal6QRrOeCtLZWQ7eWGBK', 'Rimada Natanegara (GA)', '085260508490', 'rimada.natanegara@arsari.co.id'),
(6, 'admin', '$2y$10$4YfEExO53TUWyHMYHETo4eqY9wsMm1/.rJpNZcqCDIPmicOeyyBRm', 'Manager Humas', '082119962291', 'bambang.sebastiar@arsari.co.id');

-- --------------------------------------------------------

--
-- Struktur dari tabel `loans`
--

CREATE TABLE `loans` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `pic_name` varchar(100) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `driver_status` varchar(50) NOT NULL DEFAULT 'Bawa Sendiri',
  `initial_km` int(11) NOT NULL DEFAULT 0,
  `final_km` int(11) DEFAULT NULL,
  `return_notes` text DEFAULT NULL,
  `return_photos` text DEFAULT NULL,
  `photos` text DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected','Completed') NOT NULL DEFAULT 'Pending',
  `returned_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `loans`
--

INSERT INTO `loans` (`id`, `vehicle_id`, `employee_id`, `pic_name`, `purpose`, `start_time`, `end_time`, `driver_status`, `initial_km`, `final_km`, `return_notes`, `return_photos`, `photos`, `status`, `returned_at`, `created_at`) VALUES
(23, 26, 43, 'Syukurdi Putra Yoga', 'Cari makan ke kuala beh bersama teman teman', '2026-07-29 12:07:00', '2026-07-29 13:00:00', 'Supir: Pak Mada', 3211, 3230, 'Kondisi baik, minyak tingal sedikit', '[\"uploads\\/returns\\/return_6a69a070ee075_281.jpg\",\"uploads\\/returns\\/return_6a69a070ee445_983.jpg\"]', '[\"uploads\\/loans\\/loan_6a698b5fa6dd3_867.jpg\",\"uploads\\/loans\\/loan_6a698b5fa73df_369.jpg\"]', 'Completed', '2026-07-29 13:40:48', '2026-07-29 12:10:55'),
(24, 26, 1, 'Abdul Karim', 'Ke meulaboh, ke kimia farma antar pak bowo sakit', '2026-07-29 13:50:00', '2026-07-29 16:00:00', 'Bawa Sendiri', 3231, 3313, 'Baik dan sudah diisi bensin', '[\"uploads\\/returns\\/return_6a69e876883f1_539.jpg\"]', NULL, 'Completed', '2026-07-29 18:48:06', '2026-07-29 13:51:36'),
(28, 30, 24, 'mahdy', 'Isi Minyak di SPBU Manekro', '2026-07-30 08:45:00', '2026-07-30 11:30:00', 'Bawa Sendiri', 79961, 80026, 'Sudah di isi minyak, dan dalam kondisi baik serta dapat digunakan kembali', '[\"uploads\\/returns\\/return_6a6ad4ed72abc_645.jpg\"]', '[\"uploads\\/loans\\/loan_6a6ad40546715_192.jpg\"]', 'Completed', '2026-07-30 11:37:01', '2026-07-30 11:33:09'),
(29, 26, 45, 'Teuku Safril Nizam TM', 'Beli nasi', '2026-07-30 12:04:00', '2026-07-30 12:45:00', 'Bawa Sendiri', 3313, 3329, 'Baik', '[\"uploads\\/returns\\/return_6a6b083cefc55_518.jpg\"]', '[\"uploads\\/loans\\/loan_6a6adbb6a8187_968.jpg\"]', 'Completed', '2026-07-30 15:15:56', '2026-07-30 12:05:58'),
(33, 29, 19, 'Hanifah Hanifah', 'belanja makanan', '2026-07-30 16:16:00', '2026-07-30 16:16:00', 'Bawa Sendiri', 21402, 21474, 'kondisi baik', '[\"uploads\\/returns\\/return_6a6b3bcce3d32_457.jpg\",\"uploads\\/returns\\/return_6a6b3bcce3fbb_806.jpg\"]', '[\"uploads\\/loans\\/loan_6a6b16c18b540_191.jpg\"]', 'Completed', '2026-07-30 18:55:56', '2026-07-30 16:17:53'),
(34, 25, 24, 'mahdy', 'Beli Minyak Solar', '2026-07-31 08:51:00', '2026-07-31 12:00:00', 'Bawa Sendiri', 107077, 107174, 'Mobil terparkir dengan rapi', '[\"uploads\\/returns\\/return_6a6c5f1425337_950.jpg\"]', '[\"uploads\\/loans\\/loan_6a6c000c19575_218.jpg\"]', 'Completed', '2026-07-31 15:38:44', '2026-07-31 08:53:16'),
(35, 29, 37, 'Sabaruddin', 'BSI Meulaboh', '2026-07-31 09:30:00', '2026-08-01 14:30:00', 'Bawa Sendiri', 21492, 21597, 'Baik', '[\"uploads\\/returns\\/return_6a6d4122a2a6a_601.jpg\"]', '[\"uploads\\/loans\\/loan_6a6c0bd77a0e1_273.jpg\"]', 'Completed', '2026-08-01 07:43:14', '2026-07-31 09:33:38'),
(37, 26, 26, 'Mohd. Ersan Peruka', 'Ke meulaboh', '2026-07-31 14:09:00', '2026-07-31 22:00:00', 'Bawa Sendiri', 3336, 3381, 'Baik minya sdh terisi 300ribu (eceran 13000 per liter)', '[\"uploads\\/returns\\/return_6a6c5e47b9fdd_563.jpg\"]', '[\"uploads\\/loans\\/loan_6a6c4a9b66ed1_850.jpg\"]', 'Completed', '2026-07-31 15:35:19', '2026-07-31 14:11:23'),
(39, 26, 10, 'Bowo F Frandhika', 'Ke meulaboh malam minggu perjaka mess', '2026-08-01 18:20:00', '2026-08-01 02:00:00', 'Bawa Sendiri', 3392, 3737, 'Baik', '[\"uploads\\/returns\\/return_6a7534e5ca289_242.jpg\"]', '[\"uploads\\/loans\\/loan_6a6dd6d13b383_617.jpg\"]', 'Completed', '2026-08-07 08:29:09', '2026-08-01 18:21:53'),
(40, 29, 19, 'Hanifah Hanifah', 'belanja kebutuhan pokok', '2026-08-02 12:06:00', '2026-08-02 12:06:00', 'Bawa Sendiri', 21606, 21685, 'baik', '[\"uploads\\/returns\\/return_6a6f2f3087cf3_145.jpg\"]', '[\"uploads\\/loans\\/loan_6a6ed0d4dba3c_866.jpg\",\"uploads\\/loans\\/loan_6a6ed0d4dbfd9_153.jpg\"]', 'Completed', '2026-08-02 18:51:12', '2026-08-02 12:08:36'),
(41, 29, 37, 'Sabaruddin', 'Belanja kebutuhan pokok/Kuala Bhee', '2026-08-03 16:00:00', '2026-08-03 18:00:00', 'Bawa Sendiri', 21687, 21726, 'Baik', '[\"uploads\\/returns\\/return_6a73011b5cb74_582.jpg\"]', '[\"uploads\\/loans\\/loan_6a7061070d8cf_496.jpg\"]', 'Completed', '2026-08-05 16:23:39', '2026-08-03 09:25:57'),
(42, 28, 1, 'Abdul Karim', 'Balek ke mess, dan mau jajan keluar', '2026-08-04 12:01:00', '2026-08-04 13:01:00', 'Bawa Sendiri', 15073, 15081, 'Baik, tapi minyak nya tinggal 1 bar', '[\"uploads\\/returns\\/return_6a7184d84d762_890.jpg\"]', NULL, 'Completed', '2026-08-04 13:21:12', '2026-08-04 12:02:41'),
(43, 28, 20, 'Harris Fadhilla Said', 'belanja', '2026-08-03 16:51:00', '2026-08-03 16:51:00', 'Bawa Sendiri', 15081, 15101, 'Bbm sedikit lagi', '[\"uploads\\/returns\\/return_6a71eff0024dc_655.jpg\"]', '[\"uploads\\/loans\\/loan_6a71b3dbdb776_545.jpg\"]', 'Completed', '2026-08-04 20:58:08', '2026-08-04 16:41:47'),
(44, 30, 24, 'mahdy', 'Service dan isi BBM', '2026-08-04 08:40:00', '2026-08-04 08:40:00', 'Bawa Sendiri', 80193, 80263, 'Baik', '[\"uploads\\/returns\\/return_6a72bd6c70937_976.jpg\"]', '[\"uploads\\/loans\\/loan_6a72bcaebfce0_389.jpg\"]', 'Completed', '2026-08-05 11:34:52', '2026-08-05 11:31:42'),
(45, 29, 37, 'Sabaruddin', 'Belanja kebutuhan pokok Kuala Bhee', '2026-08-05 16:21:00', '2026-08-06 08:30:00', 'Bawa Sendiri', 21726, 21727, 'Baik', '[\"uploads\\/returns\\/return_6a73095b4c13e_396.jpg\"]', '[\"uploads\\/loans\\/loan_6a730183a0725_428.jpg\"]', 'Completed', '2026-08-05 16:58:51', '2026-08-05 16:25:23'),
(46, 31, 24, 'mahdy', 'Antri Solar Hillux', '2026-08-06 08:33:00', '2026-08-06 12:00:00', 'Bawa Sendiri', 107990, 108053, 'Kondisi Baik dan BBM Tersedia', '[\"uploads\\/returns\\/return_6a753501c52ee_150.jpg\"]', '[\"uploads\\/loans\\/loan_6a73e6c4b4165_278.jpg\"]', 'Completed', '2026-08-07 08:29:37', '2026-08-06 08:43:32'),
(47, 29, 37, 'Sabaruddin', 'Belanja kebutuhan pokok Meulaboh', '2026-08-07 07:00:00', '2026-08-07 18:30:00', 'Bawa Sendiri', 21748, 21944, 'Baik dan bersih. Sudah dicuci oleh Pak Suhaimi', '[\"uploads\\/returns\\/return_6a767c2a8309b_512.jpg\"]', '[\"uploads\\/loans\\/loan_6a74513675548_803.jpg\"]', 'Completed', '2026-08-08 07:45:30', '2026-08-06 15:46:48'),
(48, 28, 1, 'Abdul Karim', 'Belanja', '2026-08-07 17:07:00', '2026-08-08 17:07:00', 'Bawa Sendiri', 15101, 15113, NULL, '[\"uploads\\/returns\\/return_6a792996d5f9e_755.jpg\"]', '[\"uploads\\/loans\\/loan_6a75aef79a1eb_967.jpg\"]', 'Completed', '2026-08-10 08:29:58', '2026-08-07 17:09:59'),
(49, 26, 1, 'Abdul Karim', 'Ke kualabhee belanja', '2026-08-07 19:56:00', '2026-08-07 22:56:00', 'Supir: Bowo Frandek', 3754, 3772, 'Baik, dan sudah di isi minyak', '[\"uploads\\/returns\\/return_6a75f662ca6d4_301.jpg\",\"uploads\\/returns\\/return_6a75f662ca8dc_941.jpg\"]', '[\"uploads\\/loans\\/loan_6a75d64971801_854.jpg\"]', 'Completed', '2026-08-07 22:14:42', '2026-08-07 19:57:45'),
(50, 25, 41, 'Surya Ramadhan', 'Belanja kebutuhan tamu dari HO, isi ulang air dll', '2026-08-08 08:50:00', '2026-08-08 12:00:00', 'Bawa Sendiri', 2527, 2637, 'Kondisi baik', '[\"uploads\\/returns\\/return_6a76f2cc9a6af_926.jpg\"]', '[\"uploads\\/loans\\/loan_6a768bd92daac_721.jpg\"]', 'Completed', '2026-08-08 16:11:40', '2026-08-08 08:52:25'),
(51, 29, 19, 'Hanifah Hanifah', 'belanja kebutuhan', '2026-08-08 15:31:00', '2026-08-08 15:31:00', 'Bawa Sendiri', 21950, NULL, NULL, NULL, '[\"uploads\\/loans\\/loan_6a76e99e6102a_400.jpg\"]', 'Rejected', NULL, '2026-08-08 15:32:30'),
(52, 31, 10, 'Bowo F Frandhika', 'Ke meulaboh, ke kimia farma', '2026-08-08 19:14:00', '2026-08-08 22:14:00', 'Supir: Ersan Peruka', 108191, 108265, 'Baik', '[\"uploads\\/returns\\/return_6a77f356d3a86_138.jpg\"]', '[\"uploads\\/loans\\/loan_6a771df143384_331.jpg\"]', 'Completed', '2026-08-09 10:26:14', '2026-08-08 19:15:45'),
(53, 29, 37, 'Sabaruddin', 'Belanja sembako Kuala Bhee', '2026-08-09 07:04:00', '2026-08-09 09:04:00', 'Bawa Sendiri', 22017, 22145, 'Baik dan bersih', '[\"uploads\\/returns\\/return_6a795f3c102e5_962.jpg\"]', '[\"uploads\\/loans\\/loan_6a77c90b9ba71_185.jpg\"]', 'Completed', '2026-08-10 12:18:52', '2026-08-09 07:06:18'),
(54, 25, 29, 'Nugroho Yulianto', 'Mobil dalam Keadaan Baik', '2026-08-10 14:19:00', '2026-08-10 15:20:00', 'Supir: Maulidi Finish Good', 2638, 2652, 'Baik', '[\"uploads\\/returns\\/return_6a799482481c2_413.jpg\"]', '[\"uploads\\/loans\\/loan_6a797bef1cb8e_871.jpg\"]', 'Completed', '2026-08-10 16:06:10', '2026-08-10 14:21:19'),
(55, 25, 43, 'Syukurdi Putra Yoga', 'Beli nasi, makan malam tamu HO', '2026-08-10 16:03:00', '2026-08-10 16:03:00', 'Supir: Pak Mada', 2652, 2722, 'Baik', '[\"uploads\\/returns\\/return_6a7ac2a9c9920_388.jpg\"]', '[\"uploads\\/loans\\/loan_6a7994f4d8f7f_238.jpg\"]', 'Completed', '2026-08-11 13:35:21', '2026-08-10 16:08:04'),
(56, 29, 29, 'Nugroho Yulianto', 'belanja', '2026-08-10 16:42:00', '2026-08-10 16:42:00', 'Bawa Sendiri', 22168, 22186, 'baik', '[\"uploads\\/returns\\/return_6a79a9d2e37e6_206.jpg\"]', '[\"uploads\\/loans\\/loan_6a799d32caba7_715.jpg\"]', 'Completed', '2026-08-10 17:37:06', '2026-08-10 16:43:14'),
(57, 31, 41, 'Surya Ramadhan', 'Isi Minyak Hilux', '2026-08-11 13:35:00', '2026-08-11 15:37:00', 'Bawa Sendiri', 108394, 108406, 'Baik , minyak tersedia', '[\"uploads\\/returns\\/return_6a7ad1b8e9efb_981.jpg\"]', '[\"uploads\\/loans\\/loan_6a7ac56e0e02d_219.jpg\"]', 'Completed', '2026-08-11 14:39:36', '2026-08-11 13:47:10'),
(58, 29, 29, 'Nugroho Yulianto', 'berobat', '2026-08-12 16:12:00', '2026-08-12 16:12:00', 'Bawa Sendiri', 22205, NULL, NULL, NULL, '[\"uploads\\/loans\\/loan_6a7c3ac5b5ca2_368.jpg\"]', 'Rejected', NULL, '2026-08-12 16:20:05'),
(59, 25, 29, 'Nugroho Yulianto', 'berobat', '2026-08-12 17:01:00', '2026-08-12 22:01:00', 'Supir: Harris', 2794, 2869, 'baik', '[\"uploads\\/returns\\/return_6a7d15a44c148_114.jpg\"]', '[\"uploads\\/loans\\/loan_6a7c4492cb4b3_834.jpg\"]', 'Completed', '2026-08-13 07:53:56', '2026-08-12 17:01:54'),
(60, 26, 10, 'Bowo F Frandhika', 'Antar karyawan sakit ke puskesmas kuala bhee', '2026-08-13 13:03:00', '2026-08-13 15:05:00', 'Bawa Sendiri', 4807, 4903, NULL, '[\"uploads\\/returns\\/return_6a7e934894df0_478.jpg\"]', '[\"uploads\\/loans\\/loan_6a7d7b4c100e2_961.jpg\"]', 'Completed', '2026-08-14 11:02:16', '2026-08-13 15:07:40'),
(61, 26, 10, 'Bowo F Frandhika', 'Ke meulaboh, makan bareng sama HO', '2026-08-13 18:35:00', '2026-08-13 22:35:00', 'Bawa Sendiri', 4825, 4903, 'Baik dan sudah di isi minyak', '[\"uploads\\/returns\\/return_6a7e8f8001a30_915.jpg\",\"uploads\\/returns\\/return_6a7e8f8002225_918.jpg\"]', '[\"uploads\\/loans\\/loan_6a7dac7250ce7_815.jpg\"]', 'Completed', '2026-08-14 10:46:08', '2026-08-13 18:37:22'),
(62, 26, 46, 'Tri Handiyanto', 'Membawa karyawan ke pukesmas layung untuk berobat', '2026-08-14 11:04:00', '2026-08-14 11:04:00', 'Bawa Sendiri', 4903, 4925, 'Baik', '[\"uploads\\/returns\\/return_6a7ebec3dfee3_292.jpg\"]', '[\"uploads\\/loans\\/loan_6a7e93d51eced_613.jpg\"]', 'Completed', '2026-08-14 14:07:47', '2026-08-14 11:04:37'),
(63, 25, 3, 'Ahlun Nazar', 'Ke bubon', '2026-08-14 16:50:00', '2026-08-14 23:00:00', 'Bawa Sendiri', 3067, 3069, 'Baik', '[\"uploads\\/returns\\/return_6a7f47aadbd4c_219.jpg\"]', '[\"uploads\\/loans\\/loan_6a7ee6af2ab28_178.jpg\"]', 'Completed', '2026-08-14 23:51:54', '2026-08-14 16:58:07'),
(64, 29, 19, 'Hanifah Hanifah', 'beli makanan ke mbo', '2026-08-14 17:07:00', '2026-08-14 17:07:00', 'Bawa Sendiri', 22208, 22290, 'kondisi baik', '[\"uploads\\/returns\\/return_6a800e480c6fa_506.jpg\"]', '[\"uploads\\/loans\\/loan_6a7ee8183a91e_744.jpg\"]', 'Completed', '2026-08-15 13:59:20', '2026-08-14 17:04:08'),
(65, 29, 19, 'Hanifah Hanifah', 'beli makanan ke mbo', '2026-08-14 17:07:00', '2026-08-14 17:07:00', 'Bawa Sendiri', 22208, 22280, 'kondisi baik', '[\"uploads\\/returns\\/return_6a7f095a858e3_837.jpg\"]', '[\"uploads\\/loans\\/loan_6a7ee818f017d_826.jpg\"]', 'Completed', '2026-08-14 19:26:02', '2026-08-14 17:04:08'),
(66, 26, 10, 'Bowo F Frandhika', 'Makan diluar', '2026-08-14 20:30:00', '2026-08-14 20:30:00', 'Bawa Sendiri', 4925, 4941, 'Baik', '[\"uploads\\/returns\\/return_6a7f305719b3a_957.jpg\"]', '[\"uploads\\/loans\\/loan_6a7f189d3bb29_742.jpg\"]', 'Completed', '2026-08-14 22:12:23', '2026-08-14 20:31:09'),
(67, 31, 43, 'Syukurdi Putra Yoga', 'Isi BBM (Solar), belanja kebutuhan HUT RI ke 81', '2026-08-15 09:06:00', '2026-08-15 11:00:00', 'Dengan Driver', 108583, 108656, 'Minyak terisi dengan kondisi baik', '[\"uploads\\/returns\\/return_6a8009e0dcab0_431.jpg\"]', '[\"uploads\\/loans\\/loan_6a7fc9ff61b43_216.jpg\"]', 'Completed', '2026-08-15 13:40:32', '2026-08-15 09:07:59'),
(68, 29, 1, 'Abdul Karim', 'Beli makan di luar', '2026-08-16 10:48:00', '2026-08-16 17:48:00', 'Supir: Fahlul Masri', 123, 22345, 'Baik', '[\"uploads\\/returns\\/return_6a825633309a1_612.jpg\"]', NULL, 'Completed', '2026-08-17 07:30:43', '2026-08-16 10:51:29'),
(69, 29, 19, 'Hanifah Hanifah', 'ke dokter gigi, dan beli obat demam ke mbo.', '2026-08-17 08:00:00', '2026-08-17 08:00:00', 'Bawa Sendiri', 22350, 22460, 'kondisi baik', '[\"uploads\\/returns\\/return_6a83bca4742c5_112.jpg\"]', '[\"uploads\\/loans\\/loan_6a825d56cdf30_604.jpg\"]', 'Completed', '2026-08-18 09:00:04', '2026-08-17 08:01:10'),
(70, 25, 41, 'Surya Ramadhan', 'Belanja Kepeluran GA (Isi Ulang Galon, Jemput Barang Pak Safril dll) ke meulaboh', '2026-08-18 08:21:00', '2026-08-18 12:00:00', 'Bawa Sendiri', 3080, 3150, 'Kondisi Baik', '[\"uploads\\/returns\\/return_6a84043bd5c45_475.jpg\"]', '[\"uploads\\/loans\\/loan_6a83c9b005659_770.jpg\"]', 'Completed', '2026-08-18 14:05:31', '2026-08-18 09:55:44'),
(71, 31, 24, 'mahdy', 'Anti BBM Solar', '2026-08-18 09:58:00', '2026-08-18 12:00:00', 'Bawa Sendiri', 108874, 108939, 'BBM Solar tersedia dan kondisi mobil baik', '[\"uploads\\/returns\\/return_6a83ddcd860ff_532.jpg\"]', '[\"uploads\\/loans\\/loan_6a83ca82d4167_308.jpg\"]', 'Completed', '2026-08-18 11:21:33', '2026-08-18 09:59:14'),
(72, 27, 29, 'Nugroho Yulianto', 'Kegiatan antar plastik', '2026-08-18 09:59:00', '2026-08-18 12:00:00', 'Supir: Maulidi', 244425, 244457, 'Baik', '[\"uploads\\/returns\\/return_6a8509d8d1ce7_457.jpg\"]', '[\"uploads\\/loans\\/loan_6a83da0f40653_924.jpg\"]', 'Completed', '2026-08-19 08:41:44', '2026-08-18 11:05:35'),
(73, 29, 37, 'Sabaruddin', 'Kuala Bhee Belanja sembako', '2026-08-18 16:00:00', '2026-08-18 19:30:00', 'Bawa Sendiri', 22507, 22523, 'Baik', NULL, '[\"uploads\\/loans\\/loan_6a842449429eb_897.jpg\"]', 'Completed', '2026-08-19 08:40:26', '2026-08-18 12:12:48'),
(74, 25, 24, 'mahdy', 'Beli pipa air karena ada kebocoran pipa air di gudang mesin pompa dekat mess', '2026-08-18 14:28:00', '2026-08-18 17:00:00', 'Bawa Sendiri', 3152, 3232, 'Mobil dalam keadaan baik', NULL, NULL, 'Completed', '2026-08-18 16:35:40', '2026-08-18 14:31:07'),
(75, 28, 1, 'Abdul Karim', 'Mau nnton bola di seuneubok', '2026-08-18 16:39:00', '2026-08-19 08:34:00', 'Bawa Sendiri', 15182, 15221, 'Baik dan minyak masih full, tapi ban nya retak retak', '[\"uploads\\/returns\\/return_6a87a147b7765_842.jpg\",\"uploads\\/returns\\/return_6a87a147b790f_630.jpg\",\"uploads\\/returns\\/return_6a87a147b7a29_576.jpg\"]', '[\"uploads\\/loans\\/loan_6a87a1131786f_859.jpg\"]', 'Completed', '2026-08-21 07:52:23', '2026-08-18 16:40:35'),
(76, 29, 37, 'Sabaruddin', 'Kuala Bhee antar motor Donny Martha ke bengkel', '2026-08-19 11:20:00', '2026-08-19 21:39:00', 'Bawa Sendiri', 22523, 22535, 'Kondisi baik', '[\"uploads\\/returns\\/return_6a864a7da0a28_305.jpg\"]', NULL, 'Completed', '2026-08-20 07:29:49', '2026-08-19 08:41:43'),
(77, 27, 29, 'Nugroho Yulianto', 'Kegiatan Pengantaran Plastik', '2026-08-19 08:35:00', '2026-08-19 12:00:00', 'Supir: Maulidi', 244425, 244457, 'Kondisi Baik', '[\"uploads\\/returns\\/return_6a87c5a7da4f4_304.jpg\"]', '[\"uploads\\/loans\\/loan_6a85179d4370d_439.jpg\"]', 'Completed', '2026-08-21 10:27:35', '2026-08-19 09:40:29'),
(78, 29, 37, 'Sabaruddin', 'Belanja kebutuhan pokok Kuala Bhee', '2026-08-20 16:00:00', '2026-08-20 19:30:00', 'Bawa Sendiri', 22536, 22564, 'Kondisi baik, rem berdenyit', '[\"uploads\\/returns\\/return_6a879f2da6600_421.jpg\"]', '[\"uploads\\/loans\\/loan_6a86c4af4734f_119.jpg\"]', 'Completed', '2026-08-21 07:43:25', '2026-08-20 07:31:35'),
(79, 29, 37, 'Sabaruddin', 'Ibadah Jumat Kuala Bhee', '2026-08-21 12:00:00', '2026-08-21 18:32:00', 'Bawa Sendiri', 22564, 22574, 'Kondisi baik\n Ban depan miring. Habis satu sisi', '[\"uploads\\/returns\\/return_6a87eec64d699_524.jpg\"]', '[\"uploads\\/loans\\/loan_6a87dcbfa7abb_736.jpg\",\"uploads\\/loans\\/loan_6a87dcbfa7c56_892.jpg\",\"uploads\\/loans\\/loan_6a87dcbfa7d5d_762.jpg\"]', 'Completed', '2026-08-21 13:23:02', '2026-08-20 07:33:37'),
(80, 29, 37, 'Sabaruddin', 'Sama tiga antar ke jalur Travel', '2026-08-22 13:00:00', '2026-08-22 18:00:00', 'Bawa Sendiri', 22657, 22711, 'Kondisi baik', NULL, '[\"uploads\\/loans\\/loan_6a893cf83d437_613.jpg\"]', 'Completed', '2026-08-22 16:44:45', '2026-08-20 07:35:50'),
(81, 26, 45, 'Teuku Safril Nizam TM', 'Solat jumat', '2026-08-21 11:50:00', '2026-08-21 14:00:00', 'Bawa Sendiri', 5575, 5599, 'Baik', '[\"uploads\\/returns\\/return_6a880126a7176_866.jpg\"]', '[\"uploads\\/loans\\/loan_6a87d981930e4_861.jpg\"]', 'Completed', '2026-08-21 14:41:26', '2026-08-21 11:52:17'),
(82, 25, 48, 'Yasro S.E', 'Shalat jumat', '2026-08-21 10:55:00', '2026-08-21 10:55:00', 'Bawa Sendiri', 3264, 3270, 'Baik', NULL, '[\"uploads\\/loans\\/loan_6a87dc399e771_359.jpg\",\"uploads\\/loans\\/loan_6a87dc399e934_291.jpg\"]', 'Completed', '2026-08-21 14:51:14', '2026-08-21 12:03:53'),
(83, 29, 19, 'Hanifah Hanifah', 'ke bank bsi meulaboh', '2026-08-21 13:25:00', '2026-08-21 13:59:00', 'Bawa Sendiri', 22574, 22700, 'kondisi baik, ban motor depan belakang', '[\"uploads\\/returns\\/return_6a881e4288e94_733.jpg\"]', '[\"uploads\\/loans\\/loan_6a87eee82932f_653.jpg\"]', 'Completed', '2026-08-21 16:45:38', '2026-08-21 13:23:36'),
(84, 28, 14, 'Fahlul Masri', 'Beli makan malam', '2026-08-21 17:04:00', '2026-08-21 17:04:00', 'Bawa Sendiri', 1522, 15230, 'Kondisi baik', '[\"uploads\\/returns\\/return_6a88f1a29cbd2_432.jpg\"]', '[\"uploads\\/loans\\/loan_6a88232f51a10_473.jpg\"]', 'Completed', '2026-08-22 07:47:30', '2026-08-21 17:06:39'),
(85, 29, 12, 'Donny Marta', 'Belanja ke kuala bhee', '2026-08-21 17:22:00', '2026-08-21 19:22:00', 'Bawa Sendiri', 22642, 22655, 'Baik', '[\"uploads\\/returns\\/return_6a8843f5c79e6_793.jpg\"]', '[\"uploads\\/loans\\/loan_6a8843bccb7d3_758.jpg\"]', 'Completed', '2026-08-21 19:26:29', '2026-08-21 17:23:37'),
(86, 26, 41, 'Surya Ramadhan', 'Penjemputan Pak Bambang ke Bandara Iskandar Muda Banda Aceh', '2026-08-22 09:00:00', '2026-08-22 03:30:00', 'Bawa Sendiri', 5599, 6192, 'Baik', '[\"uploads\\/returns\\/return_6a8bd2a8a9020_755.jpg\"]', '[\"uploads\\/loans\\/loan_6a890a60f3067_832.jpg\"]', 'Completed', '2026-08-24 12:12:08', '2026-08-22 09:33:04'),
(87, 28, 29, 'Nugroho Yulianto', 'Belanja', '2026-08-22 13:19:00', '2026-08-23 16:22:00', 'Bawa Sendiri', 15230, 15316, NULL, '[\"uploads\\/returns\\/return_6a8b930e00242_994.jpg\"]', '[\"uploads\\/loans\\/loan_6a893fd285646_899.jpg\"]', 'Completed', '2026-08-24 07:40:46', '2026-08-22 13:21:06'),
(88, 29, 19, 'Hanifah Hanifah', 'beli makanan di meulaboh', '2026-08-22 17:15:00', '2026-08-22 17:15:00', 'Bawa Sendiri', 22711, 22775, 'kondisi ban botak blm ada perbaikan', '[\"uploads\\/returns\\/return_6a8991ea93d51_768.jpg\"]', '[\"uploads\\/loans\\/loan_6a8976df94762_397.jpg\"]', 'Completed', '2026-08-22 19:11:22', '2026-08-22 17:15:59'),
(89, 29, 12, 'Donny Marta', 'Belanja', '2026-08-23 13:50:00', '2026-08-23 17:30:00', 'Bawa Sendiri', 22775, 22786, 'Kondisi baik', NULL, NULL, 'Completed', '2026-08-23 16:45:27', '2026-08-23 13:39:24'),
(90, 29, 19, 'Hanifah Hanifah', 'ke meulaboh beli makan', '2026-08-24 16:01:00', '2026-08-25 16:11:00', 'Bawa Sendiri', 22790, 22856, 'ban masih blm diganti', '[\"uploads\\/returns\\/return_6a8c319d68933_676.jpg\"]', '[\"uploads\\/loans\\/loan_6a8bcfabb535f_952.jpg\"]', 'Completed', '2026-08-24 18:57:17', '2026-08-24 11:59:23'),
(91, 26, 36, 'Rusmanto', 'Kunjungan duka ke rumah karyawan team workshop', '2026-08-24 12:03:00', '2026-08-24 13:03:00', 'Bawa Sendiri', 6192, 6205, 'Baik', '[\"uploads\\/returns\\/return_6a8be5991466c_151.jpg\",\"uploads\\/returns\\/return_6a8be599148d6_368.jpg\"]', '[\"uploads\\/loans\\/loan_6a8bd41bb8853_284.jpg\"]', 'Completed', '2026-08-24 13:32:57', '2026-08-24 12:18:19'),
(92, 25, 41, 'Surya Ramadhan', 'Jemput Barang Warehouse (Pak Ahlun ) ke MBO', '2026-08-26 10:52:00', '2026-08-26 12:00:00', 'Bawa Sendiri', 3343, 3410, 'Baik', '[\"uploads\\/returns\\/return_6a8e890766f1f_338.jpg\"]', '[\"uploads\\/loans\\/loan_6a8e634a6a015_196.jpg\"]', 'Completed', '2026-08-26 13:34:47', '2026-08-26 10:53:46'),
(93, 26, 43, 'Syukurdi Putra Yoga', 'Belanja ke mbo dan ukur baju team RM an Arib dan Yogie', '2026-08-27 09:40:00', '2026-08-27 12:00:00', 'Supir: Arib', 6205, 6279, 'baik', '[\"uploads\\/returns\\/return_6a91350b7d815_877.jpg\"]', '[\"uploads\\/loans\\/loan_6a8fa44453e61_638.jpg\"]', 'Completed', '2026-08-28 14:13:15', '2026-08-27 09:43:16'),
(94, 29, 19, 'Hanifah Hanifah', 'beli makanan di meulaboh', '2026-08-27 16:19:00', '2026-08-27 16:19:00', 'Bawa Sendiri', 22862, 22865, 'Baik\'', NULL, '[\"uploads\\/loans\\/loan_6a90017a15531_906.jpg\"]', 'Completed', '2026-08-28 12:27:34', '2026-08-27 16:20:58'),
(95, 29, 19, 'Hanifah Hanifah', 'beli makanan di meulaboh', '2026-08-27 16:19:00', '2026-08-27 16:19:00', 'Bawa Sendiri', 22862, 22927, 'ban makin parah, harus segera diganti', '[\"uploads\\/returns\\/return_6a902fdd5965a_383.jpg\"]', '[\"uploads\\/loans\\/loan_6a90017b3f543_975.jpg\"]', 'Completed', '2026-08-27 19:38:53', '2026-08-27 16:20:59'),
(96, 29, 37, 'Sabaruddin', 'Sholat Jum\'at Glee Siblah', '2026-08-28 12:24:00', '2026-08-28 14:00:00', 'Bawa Sendiri', 22928, 22935, 'Kondisi baik tidak ada kerusakan', NULL, '[\"uploads\\/loans\\/loan_6a911e92bb1f3_222.jpg\"]', 'Completed', '2026-08-28 15:24:38', '2026-08-28 12:29:05'),
(97, 29, 37, 'Sabaruddin', 'Ke Loket Angkutan Umum antar kota', '2026-08-29 12:00:00', '2026-08-29 16:01:00', 'Bawa Sendiri', 22937, 22938, 'Kondisi baik. Batal pinjam karena menumpang dengan Khairuddin', NULL, NULL, 'Completed', '2026-08-29 12:45:46', '2026-08-29 09:03:18'),
(98, 29, 19, 'Hanifah Hanifah', 'kondisi baik', '2026-08-29 13:04:00', '2026-08-30 18:04:00', 'Bawa Sendiri', 22938, 22959, 'kondisi ban masih blm diganti', '[\"uploads\\/returns\\/return_6a94081943ffa_915.jpg\"]', '[\"uploads\\/loans\\/loan_6a9276ccd2d89_857.jpg\"]', 'Completed', '2026-08-30 17:38:17', '2026-08-29 13:06:04'),
(99, 28, 29, 'Nugroho Yulianto', 'berobat ke klinkin', '2026-08-29 08:42:00', '2026-08-29 08:42:00', 'Bawa Sendiri', 15318, 15450, NULL, '[\"uploads\\/returns\\/return_6a9409034a86d_101.jpg\"]', '[\"uploads\\/loans\\/loan_6a929a6174b63_744.jpg\"]', 'Completed', '2026-08-30 17:42:11', '2026-08-29 15:37:53'),
(100, 26, 10, 'Bowo F Frandhika', 'Ke mbo belanja', '2026-08-29 19:08:00', '2026-08-29 02:00:00', 'Bawa Sendiri', 6317, 6426, NULL, '[\"uploads\\/returns\\/return_6a962e3f57e2d_114.jpg\",\"uploads\\/returns\\/return_6a962e3f58338_755.jpg\"]', '[\"uploads\\/loans\\/loan_6a92cbf32ae0f_351.jpg\"]', 'Completed', '2026-09-01 08:45:35', '2026-08-29 19:09:23'),
(101, 28, 45, 'Teuku Safril Nizam TM', 'Beli nasi', '2026-08-31 11:56:00', '2026-08-31 12:00:00', 'Bawa Sendiri', 15450, 15469, 'Baik', '[\"uploads\\/returns\\/return_6a9636aec36c2_201.jpg\"]', '[\"uploads\\/loans\\/loan_6a9509dd3405b_845.jpg\"]', 'Completed', '2026-09-01 09:21:34', '2026-08-31 11:58:05'),
(102, 29, 19, 'Hanifah Hanifah', 'beli makan ke meulaboh', '2026-08-31 16:19:00', '2026-09-01 16:19:00', 'Bawa Sendiri', 22961, 23030, 'kondisi kurang baik, perlu pergantian ban', '[\"uploads\\/returns\\/return_6a956daf1a9ee_317.jpg\"]', '[\"uploads\\/loans\\/loan_6a95478d6f6b8_888.jpg\"]', 'Completed', '2026-08-31 19:03:59', '2026-08-31 16:21:17'),
(103, 29, 49, 'Yogie Aditya Pratama', 'Beli peralatan pribadi ke Indomaret', '2026-08-31 19:14:00', '2026-08-31 20:30:00', 'Bawa Sendiri', 23030, 23048, 'Baik', '[\"uploads\\/returns\\/return_6a95902546c7e_774.jpg\"]', '[\"uploads\\/loans\\/loan_6a9570a36ce20_508.jpg\",\"uploads\\/loans\\/loan_6a9570a36d8d1_747.jpg\"]', 'Completed', '2026-08-31 21:31:01', '2026-08-31 19:16:35'),
(110, 28, 1, 'Abdul Karim', 'Olahraga sore', '2026-09-01 16:13:00', '2026-09-01 19:13:00', 'Bawa Sendiri', 15469, 15485, 'Sudah dikembalikan', '[\"uploads\\/returns\\/return_6a981d7d6b518_660.jpg\"]', '[\"uploads\\/loans\\/loan_6a981d5ea7711_342.jpg\"]', 'Completed', '2026-09-02 19:58:37', '2026-09-01 11:13:36'),
(111, 29, 19, 'Hanifah Hanifah', 'beli makanan di mboo', '2026-09-01 16:12:00', '2026-09-02 16:12:00', 'Bawa Sendiri', 0, 23117, 'kondisi baik', '[\"uploads\\/returns\\/return_6a96b8b8c3c67_379.jpg\"]', NULL, 'Completed', '2026-09-01 18:36:24', '2026-09-01 16:12:30'),
(112, 26, 17, 'Fauzi', 'Antar karyawan sakit ke Puskesmas', '2026-09-02 10:04:00', '2026-09-02 10:04:00', 'Dengan Driver', 0, 6556, 'Dikembalikan dalam kondisi baik', '[\"uploads\\/returns\\/return_6a98dcbb60c39_499.jpg\"]', NULL, 'Completed', '2026-09-03 09:34:35', '2026-09-02 10:06:50'),
(113, 29, 49, 'Yogie Aditya Pratama', 'Beli keperluan pribadi', '2026-09-02 19:22:00', '2026-09-02 20:35:00', 'Bawa Sendiri', 23118, 23137, 'Baik', '[\"uploads\\/returns\\/return_6a982a9054bff_239.jpg\"]', '[\"uploads\\/loans\\/loan_6a9815753f3e0_587.jpg\"]', 'Completed', '2026-09-02 20:54:24', '2026-09-02 19:23:25'),
(114, 25, 37, 'Sabaruddin', 'Meulaboh', '2026-09-03 10:08:00', '2026-09-03 15:00:00', 'Dengan Driver', 0, 0, 'Batal', NULL, NULL, 'Completed', '2026-09-03 11:06:16', '2026-09-03 10:09:50'),
(115, 29, 37, 'Sabaruddin', 'Perjalanan Pribadi-Beli Obat ke Kuala Bhee', '2026-09-03 12:00:00', '2026-09-03 13:00:00', 'Bawa Sendiri', 23147, 23154, 'Konsumsi motor baik', '[\"uploads\\/returns\\/return_6a9912e29d4e7_852.jpg\"]', NULL, 'Completed', '2026-09-03 13:25:38', '2026-09-03 11:28:39'),
(116, 26, 29, 'Nugroho Yulianto', 'berobat', '2026-09-03 16:15:00', '2026-09-03 16:15:00', 'Supir: haris', 0, 6709, 'berobat', '[\"uploads\\/returns\\/return_6a9a1f34af81f_434.jpg\"]', NULL, 'Completed', '2026-09-04 08:30:28', '2026-09-03 16:15:54'),
(118, 29, 49, 'Yogie Aditya Pratama', 'Pembelian kebutuhan pribadi', '2026-09-04 17:00:00', '2026-09-04 18:01:00', 'Bawa Sendiri', 0, 0, 'Baik', '[\"uploads\\/returns\\/return_6a9a986b56181_838.jpg\"]', NULL, 'Completed', '2026-09-04 17:07:39', '2026-09-04 16:02:29'),
(119, 29, 1, 'Abdul Karim', 'Mau belanja', '2026-09-04 17:22:00', '2026-09-04 21:22:00', 'Bawa Sendiri', 23175, 23257, 'Baik', '[\"uploads\\/returns\\/return_6a9b6b6ecc18b_938.jpg\"]', '[\"uploads\\/loans\\/loan_6a9b6b54c610d_782.jpg\"]', 'Completed', '2026-09-05 08:07:58', '2026-09-04 17:23:41'),
(120, 29, 19, 'Hanifah Hanifah', 'beli kebutuhan makanan di mbo', '2026-09-05 13:08:00', '2026-09-06 13:08:00', 'Bawa Sendiri', 0, 23328, 'kondisi kurang sehat dari awal pemakaian. tali kipas & Ban depan belakang perlu pergantian. tadi sudah ke dealer untuk dilakukan perbaikan namun sudah full untuk hari sabtu ini.', '[\"uploads\\/returns\\/return_6a9c18432bb7b_892.jpg\"]', NULL, 'Completed', '2026-09-05 20:25:23', '2026-09-05 13:09:23'),
(121, 28, 49, 'Yogie Aditya Pratama', 'Belanja', '2026-09-05 14:00:00', '2026-09-05 15:09:00', 'Bawa Sendiri', 0, 15524, 'Baik', '[\"uploads\\/returns\\/return_6a9be3228a9ce_323.jpg\"]', NULL, 'Completed', '2026-09-05 16:38:42', '2026-09-05 13:10:34'),
(123, 29, 1, 'Abdul Karim', 'Beli makan', '2026-09-05 21:08:00', '2026-09-05 23:59:00', 'Bawa Sendiri', 23328, 23348, NULL, '[\"uploads\\/returns\\/return_6a9e2af61cc3c_567.jpg\"]', NULL, 'Completed', '2026-09-07 10:09:42', '2026-09-05 21:08:40'),
(125, 28, 49, 'Yogie Aditya Pratama', 'Kualabee', '2026-09-06 19:24:00', '2026-09-06 20:35:00', 'Bawa Sendiri', 0, 15543, 'Baik', '[\"uploads\\/returns\\/return_6a9d731926656_121.jpg\"]', NULL, 'Completed', '2026-09-06 21:05:13', '2026-09-06 19:25:32'),
(126, 29, 45, 'Teuku Safril Nizam TM', 'Beli makan', '2026-09-08 12:09:00', '2026-09-08 12:31:00', 'Bawa Sendiri', 23348, 23367, NULL, '[\"uploads\\/returns\\/return_6a9fcfe245168_795.jpg\"]', '[\"uploads\\/loans\\/loan_6a9fcfbe497c5_617.jpg\"]', 'Completed', '2026-09-08 16:05:38', '2026-09-08 12:10:29'),
(127, 26, 3, 'Ahlun Nazar', 'Mendampingi tim bwss 1 aceh', '2026-09-08 12:21:00', '2026-09-08 12:21:00', 'Bawa Sendiri', 0, 6899, 'Baik', NULL, NULL, 'Completed', '2026-09-08 16:15:09', '2026-09-08 12:23:18'),
(128, 29, 19, 'Hanifah Hanifah', 'beli makanann', '2026-09-08 16:07:00', '2026-09-09 16:07:00', 'Bawa Sendiri', 0, 23387, 'masih perlu perbaikan tali kipas', '[\"uploads\\/returns\\/return_6a9ffbfa77f0b_322.jpg\"]', NULL, 'Completed', '2026-09-08 19:13:46', '2026-09-08 16:08:40'),
(129, 28, 20, 'Harris Fadhilla Said', 'belanja', '2026-09-04 08:29:00', '2026-09-04 08:29:00', 'Bawa Sendiri', 0, 15562, 'Baik', '[\"uploads\\/returns\\/return_6aa0acd07638b_859.jpg\"]', NULL, 'Completed', '2026-09-09 07:48:16', '2026-09-08 16:31:41'),
(130, 26, 10, 'Bowo F Frandhika', 'Ke meulaboh, makan', '2026-09-08 19:23:00', '2026-09-08 23:23:00', 'Bawa Sendiri', 6899, 6969, NULL, '[\"uploads\\/returns\\/return_6aa0cf1494542_267.jpg\"]', '[\"uploads\\/loans\\/loan_6aa012a502916_572.jpg\"]', 'Completed', '2026-09-09 10:14:28', '2026-09-08 19:24:30'),
(131, 29, 37, 'Sabaruddin', 'Perjalanan pribadi-Puskesmas Kuala Bhee', '2026-09-09 09:00:00', '2026-09-09 11:09:00', 'Bawa Sendiri', 23388, NULL, NULL, NULL, NULL, 'Rejected', NULL, '2026-09-09 08:16:43'),
(132, 28, 49, 'Yogie Aditya Pratama', 'Belanja', '2026-09-09 16:09:00', '2026-09-09 17:30:00', 'Bawa Sendiri', 0, NULL, NULL, NULL, NULL, 'Rejected', NULL, '2026-09-09 16:09:48'),
(133, 28, 49, 'Yogie Aditya Pratama', 'Belanja', '2026-09-09 16:11:00', '2026-09-09 18:11:00', 'Bawa Sendiri', 0, 15581, 'Baik', '[\"uploads\\/returns\\/return_6aa13bc4c69dc_939.jpg\",\"uploads\\/returns\\/return_6aa13bc4c6bd8_941.jpg\"]', NULL, 'Completed', '2026-09-09 17:58:12', '2026-09-09 16:12:25'),
(134, 29, 19, 'Hanifah Hanifah', 'ganti karet behel ke mbo', '2026-09-10 16:07:00', '2026-09-11 15:19:00', 'Bawa Sendiri', 0, 23435, 'kondisi blm membaik, perlu perbaikan cvt, tali kipas & pergantian ban', '[\"uploads\\/returns\\/return_6aa35139580e5_601.jpg\"]', NULL, 'Completed', '2026-09-11 07:54:17', '2026-09-10 15:20:34'),
(135, 26, 20, 'Harris Fadhilla Said', 'berobat', '2026-09-10 17:08:00', '2026-09-10 17:08:00', 'Bawa Sendiri', 0, 7155, NULL, '[\"uploads\\/returns\\/return_6aa35031c324f_397.jpg\"]', NULL, 'Completed', '2026-09-11 07:49:53', '2026-09-10 17:09:08'),
(136, 26, 20, 'Harris Fadhilla Said', 'berobat', '2026-09-10 17:08:00', '2026-09-10 17:08:00', 'Bawa Sendiri', 0, 7155, NULL, '[\"uploads\\/returns\\/return_6aa4d3fa3bd2a_923.jpg\"]', NULL, 'Completed', '2026-09-12 11:24:26', '2026-09-10 17:09:10'),
(137, 28, 50, 'Teuku Arib Multazam', 'Visit Supplier', '2026-09-11 09:29:00', '2026-09-11 09:29:00', 'Bawa Sendiri', 0, 15635, 'Kondisi Baik', '[\"uploads\\/returns\\/return_6aa3cfa8668a8_699.jpg\"]', NULL, 'Completed', '2026-09-11 16:53:44', '2026-09-11 09:37:17'),
(138, 29, 49, 'Yogie Aditya Pratama', 'Sholat jumat', '2026-09-11 12:00:00', '2026-09-11 14:00:00', 'Bawa Sendiri', 0, NULL, NULL, NULL, NULL, 'Rejected', NULL, '2026-09-11 11:33:58'),
(139, 29, 1, 'Abdul Karim', 'Jum\'atan', '2026-09-11 11:54:00', '2026-09-11 13:54:00', 'Bawa Sendiri', 23435, 23453, NULL, NULL, NULL, 'Completed', '2026-09-11 14:10:48', '2026-09-11 11:55:31'),
(140, 29, 1, 'Abdul Karim', 'Belanja', '2026-09-11 17:22:00', '2026-09-11 22:22:00', 'Bawa Sendiri', 23453, 23460, NULL, '[\"uploads\\/returns\\/return_6aa4b1abc0e96_945.jpg\"]', '[\"uploads\\/loans\\/loan_6aa4b18cd8af3_510.jpg\"]', 'Completed', '2026-09-12 08:58:03', '2026-09-11 17:22:49'),
(141, 28, 49, 'Yogie Aditya Pratama', 'Belanja', '2026-09-11 19:02:00', '2026-09-11 21:02:00', 'Bawa Sendiri', 0, 15654, 'Baik', '[\"uploads\\/returns\\/return_6aa418dc3d029_698.jpg\"]', NULL, 'Completed', '2026-09-11 22:06:04', '2026-09-11 17:34:12'),
(142, 28, 50, 'Teuku Arib Multazam', 'Visit suplier', '2026-09-12 09:21:00', '2026-09-12 09:21:00', 'Bawa Sendiri', 0, 157, 'Baik dan tidak ada kerusakan', NULL, NULL, 'Completed', '2026-09-12 14:02:25', '2026-09-12 09:22:15'),
(143, 29, 19, 'Hanifah Hanifah', 'ganti karet behel dan beli makanan', '2026-09-12 13:21:00', '2026-09-13 17:21:00', 'Bawa Sendiri', 0, 23540, 'kondisi baik, sudah dilakukan perbaikan ganti tali kipas dan cvt di dealer. tinggal menunggu pergantian ban', '[\"uploads\\/returns\\/return_6aa54a95a88d6_764.jpg\"]', NULL, 'Completed', '2026-09-12 19:50:29', '2026-09-12 11:23:19'),
(144, 26, 1, 'Abdul Karim', 'Belanja sekaligus lihat anaknya anggota qc yang baru lahiran', '2026-09-12 13:09:00', '2026-09-12 18:09:00', 'Bawa Sendiri', 43983, 44723, NULL, '[\"uploads\\/returns\\/return_6aa7452fbf0da_424.jpg\"]', '[\"uploads\\/loans\\/loan_6aa544c43e467_124.jpg\"]', 'Completed', '2026-09-14 07:51:59', '2026-09-12 13:10:15'),
(145, 28, 49, 'Yogie Aditya Pratama', 'Kualabee', '2026-09-12 14:08:00', '2026-09-12 14:08:00', 'Bawa Sendiri', 0, 15717, 'Baik', '[\"uploads\\/returns\\/return_6aa76e1416ad0_190.jpg\"]', NULL, 'Completed', '2026-09-14 10:46:28', '2026-09-12 14:08:26'),
(146, 28, 29, 'Nugroho Yulianto', 'Belanja', '2026-09-13 16:06:00', '2026-09-13 20:00:00', 'Bawa Sendiri', 15735, 15754, 'Baik', '[\"uploads\\/returns\\/return_6aa68b2de9841_449.jpg\"]', '[\"uploads\\/loans\\/loan_6aa6680b4aa84_157.jpg\"]', 'Completed', '2026-09-13 18:38:21', '2026-09-13 16:07:34'),
(147, 26, 29, 'Nugroho Yulianto', 'ke medan', '2026-09-14 07:57:00', '2026-09-19 07:57:00', 'Dengan Driver', 44723, 60021, NULL, '[\"uploads\\/returns\\/return_6aacba41a71ba_733.jpg\"]', '[\"uploads\\/loans\\/loan_6aa746cc0ec47_244.jpg\"]', 'Completed', '2026-09-18 11:12:49', '2026-09-14 07:57:53'),
(148, 29, 43, 'Syarwani', 'Beli Mata Gerinda', '2026-09-14 10:15:00', '2026-09-14 11:15:00', 'Bawa Sendiri', 23560, 23581, 'Baik', '[\"uploads\\/returns\\/return_6aa7716a45db3_417.jpg\"]', '[\"uploads\\/loans\\/loan_6aa767513d479_241.jpg\"]', 'Completed', '2026-09-14 11:00:42', '2026-09-14 10:16:10'),
(149, 28, 50, 'Teuku Arib Multazam', 'Visit suplier', '2026-09-14 10:45:00', '2026-09-14 10:45:00', 'Bawa Sendiri', 157, 158, 'Kondisi baik', NULL, NULL, 'Completed', '2026-09-14 15:07:03', '2026-09-14 10:47:36'),
(150, 29, 49, 'Yogie Aditya Pratama', 'Kualabee', '2026-09-14 18:55:00', '2026-09-14 20:55:00', 'Bawa Sendiri', 23581, 23601, 'Baik', '[\"uploads\\/returns\\/return_6aa80a23975f2_369.jpg\"]', '[\"uploads\\/loans\\/loan_6aa8072472192_574.jpg\"]', 'Completed', '2026-09-14 21:52:19', '2026-09-14 18:55:53'),
(151, 29, 20, 'Harris Fadhilla Said', 'Dinner', '2026-09-14 21:15:00', '2026-09-14 22:15:00', 'Bawa Sendiri', 23601, 24542, NULL, '[\"uploads\\/returns\\/return_6abefc02621f3_157.jpg\"]', '[\"uploads\\/loans\\/loan_6aa80253be534_576.jpg\"]', 'Completed', '2026-10-02 07:34:10', '2026-09-14 21:17:55'),
(152, 28, 50, 'Teuku Arib Multazam', 'Visit suplier', '2026-09-15 10:03:00', '2026-09-15 10:03:00', 'Bawa Sendiri', 0, 15845, NULL, NULL, NULL, 'Completed', '2026-09-15 16:10:47', '2026-09-15 10:04:47'),
(153, 29, 43, 'Syarwani', 'Ke panglong kayu', '2026-09-15 09:03:00', '2026-09-15 11:15:00', 'Bawa Sendiri', 23622, 23643, 'Kondisi Baik', NULL, NULL, 'Completed', '2026-09-15 15:24:33', '2026-09-15 10:05:14'),
(154, 29, 19, 'Hanifah Hanifah', 'beli makanan ke meulaboh aceh barat', '2026-09-15 16:16:00', '2026-09-16 16:25:00', 'Bawa Sendiri', 0, 23645, 'kondisi baik', '[\"uploads\\/returns\\/return_6aa9ccee5b57b_206.jpg\"]', NULL, 'Completed', '2026-09-16 05:55:42', '2026-09-15 15:26:44'),
(155, 28, 1, 'Abdul Karim', 'Olahraga', '2026-09-15 16:10:00', '2026-09-15 20:10:00', 'Bawa Sendiri', 15845, 15869, NULL, '[\"uploads\\/returns\\/return_6aa9e966b9259_496.jpg\"]', '[\"uploads\\/loans\\/loan_6aa9e937edafb_121.jpg\"]', 'Completed', '2026-09-16 07:57:10', '2026-09-15 16:13:02'),
(156, 29, 37, 'Sabaruddin', 'Perjalanan Dinas BSI Meulaboh', '2026-09-16 10:47:00', '2026-09-16 16:00:00', 'Bawa Sendiri', 23647, 23717, 'Kondisi baik', NULL, '[\"uploads\\/loans\\/loan_6aaa241e7080f_103.jpg\"]', 'Completed', '2026-09-16 16:19:09', '2026-09-16 10:48:37'),
(157, 28, 49, 'Yogie Aditya Pratama', 'Kuala bee', '2026-09-16 16:05:00', '2026-09-16 18:30:00', 'Bawa Sendiri', 15888, 15907, 'Baik', '[\"uploads\\/returns\\/return_6aaa835425085_705.jpg\"]', '[\"uploads\\/loans\\/loan_6aaa6713b45e5_129.jpg\"]', 'Completed', '2026-09-16 18:53:56', '2026-09-16 11:23:35'),
(158, 28, 50, 'Teuku Arib Multazam', 'Visit suplier', '2026-09-17 10:31:00', '2026-09-17 10:31:00', 'Bawa Sendiri', 0, 159, 'Kondisi baik', NULL, NULL, 'Completed', '2026-09-17 16:25:08', '2026-09-17 10:32:11'),
(159, 29, 19, 'Hanifah Hanifah', 'ke meulaboh beli makanan', '2026-09-17 16:10:00', '2026-09-18 11:54:00', 'Bawa Sendiri', 0, 23746, 'kondisi baik', '[\"uploads\\/returns\\/return_6aac938e059d9_711.jpg\"]', NULL, 'Completed', '2026-09-18 08:27:42', '2026-09-17 11:55:15'),
(160, 26, 45, 'Teuku Safril Nizam TM', 'Solat jumat', '2026-09-18 12:03:00', '2026-09-18 14:00:00', 'Bawa Sendiri', 0, 6025, 'Baik', NULL, NULL, 'Completed', '2026-09-18 15:27:56', '2026-09-18 12:04:22'),
(161, 29, 43, 'Syarwani', 'Beli keran air', '2026-09-18 14:02:00', '2026-09-18 14:58:00', 'Bawa Sendiri', 23746, 23767, NULL, NULL, NULL, 'Completed', '2026-09-18 15:03:32', '2026-09-18 14:32:46'),
(162, 29, 49, 'Yogie Aditya Pratama', 'Antar barang ke glee siblah', '2026-09-18 15:15:00', '2026-09-18 15:15:00', 'Bawa Sendiri', 0, 23767, 'Baik', NULL, NULL, 'Completed', '2026-09-18 15:28:44', '2026-09-18 15:16:21'),
(163, 29, 49, 'Yogie Aditya Pratama', 'Antar barang ke glee siblah', '2026-09-18 17:00:00', '2026-09-18 18:35:00', 'Bawa Sendiri', 23787, 23794, 'Baik', '[\"uploads\\/returns\\/return_6aad390a30683_128.jpg\"]', '[\"uploads\\/loans\\/loan_6aad38e24ab14_243.jpg\"]', 'Completed', '2026-09-18 20:13:46', '2026-09-18 16:00:28'),
(164, 28, 20, 'Harris Fadhilla Said', 'Belanja', '2026-09-18 17:20:00', '2026-09-18 19:20:00', 'Bawa Sendiri', 15945, 15969, 'Baik', '[\"uploads\\/returns\\/return_6aad2a5ff146e_143.jpg\"]', '[\"uploads\\/loans\\/loan_6aad10bf39d87_764.jpg\"]', 'Completed', '2026-09-18 19:11:11', '2026-09-18 17:20:58'),
(165, 29, 19, 'Hanifah Hanifah', 'beli makan ke meulaboh', '2026-09-19 13:10:00', '2026-09-20 18:16:00', 'Bawa Sendiri', 0, 23894, 'kondisi baik', '[\"uploads\\/returns\\/return_6ab081a01cd4b_906.jpg\"]', NULL, 'Completed', '2026-09-21 08:00:16', '2026-09-19 08:17:26'),
(166, 28, 49, 'Yogie Aditya Pratama', 'Kuala bee', '2026-09-19 19:00:00', '2026-09-19 21:00:00', 'Bawa Sendiri', 15969, 15987, 'Baik', '[\"uploads\\/returns\\/return_6aae9a56d47e9_577.jpg\"]', '[\"uploads\\/loans\\/loan_6aae805a3fde9_302.jpg\"]', 'Completed', '2026-09-19 21:21:10', '2026-09-19 17:56:58'),
(167, 28, 29, 'Nugroho Yulianto', 'Belanja', '2026-09-20 17:04:00', '2026-09-20 19:04:00', 'Bawa Sendiri', 15987, 16007, 'Baik', '[\"uploads\\/returns\\/return_6aafc8e313a03_947.jpg\"]', '[\"uploads\\/loans\\/loan_6aafb000ef662_328.jpg\"]', 'Completed', '2026-09-20 18:52:03', '2026-09-20 17:04:52'),
(168, 29, 37, 'Sabaruddin', 'Perjalanan Dinas KTR pos Meulaboh', '2026-09-21 11:48:00', '2026-09-21 16:00:00', 'Bawa Sendiri', 23894, 23965, 'Kondisi baik', '[\"uploads\\/returns\\/return_6ab0f2f4a8624_733.jpg\"]', '[\"uploads\\/loans\\/loan_6ab0ba8332349_173.jpg\"]', 'Completed', '2026-09-21 16:03:48', '2026-09-21 11:49:37'),
(169, 25, 33, 'Rimada Natanegara', 'Beli nasi', '2026-09-21 14:50:00', '2026-09-21 17:50:00', 'Bawa Sendiri', 4134, 4274, 'Baik', NULL, NULL, 'Completed', '2026-09-22 12:34:58', '2026-09-21 14:50:15'),
(170, 28, 49, 'Yogie Aditya Pratama', 'Beli makan kuala bee', '2026-09-21 16:07:00', '2026-09-21 18:00:00', 'Bawa Sendiri', 16009, 16047, 'Baik', '[\"uploads\\/returns\\/return_6ab1dccb8491f_985.jpg\"]', '[\"uploads\\/loans\\/loan_6ab0f51a318a0_952.jpg\"]', 'Completed', '2026-09-22 08:41:31', '2026-09-21 16:08:46'),
(171, 29, 19, 'Hanifah Hanifah', 'takziah kerumah duka pak Arib rekan di divisi Raw Material', '2026-09-22 17:09:00', '2026-09-23 20:09:00', 'Bawa Sendiri', 0, 24032, 'kondisi baik', '[\"uploads\\/returns\\/return_6ab3229f1cf16_486.jpg\"]', NULL, 'Completed', '2026-09-23 07:51:43', '2026-09-22 13:10:50'),
(172, 28, 10, 'Bowo F Frandhika', 'Ke meulaboh,', '2026-09-22 16:47:00', '2026-09-23 08:00:00', 'Bawa Sendiri', 0, 16301, NULL, '[\"uploads\\/returns\\/return_6abb8123b9808_754.jpg\"]', NULL, 'Completed', '2026-09-29 16:13:07', '2026-09-22 16:48:48'),
(173, 25, 43, 'Syarwani', 'Beli makan malam tim HO', '2026-09-22 16:13:00', '2026-09-22 18:30:00', 'Dengan Driver', 4274, 4344, 'Baik', NULL, NULL, 'Completed', '2026-09-23 08:45:46', '2026-09-23 08:45:10'),
(174, 29, 49, 'Yogie Aditya Pratama', 'Kuala bee', '2026-09-23 16:00:00', '2026-09-23 19:39:00', 'Bawa Sendiri', 24032, 24053, 'Baik', '[\"uploads\\/returns\\/return_6ab3cd93e8bde_865.jpg\"]', '[\"uploads\\/loans\\/loan_6ab3cd711c7fd_773.jpg\"]', 'Completed', '2026-09-23 20:01:07', '2026-09-23 15:41:34'),
(175, 25, 43, 'Syarwani', 'Ambil nasi di Meulaboh', '2026-09-23 09:30:00', '2026-09-23 11:45:00', 'Bawa Sendiri', 4346, 4415, 'Baik', NULL, NULL, 'Completed', '2026-09-23 15:59:08', '2026-09-23 15:58:03'),
(176, 25, 20, 'Harris Fadhilla Said', 'diner', '2026-09-24 18:54:00', '2026-09-24 18:54:00', 'Bawa Sendiri', 0, 4484, NULL, '[\"uploads\\/returns\\/return_6abb826207e02_739.jpg\"]', NULL, 'Completed', '2026-09-29 16:18:26', '2026-09-24 18:54:57'),
(177, 29, 37, 'Sabaruddin', 'Ambil paket ke SP Gunong meuh', '2026-09-25 08:00:00', '2026-09-25 10:30:00', 'Bawa Sendiri', 24052, 24052, 'Kondisi baik-batal pinjam', NULL, NULL, 'Completed', '2026-09-25 09:53:27', '2026-09-25 06:59:17'),
(178, 26, 37, 'Sabaruddin', 'Perjalanan: Undangan maulid dan belanja ke Meulaboh', '2026-09-27 08:00:00', '2026-09-27 17:30:00', 'Bawa Sendiri', 10518, 10613, 'Kondisi baik\nBumper depan kiri kambuh lagi', '[\"uploads\\/returns\\/return_6ab8f62d4c4c1_385.jpg\",\"uploads\\/returns\\/return_6ab8f62d4c74e_703.jpg\"]', NULL, 'Completed', '2026-09-27 17:55:41', '2026-09-25 14:48:25'),
(179, 29, 19, 'Hanifah Hanifah', 'ke meulaboh beli makan', '2026-09-25 17:30:00', '2026-09-26 15:18:00', 'Bawa Sendiri', 0, 24247, 'kondisi baik', '[\"uploads\\/returns\\/return_6ab6685dc7feb_141.jpg\"]', NULL, 'Completed', '2026-09-25 19:26:05', '2026-09-25 15:19:24'),
(180, 29, 19, 'Hanifah Hanifah', 'perbaikan kapas rem vario ke dealer di meulaboh', '2026-09-26 15:17:00', '2026-09-27 20:17:00', 'Bawa Sendiri', 0, 24420, 'kondisi baik', '[\"uploads\\/returns\\/return_6ab8efc63e248_365.jpg\"]', NULL, 'Completed', '2026-09-27 17:28:22', '2026-09-26 09:18:21'),
(181, 26, 14, 'Fahlul Masri', 'Pembayaran pelaksanaan pemeriksaan dokumen rintek penyimpanan limbah B3 dan pemeriksaan substansi dokumen lingkungan ke dlhk kab. Aceh barat', '2026-09-28 10:33:00', '2026-09-28 10:33:00', 'Dengan Driver', 0, 10784, 'Kondisi baik', '[\"uploads\\/returns\\/return_6aba15cb201f5_424.jpg\"]', NULL, 'Completed', '2026-09-28 14:22:51', '2026-09-28 10:38:29'),
(182, 26, 14, 'Fahlul Masri', 'Pembayaran pelaksanaan pemeriksaan dokumen rintek penyimpanan limbah B3 dan pemeriksaan substansi dokumen lingkungan ke dlhk kab. Aceh barat', '2026-09-28 10:33:00', '2026-09-28 10:33:00', 'Dengan Driver', 10714, 10837, 'Baik', '[\"uploads\\/returns\\/return_6abcd11e9ee2c_218.jpg\"]', '[\"uploads\\/loans\\/loan_6ab9e193eb81d_337.jpg\"]', 'Completed', '2026-09-30 16:06:38', '2026-09-28 10:38:29'),
(183, 29, 38, 'Siti Utari Amaranggana', 'beli galon ke kuala bhee', '2026-09-29 17:24:00', '2026-09-30 17:24:00', 'Bawa Sendiri', 0, 24442, 'kondisi baik', '[\"uploads\\/returns\\/return_6abba9c89c928_217.jpg\"]', NULL, 'Completed', '2026-09-29 19:06:32', '2026-09-29 17:24:36'),
(184, 25, 49, 'Yogie Aditya Pratama', 'Beli Bokar ke lapangan / ranger', '2026-09-30 08:21:00', '2026-09-30 16:21:00', 'Supir: T. Arif', 0, 4697, 'Baik', '[\"uploads\\/returns\\/return_6abdb6f4ca127_367.jpg\"]', NULL, 'Completed', '2026-10-01 08:27:16', '2026-09-30 08:22:38'),
(185, 29, 19, 'Hanifah Hanifah', 'beli makanan ke meulaboh', '2026-09-30 16:47:00', '2026-09-30 22:47:00', 'Bawa Sendiri', 0, 24520, 'kondisi baik', '[\"uploads\\/returns\\/return_6abd094e5ade7_390.jpg\"]', NULL, 'Completed', '2026-09-30 20:06:22', '2026-09-30 15:48:32'),
(186, 25, 49, 'Yogie Aditya Pratama', 'Mapping, Ranger', '2026-10-01 08:26:00', '2026-10-01 16:26:00', 'Supir: T. Arif', 4697, 4858, 'Baik', '[\"uploads\\/returns\\/return_6abe90969513d_827.jpg\"]', '[\"uploads\\/loans\\/loan_6abdb9ae83ae9_446.jpg\"]', 'Completed', '2026-10-01 23:55:50', '2026-10-01 08:28:11'),
(187, 26, 1, 'Abdul Karim', 'Ke meulaboh', '2026-10-01 16:18:00', '2026-10-01 23:38:00', 'Bawa Sendiri', 10838, 10910, NULL, '[\"uploads\\/returns\\/return_6abf0c38ec64e_600.jpg\"]', '[\"uploads\\/loans\\/loan_6abf0bc879ac8_252.jpg\"]', 'Completed', '2026-10-02 08:43:20', '2026-10-01 16:19:53'),
(188, 25, 49, 'Yogie Aditya Pratama', 'Jemput bokar/ranger', '2026-10-02 10:54:00', '2026-10-02 15:12:00', 'Bawa Sendiri', 0, 10930, 'Baik', '[\"uploads\\/returns\\/return_6abf59538403e_803.jpg\"]', NULL, 'Completed', '2026-10-02 14:12:19', '2026-10-02 10:55:50'),
(189, 29, 20, 'Harris Fadhilla Said', 'Shalat Jum\'at', '2026-10-02 12:36:00', '2026-10-02 13:45:00', 'Bawa Sendiri', 24543, 24550, 'Baik', '[\"uploads\\/returns\\/return_6abf4dc646c4c_905.jpg\"]', '[\"uploads\\/loans\\/loan_6abf459a41565_402.jpg\"]', 'Completed', '2026-10-02 13:23:02', '2026-10-02 12:46:24'),
(190, 26, 45, 'Teuku Safril Nizam TM', 'Solat jumat', '2026-10-02 12:00:00', '2026-10-02 14:08:00', 'Bawa Sendiri', 10930, 10930, 'Baik', NULL, '[\"uploads\\/loans\\/loan_6abf593221168_232.jpg\"]', 'Completed', '2026-10-03 08:50:51', '2026-10-02 14:09:01'),
(191, 26, 49, 'Yogie Aditya Pratama', 'Ke melaboh jemput isteri', '2026-10-03 09:01:00', '2026-10-03 13:01:00', 'Dengan Driver', 10930, 11007, 'Baik', NULL, NULL, 'Completed', '2026-10-03 12:50:35', '2026-10-03 09:02:06'),
(192, 25, 37, 'Sabaruddin', 'Perjalanan Dinas- Meulaboh Belanja office supplies', '2026-10-04 10:00:00', '2026-10-04 18:00:00', 'Bawa Sendiri', 4943, 5011, 'Kondisinya baik', NULL, NULL, 'Completed', '2026-10-04 17:51:26', '2026-10-03 13:02:52'),
(193, 26, 1, 'Abdul Karim', 'Ke meulaboh', '2026-10-03 13:22:00', '2026-10-03 19:22:00', 'Bawa Sendiri', 11008, 11008, NULL, '[\"uploads\\/returns\\/return_6ac2f50540227_942.jpg\"]', '[\"uploads\\/loans\\/loan_6ac0ef2d9da79_137.jpg\"]', 'Completed', '2026-10-05 07:53:25', '2026-10-03 13:22:53'),
(194, 29, 19, 'Hanifah Hanifah', 'ganti karet behel ke meulaboh', '2026-10-04 08:53:00', '2026-10-04 20:53:00', 'Bawa Sendiri', 0, 24647, 'kondisi baik', '[\"uploads\\/returns\\/return_6ac213b66a9d5_566.jpg\"]', NULL, 'Completed', '2026-10-04 15:52:06', '2026-10-04 07:54:10'),
(195, 25, 49, 'Yogie Aditya Pratama', 'Jemput Bokar/Ranger', '2026-10-05 08:29:00', '2026-10-05 15:29:00', 'Supir: T. Arib', 0, NULL, 'Baik', NULL, NULL, 'Completed', '2026-10-06 08:06:19', '2026-10-05 08:30:34'),
(196, 29, 37, 'Sabaruddin', 'Belanja sembako Kuala Bhee', '2026-10-05 12:00:00', '2026-10-05 13:00:00', 'Bawa Sendiri', 24647, 24655, 'Kondisi baik', NULL, NULL, 'Completed', '2026-10-05 13:10:05', '2026-10-05 11:53:47'),
(197, 26, 10, 'Bowo F Frandhika', 'Ke meulaboh belanja', '2026-10-05 19:10:00', '2026-10-05 23:10:00', 'Supir: Ersan Peruka', 11179, 11246, NULL, '[\"uploads\\/returns\\/return_6ac452d0699ef_809.jpg\"]', '[\"uploads\\/loans\\/loan_6ac4528571c6f_207.jpg\"]', 'Completed', '2026-10-06 08:45:52', '2026-10-05 19:11:13'),
(198, 26, 45, 'Teuku Safril Nizam TM', 'Visit toko Baja Utama', '2026-10-06 10:04:00', '2026-10-06 12:00:00', 'Bawa Sendiri', 11246, 11321, 'Baiks', NULL, '[\"uploads\\/loans\\/loan_6ac465e5be3bf_722.jpg\"]', 'Completed', '2026-10-06 17:15:08', '2026-10-06 10:05:20'),
(199, 29, 37, 'Sabaruddin', 'Perjalanan Dinas-Meulaboh', '2026-10-06 15:58:00', '2026-10-07 12:58:00', 'Bawa Sendiri', 24676, 24772, 'Kondisi baik', NULL, '[\"uploads\\/loans\\/loan_6ac4bd079d5a9_644.jpg\"]', 'Completed', '2026-10-07 11:23:27', '2026-10-06 15:58:43'),
(200, 25, 43, 'Syarwani', 'Ke Meulaboh beli Oksigen dan Ambil barang di toko baja utama', '2026-10-07 09:55:00', '2026-10-07 15:30:00', 'Supir: Surya Ramadan', 5183, 5326, 'Baik', '[\"uploads\\/returns\\/return_6ac6e858ad510_746.jpg\"]', '[\"uploads\\/loans\\/loan_6ac5b288aa919_982.jpg\"]', 'Completed', '2026-10-08 07:48:24', '2026-10-07 09:45:51'),
(201, 26, 33, 'Rimada Natanegara', 'Ke dinas DLHK dan beli dispenser di Meulaboh', '2026-10-07 13:24:00', '2026-10-07 16:00:00', 'Bawa Sendiri', 0, 11388, 'Baik', '[\"uploads\\/returns\\/return_6ac6fcf1e6394_575.jpg\"]', NULL, 'Completed', '2026-10-08 09:16:17', '2026-10-07 13:26:19'),
(202, 29, 37, 'Sabaruddin', 'Perjalanan Dinas- Smart agen BSI Kuala Bhee', '2026-10-08 09:20:00', '2026-10-08 11:00:00', 'Bawa Sendiri', 24801, 24820, 'Kondisi baik', '[\"uploads\\/returns\\/return_6ac70a7554096_283.jpg\"]', '[\"uploads\\/loans\\/loan_6ac70a381b744_848.jpg\"]', 'Completed', '2026-10-08 10:13:57', '2026-10-08 09:15:07'),
(203, 28, 49, 'Yogie Aditya Pratama', 'Cari bokar di aceh barat', '2026-10-08 14:07:00', '2026-10-08 16:07:00', 'Bawa Sendiri', 16354, 16379, 'Baik', NULL, NULL, 'Completed', '2026-10-09 08:17:47', '2026-10-08 14:16:36'),
(204, 28, 29, 'Nugroho Yulianto', 'Belanja', '2026-10-08 19:33:00', '2026-10-08 19:33:00', 'Bawa Sendiri', 0, 16379, 'Baik', NULL, NULL, 'Completed', '2026-10-09 08:17:36', '2026-10-08 19:34:13'),
(205, 25, 49, 'Yogie Aditya Pratama', 'Jemput bokar/ranger', '2026-10-09 11:58:00', '2026-10-09 16:58:00', 'Supir: Arib', 5326, NULL, 'Baik', NULL, '[\"uploads\\/loans\\/loan_6ac874be06015_393.jpg\"]', 'Completed', '2026-10-10 12:05:46', '2026-10-09 11:58:52'),
(206, 26, 29, 'Nugroho Yulianto', 'Berobat', '2026-10-09 18:00:00', '2026-10-09 18:00:00', 'Supir: Harris', 0, 11657, NULL, '[\"uploads\\/returns\\/return_6ac98cb8e9838_506.jpg\"]', NULL, 'Completed', '2026-10-10 07:54:16', '2026-10-09 18:01:40'),
(207, 25, 49, 'Yogie Aditya Pratama', 'Kunjungan supplier', '2026-10-10 08:48:00', '2026-10-10 12:01:00', 'Supir: Arib', 0, NULL, 'Baik', NULL, NULL, 'Completed', '2026-10-10 15:30:15', '2026-10-10 12:07:32');
INSERT INTO `loans` (`id`, `vehicle_id`, `employee_id`, `pic_name`, `purpose`, `start_time`, `end_time`, `driver_status`, `initial_km`, `final_km`, `return_notes`, `return_photos`, `photos`, `status`, `returned_at`, `created_at`) VALUES
(208, 29, 19, 'Hanifah Hanifah', 'berobat', '2026-10-11 07:36:00', '2026-10-11 18:36:00', 'Bawa Sendiri', 0, 24971, 'kondisi baik', '[\"uploads\\/returns\\/return_6acb0b909e99b_114.jpg\"]', NULL, 'Completed', '2026-10-11 11:07:44', '2026-10-11 07:36:30'),
(209, 25, 49, 'Yogie Aditya Pratama', 'Jemput bokar', '2026-10-12 08:26:00', '2026-10-12 16:22:00', 'Supir: Arib', 0, 5619, NULL, '[\"uploads\\/returns\\/return_6acca687e7653_507.jpg\"]', NULL, 'Completed', '2026-10-12 16:21:11', '2026-10-12 08:28:43'),
(210, 29, 1, 'Abdul Karim', 'Belanja', '2026-10-12 11:04:00', '2026-10-12 20:04:00', 'Bawa Sendiri', 0, NULL, NULL, NULL, NULL, 'Completed', '2026-10-13 13:58:49', '2026-10-12 11:05:20'),
(211, 26, 20, 'Harris Fadhilla Said', 'berobat tari', '2026-10-12 16:42:00', '2026-10-12 16:42:00', 'Bawa Sendiri', 0, NULL, NULL, NULL, NULL, 'Pending', NULL, '2026-10-12 16:43:09'),
(212, 29, 37, 'Sabaruddin', 'Perjalanan Dinas-Meulaboh', '2026-10-14 07:16:00', '2026-10-14 12:16:00', 'Bawa Sendiri', 25017, 25084, 'Kondisi baik', '[\"uploads\\/returns\\/return_6acf0cc2a52e3_608.jpg\"]', '[\"uploads\\/loans\\/loan_6aceca4ece7b3_739.jpg\",\"uploads\\/loans\\/loan_6aceca4eceea4_389.jpg\"]', 'Completed', '2026-10-14 12:01:54', '2026-10-14 07:17:16'),
(213, 26, 43, 'Syarwani', 'Ke Banda Aceh Jemput Tim External Audit', '2026-10-14 05:00:00', '2026-10-14 20:00:00', 'Supir: Surya Ramadan', 0, NULL, NULL, NULL, NULL, 'Approved', NULL, '2026-10-14 07:51:50'),
(214, 25, 49, 'Yogie Aditya Pratama', 'Jemput bokar ke aceh Jaya', '2026-10-14 08:59:00', '2026-10-14 16:59:00', 'Supir: Arib', 5700, 5833, NULL, '[\"uploads\\/returns\\/return_6acf469068a49_438.jpg\"]', NULL, 'Completed', '2026-10-14 16:08:32', '2026-10-14 09:09:13'),
(215, 28, 30, 'Rahmatillah', 'Perjalanan pengantaran stempel PBS ke DLH Kab. Aceh Barat', '2026-10-14 10:24:00', '2026-10-14 13:00:00', 'Bawa Sendiri', 0, NULL, NULL, NULL, NULL, 'Approved', NULL, '2026-10-14 10:37:21'),
(216, 29, 19, 'Hanifah Hanifah', 'perbaikan rekening terblokir di BSI Meulaboh', '2026-10-14 12:29:00', '2026-10-14 17:29:00', 'Bawa Sendiri', 0, 25156, 'kondisi baik', '[\"uploads\\/returns\\/return_6acf4b135689f_115.jpg\"]', NULL, 'Completed', '2026-10-14 16:27:47', '2026-10-14 12:30:56'),
(217, 25, 49, 'Yogie Aditya Pratama', 'Hunting bokar ke pante kuyun', '2026-10-17 09:36:00', '2026-10-17 16:36:00', 'Supir: Arib', 0, NULL, NULL, NULL, NULL, 'Approved', NULL, '2026-10-17 14:36:59'),
(218, 29, 19, 'Hanifah Hanifah', 'belanja ke meulaboh', '2026-10-18 14:32:00', '2026-10-18 22:32:00', 'Bawa Sendiri', 0, 25264, 'ban perlu diganti', '[\"uploads\\/returns\\/return_6ad569e08a3ae_825.jpg\"]', NULL, 'Completed', '2026-10-19 07:52:48', '2026-10-18 13:33:46');

-- --------------------------------------------------------

--
-- Struktur dari tabel `maintenances`
--

CREATE TABLE `maintenances` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `workshop` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `cost` int(11) DEFAULT 0,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` enum('Ongoing','Completed') NOT NULL DEFAULT 'Ongoing',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `otp_verifications`
--

CREATE TABLE `otp_verifications` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `sn_code` varchar(10) NOT NULL,
  `is_verified` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `otp_verifications`
--

INSERT INTO `otp_verifications` (`id`, `email`, `sn_code`, `is_verified`, `created_at`) VALUES
(1, 'a.k4r1m55@gmail.com', 'SN-5340', 0, '2026-07-27 12:36:45'),
(2, 'a.k4r1m55@gmail.com', 'SN-7958', 0, '2026-07-27 12:38:05'),
(3, 'a.k4r1m55@gmail.com', 'SN-5355', 0, '2026-07-27 12:46:08'),
(4, 'a.k4r1m55@gmail.com', 'SN-4079', 0, '2026-07-27 12:46:14'),
(5, 'a.k4r1m55@gmail.com', 'SN-2659', 0, '2026-07-27 12:46:58'),
(6, 'a.k4r1m55@gmail.com', 'SN-1521', 0, '2026-07-27 12:47:31'),
(7, 'a.k4r1m55@gmail.com', 'SN-3841', 0, '2026-07-27 12:49:21'),
(8, 'a.k4r1m55@gmail.com', 'SN-4292', 0, '2026-07-27 12:49:53'),
(9, 'a.k4r1m55@gmail.com', 'SN-5954', 0, '2026-07-27 12:56:33'),
(10, 'a.k4r1m55@gmail.com', 'SN-8816', 0, '2026-07-27 13:23:39'),
(11, 'a.k4r1m55@gmail.com', 'SN-3734', 0, '2026-07-27 13:25:21'),
(12, 'a.k4r1m55@gmail.com', 'SN-5674', 0, '2026-07-27 13:26:39'),
(13, 'a.k4r1m55@gmail.com', 'SN-8633', 0, '2026-07-27 13:35:28'),
(14, 'a.k4r1m55@gmail.com', 'SN-1801', 0, '2026-07-27 13:41:37'),
(15, 'a.k4r1m55@gmail.com', 'SN-8297', 0, '2026-07-27 13:49:28'),
(16, 'a.k4r1m55@gmail.com', 'SN-6352', 0, '2026-07-27 13:54:28'),
(17, 'a.k4r1m55@gmail.com', 'SN-2091', 0, '2026-07-27 13:55:06'),
(18, 'a.k4r1m55@gmail.com', 'SN-5941', 0, '2026-07-27 13:55:42'),
(19, 'a.k4r1m55@gmail.com', 'SN-6353', 0, '2026-07-27 13:58:24'),
(20, 'a.k4r1m55@gmail.com', 'SN-7497', 0, '2026-07-27 13:59:56'),
(21, 'a.k4r1m55@gmail.com', 'SN-7995', 0, '2026-07-27 14:08:02'),
(22, 'a.k4r1m55@gmail.com', 'SN-5577', 0, '2026-07-27 14:15:45'),
(23, 'a.k4r1m55@gmail.com', 'SN-3822', 0, '2026-07-27 14:16:18'),
(24, 'a.k4r1m55@gmail.com', 'SN-8557', 0, '2026-07-27 14:21:44'),
(25, 'a.k4r1m55@gmail.com', 'SN-9229', 0, '2026-07-27 14:22:42'),
(26, 'a.k4r1m55@gmail.com', 'SN-6946', 1, '2026-07-27 14:22:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `type` varchar(30) NOT NULL,
  `status` enum('Ready','Loaned','Maintenance') NOT NULL DEFAULT 'Ready',
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `vehicles`
--

INSERT INTO `vehicles` (`id`, `plate_number`, `brand`, `model`, `type`, `status`, `notes`) VALUES
(25, 'BL 1672 AZH', 'Toyota Hilux Rangga', 'High 2.0 M/T', 'Pickup', 'Loaned', 'Baik, dan layak digunakan'),
(26, 'BL 1670 AZH', 'Toyota Rush', '1,5 S M/T GR SPORT', 'SUV', 'Loaned', 'Baik, dan layak digunakan'),
(27, 'BL 8435 EW', 'Nissan Navara', 'Frontier 2 5 AT DC', 'Pickup', 'Ready', 'Baik, dan layak digunakan'),
(28, 'BL 6613 EAW', 'Honda CRF', 'T4G02T31L0 M/T', 'Motor Trail', 'Loaned', 'Baik, dan layak digunakan'),
(29, 'BL 6612 EAW', 'HONDA VARIO 160', 'X1H02N32L1 A/T', 'Motor Matic', 'Ready', 'Baik, dan layak digunakan'),
(30, 'B 1770 PJL', 'TOYOTA FORTUNER', 'FORTUNER2.7SRZ 4X2 AT', 'MPV', 'Ready', ''),
(31, 'BL 8135 EB', 'Toyota Hilux Solar', 'Hilux 2.av DC 4X4 AT', 'Pickup', 'Ready', 'Kondisi Baik dan Dapat digunakan');

--
-- Indeks untuk tabel yang dibuang
--

--
-- Indeks untuk tabel `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nik` (`nik`);

--
-- Indeks untuk tabel `fuel_fillings`
--
ALTER TABLE `fuel_fillings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loan_id` (`loan_id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indeks untuk tabel `ga_users`
--
ALTER TABLE `ga_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indeks untuk tabel `maintenances`
--
ALTER TABLE `maintenances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indeks untuk tabel `otp_verifications`
--
ALTER TABLE `otp_verifications`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plate_number` (`plate_number`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=770;

--
-- AUTO_INCREMENT untuk tabel `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT untuk tabel `fuel_fillings`
--
ALTER TABLE `fuel_fillings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT untuk tabel `ga_users`
--
ALTER TABLE `ga_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `loans`
--
ALTER TABLE `loans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT untuk tabel `maintenances`
--
ALTER TABLE `maintenances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `otp_verifications`
--
ALTER TABLE `otp_verifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT untuk tabel `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `fuel_fillings`
--
ALTER TABLE `fuel_fillings`
  ADD CONSTRAINT `fuel_fillings_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fuel_fillings_ibfk_2` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `maintenances`
--
ALTER TABLE `maintenances`
  ADD CONSTRAINT `maintenances_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
