<?php
// test_db.php - DB Connection Test for SIMKEN
require_once 'config.php';

echo "<h1>SIMKEN Database Status</h1>";
try {
    $tables = ['vehicles', 'loans', 'maintenances', 'activities', 'employees', 'ga_users'];
    foreach ($tables as $table) {
        $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
        echo "<p>Table <strong>$table</strong>: $count records found.</p>";
    }
    echo "<p style='color:green;'><strong>Connection is successful and database has been initialized!</strong></p>";
} catch (Exception $e) {
    echo "<p style='color:red;'><strong>Error: " . $e->getMessage() . "</strong></p>";
}
echo "<p><a href='./'>Go to Dashboard</a></p>";
