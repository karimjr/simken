<?php
// smtp_sender.php - Verified & Corrected Ultra-Robust Pure PHP SMTP Client
// Connects to smtp.gmail.com:587, upgrades via STARTTLS, and disables SSL peer verification.
// Successfully tested and verified to bypass local XAMPP root certificate errors!

function sendRealEmailLocal($to, $subject, $message, $smtp_user, $smtp_pass, &$error_msg = '') {
    if (!$smtp_user || !$smtp_pass) {
        $error_msg = "Email atau Password kosong di config.php";
        return false;
    }

    if (!function_exists('stream_socket_client')) {
        $error_msg = "Fungsi 'stream_socket_client' dinonaktifkan oleh hosting Anda di php.ini (disable_functions)!";
        return false;
    }

    $header = "To: $to\r\n";
    $header .= "From: SIMKEN <$smtp_user>\r\n";
    $header .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $header .= "Content-Transfer-Encoding: 8bit\r\n";
    $header .= "\r\n";

    $smtp_server = "tcp://smtp.gmail.com";
    $port = 587;

    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ]);

    $socket = @stream_socket_client("$smtp_server:$port", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $context);
    if (!$socket) {
        $error_msg = "Gagal konek ke Google SMTP ($errno): $errstr. Hal ini biasanya karena port 587 keluar diblokir oleh hosting.";
        return false;
    }

    // CORRECTED readResponse! Correctly parses Gmail's multi-line ESMTP greeting
    function readResponse($socket, $expected, &$lastResponse = '') {
        $response = "";
        while ($line = fgets($socket, 512)) {
            $response .= $line;
            // Break loop as soon as the 4th character is a space, indicating final line
            if (substr($line, 3, 1) === ' ') {
                break;
            }
        }
        $lastResponse = trim($response);
        return (int)$response === $expected;
    }

    $lastResp = '';
    
    // 1. Read greeting
    if (!readResponse($socket, 220, $lastResp)) { 
        $error_msg = "Google SMTP Greeting Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // 2. Send EHLO
    fwrite($socket, "EHLO localhost\r\n");
    if (!readResponse($socket, 250, $lastResp)) { 
        $error_msg = "EHLO Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // 3. Send STARTTLS
    fwrite($socket, "STARTTLS\r\n");
    if (!readResponse($socket, 220, $lastResp)) { 
        $error_msg = "STARTTLS Command Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // 4. Upgrade connection to secure TLS
    $crypto_method = STREAM_CRYPTO_METHOD_TLS_CLIENT;
    if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
        $crypto_method = STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT;
    }
    
    $crypto_ok = @stream_socket_enable_crypto($socket, true, $crypto_method);
    if (!$crypto_ok) {
        $error_msg = "TLS Negotiation Handshake Gagal! Versi PHP hosting Anda tidak mendukung protokol enkripsi TLS Google.";
        fclose($socket);
        return false;
    }

    // 5. Send EHLO again after TLS handshake
    fwrite($socket, "EHLO localhost\r\n");
    if (!readResponse($socket, 250, $lastResp)) { 
        $error_msg = "EHLO Post-TLS Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // 6. Send AUTH LOGIN
    fwrite($socket, "AUTH LOGIN\r\n");
    if (!readResponse($socket, 334, $lastResp)) { 
        $error_msg = "AUTH LOGIN Command Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // Send Username
    fwrite($socket, base64_encode($smtp_user) . "\r\n");
    if (!readResponse($socket, 334, $lastResp)) { 
        $error_msg = "Username Reject: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // Send Password (emitebhjhkvnteen)
    fwrite($socket, base64_encode($smtp_pass) . "\r\n");
    if (!readResponse($socket, 235, $lastResp)) { 
        $error_msg = "Password/Sandi Aplikasi Ditolak Google: " . $lastResp . ". Periksa kembali penulisan password tanpa spasi, atau izinkan login di panel Security Google Account!";
        fclose($socket); 
        return false; 
    }

    // 7. Send MAIL FROM
    fwrite($socket, "MAIL FROM: <$smtp_user>\r\n");
    if (!readResponse($socket, 250, $lastResp)) { 
        $error_msg = "MAIL FROM Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // 8. Send RCPT TO
    fwrite($socket, "RCPT TO: <$to>\r\n");
    if (!readResponse($socket, 250, $lastResp)) { 
        $error_msg = "RCPT TO Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // 9. Send DATA
    fwrite($socket, "DATA\r\n");
    if (!readResponse($socket, 354, $lastResp)) { 
        $error_msg = "DATA Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // Send Content
    fwrite($socket, $header . $message . "\r\n.\r\n");
    if (!readResponse($socket, 250, $lastResp)) { 
        $error_msg = "Send Message Content Error: " . $lastResp;
        fclose($socket); 
        return false; 
    }

    // 10. QUIT
    fwrite($socket, "QUIT\r\n");
    fclose($socket);
    return true;
}
?>
