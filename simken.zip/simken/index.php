<?php
// index.php - Sistem Informasi Manajemen Kendaraan (SIMKEN)
// Anti-Cache Headers to prevent browser caching issues in local environments
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SIMKEN — Sistem Informasi Manajemen Kendaraan</title>
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="apple-touch-icon" href="assets/img/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@500;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">

<!-- 📊 CDNs for Exporting features (Excel & PDF) -->
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>

<style>
  :root{
    --bg:#E9EDF0;
    --bg-soft:#DFE5E9;
    --panel:#FFFFFF;
    --ink:#131A24;
    --ink-soft:#4B5563;
    --line:#CBD3D9;
    --blue:#2A5FA8;
    --blue-soft:#E4ECF7;
    --green:#1B8A55;
    --green-soft:#E1F4EA;
    --amber:#C3630A;
    --amber-soft:#FBEBDC;
    --plate-bg:#12161C;
    --plate-fg:#F5F7F8;
    --radius:14px;
    --red:#DC2626;
    --red-soft:#FEE2E2;
  }
  *{box-sizing:border-box;}
  html{scroll-behavior:smooth;}
  body{
    margin:0;
    background:var(--bg);
    color:var(--ink);
    font-family:'Inter',sans-serif;
    -webkit-font-smoothing:antialiased;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
  }
  .display{
    font-family:'Barlow Condensed',sans-serif;
    text-transform:uppercase;
    letter-spacing:0.01em;
  }
  .mono{
    font-family:'JetBrains Mono',monospace;
  }
  a{color:inherit;text-decoration:none;}
  
  /* ---------- topbar ---------- */
  header{
    position:sticky;top:0;z-index:50;
    display:flex;align-items:center;justify-content:space-between;
    padding:16px 40px;
    background:rgba(233,237,240,0.9);
    backdrop-filter:blur(8px);
    border-bottom:1px solid var(--line);
    /* Fix Chromium (Chrome/Edge) rendering bug: sticky + backdrop-filter can leave
       a stale/ghost blurred rectangle after large DOM updates (e.g. table re-render
       after approve/reject/return). Forcing its own GPU compositing layer prevents it. */
    transform: translateZ(0);
    will-change: transform;
    isolation: isolate;
  }
  .brand{display:flex;align-items:center;gap:14px;}
  .brand-logo {
    height: 48px;
    width: auto;
    object-fit: contain;
  }
  .brand-text {
    display: flex;
    flex-direction: column;
  }
  .brand-name{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:22px;letter-spacing:0.02em;text-transform:uppercase;line-height:1.1;}
  .brand-sub{font-size:11px;color:var(--ink-soft);margin-top:-1px;}
  nav{display:flex;align-items:center;gap:24px;}
  nav .links{display:flex;gap:6px;font-size:14px;font-weight:600;color:var(--ink-soft);}
  nav .links a {
    cursor: pointer;
    transition: color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
    padding:9px 16px;
    border-radius:9px;
  }
  nav .links a:hover{color:var(--ink); background:rgba(255,255,255,0.6);}
  nav .links a.active{
    color:var(--ink);
    background:#FFFFFF;
    box-shadow:0 1px 3px rgba(19,26,36,0.12), 0 1px 2px rgba(19,26,36,0.08);
  }
  
  /* Buttons */
  .btn-primary{
    background:var(--ink);color:#fff;
    padding:10px 18px;border-radius:9px;
    font-size:14px;font-weight:600;
    border:none;cursor:pointer;
    display:inline-flex;align-items:center;gap:8px;
    transition: background-color 0.15s ease;
  }
  .btn-primary:hover{background:var(--blue);}
  .btn-danger {
    background: var(--red); color: #fff;
  }
  .btn-danger:hover { background: #b91c1c; }
  .btn-secondary-dark {
    background: var(--bg-soft); color: var(--ink);
    padding: 10px 18px; border-radius: 9px;
    font-size: 14px; font-weight: 600;
    border: 1px solid var(--line); cursor: pointer;
  }
  .btn-secondary-dark:hover { background: var(--line); }

  /* Admin Mode Banner */
  .admin-banner {
    background: var(--amber);
    color: #fff;
    font-size: 12.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    text-align: center;
    padding: 6px 14px;
    display: none;
    border-radius: 6px;
    margin-right: 12px;
    cursor: pointer;
    transition: background-color 0.15s ease;
    border: 1px solid rgba(255,255,255,0.1);
  }
  .admin-banner:hover {
    background: var(--ink);
  }
  
  /* WhatsApp Button Style */
  .btn-wa {
    background-color: #1B8A55;
    color: white;
    font-weight: 600;
    padding: 12px;
    border-radius: 9px;
    text-align: center;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    border: none;
    cursor: pointer;
    transition: background-color 0.15s ease;
    font-size: 14px;
    width: 100%;
    font-family: 'Inter', sans-serif;
  }
  .btn-wa:hover {
    background-color: #12613d;
  }
  .btn-wa svg {
    fill: currentColor;
  }
  
  /* Autocomplete Suggestions Dropdown Style (Ultra-Premium! 🌟) */
  #employee-suggestions {
    border-radius: var(--radius);
    border: 1px solid var(--line);
    box-shadow: 0 12px 32px -10px rgba(19, 26, 36, 0.25);
    background: var(--panel);
    overflow: hidden;
    z-index: 1000;
  }
  .autocomplete-item {
    padding: 12px 18px;
    cursor: pointer;
    transition: all 0.15s ease;
    border-bottom: 1px solid var(--bg-soft);
  }
  .autocomplete-item:last-child {
    border-bottom: none;
  }
  .autocomplete-item:hover {
    background-color: var(--blue-soft) !important;
  }
  
  /* Photos upload trigger and thumbnail grid style */
  .photo-upload-container {
    display: flex;
    gap: 12px;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 10px;
  }
  .photo-trigger-btn {
    border: 2px dashed var(--line);
    background: var(--panel);
    border-radius: 8px;
    width: 80px; height: 80px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: var(--ink-soft);
    font-size: 10px;
    font-weight: 600;
    gap: 4px;
    transition: all 0.15s ease;
  }
  .photo-trigger-btn:hover {
    border-color: var(--blue);
    color: var(--blue);
  }
  .photos-preview-grid {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
  }
  .preview-item {
    position: relative;
    width: 80px; height: 80px;
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid var(--line);
    background: var(--bg-soft);
  }
  .preview-item img {
    width: 100%; height: 100%;
    object-fit: cover;
  }
  .preview-item .remove-btn {
    position: absolute;
    top: 2px; right: 2px;
    background: rgba(220, 38, 38, 0.85);
    color: white;
    border: none;
    border-radius: 50%;
    width: 18px; height: 18px;
    font-size: 11px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 1;
    transition: background-color 0.1s ease;
  }
  .preview-item .remove-btn:hover {
    background: rgb(220, 38, 38);
  }
  
  /* ---------- content section layout ---------- */
  main {
    flex: 1;
  }
  .content-section {
    display: none;
    animation: fadeIn 0.25s ease-in-out forwards;
  }
  .content-section.active {
    display: block;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* ---------- hero & gauges ---------- */
  .hero{padding:64px 40px 40px;max-width:1180px;margin:0 auto;}
  .eyebrow{
    font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:500;
    color:var(--blue);letter-spacing:0.14em;text-transform:uppercase;
    display:flex;align-items:center;gap:10px;margin-bottom:18px;
  }
  .eyebrow::before{content:"";width:22px;height:2px;background:var(--blue);display:inline-block;}
  h1{
    font-family:'Barlow Condensed',sans-serif;
    font-weight:800;
    font-size:clamp(38px,5.2vw,68px);
    line-height:0.98;
    letter-spacing:0.002em;
    margin:0 0 20px;
    max-width:16ch;
  }
  .lede{
    font-size:17px;line-height:1.6;color:var(--ink-soft);
    max-width:56ch;margin:0 0 40px;
  }
  .cluster{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:14px;
    max-width:900px;
  }
  .gauge{
    background:var(--panel);
    border:1px solid var(--line);
    border-radius:var(--radius);
    padding:18px 18px 16px;
    transition: transform 0.2s ease;
  }
  .gauge:hover {
    transform: translateY(-2px);
  }
  .plate{
    display:inline-block;
    background:var(--plate-bg);color:var(--plate-fg);
    font-family:'JetBrains Mono',monospace;font-weight:700;
    font-size:26px;padding:4px 12px;border-radius:6px;
    letter-spacing:0.03em;margin-bottom:10px;
  }
  .gauge-label{font-size:12.5px;color:var(--ink-soft);font-weight:600;}
  .gauge.status-ready .plate{box-shadow:inset 0 0 0 2px var(--green);}
  .gauge.status-loan .plate{box-shadow:inset 0 0 0 2px var(--blue);}
  .gauge.status-maint .plate{box-shadow:inset 0 0 0 2px var(--amber);}
  .gauge-tag{
    display:inline-flex;align-items:center;gap:6px;
    font-size:11px;font-weight:600;margin-top:8px;
    padding:3px 8px;border-radius:99px;
  }
  .tag-ready{background:var(--green-soft);color:var(--green);}
  .tag-loan{background:var(--blue-soft);color:var(--blue);}
  .tag-maint{background:var(--amber-soft);color:var(--amber);}
  .tag-total{background:var(--bg-soft);color:var(--ink-soft);}
  
  /* ---------- lane divider ---------- */
  .lane{
    max-width:1180px;margin:56px auto 0;padding:0 40px;
  }
  .lane-line{
    height:0;border-top:3px dashed #C2CAD1;
  }
  
  /* ---------- modules ---------- */
  .modules{
    max-width:1180px;margin:0 auto;padding:56px 40px 20px;
  }
  .section-head{display:flex;align-items:baseline;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:8px;}
  .section-title{
    font-family:'Barlow Condensed',sans-serif;font-weight:700;
    font-size:28px;text-transform:uppercase;letter-spacing:0.01em;
  }
  .section-note{font-size:13.5px;color:var(--ink-soft);}
  .module-grid{
    display:grid;grid-template-columns:1fr 1fr;gap:20px;
  }
  .module-card{
    background:var(--panel);
    border:1px solid var(--line);
    border-radius:20px;
    padding:32px;
    display:flex;flex-direction:column;
    min-height:320px;
    cursor: pointer;
    transition:transform .18s ease, box-shadow .18s ease, border-color .18s ease;
  }
  .module-card:hover{
    transform:translateY(-3px);
    box-shadow:0 16px 32px -18px rgba(19,26,36,0.35);
  }
  .module-card.loan:hover{border-color:var(--blue);}
  .module-card.maint:hover{border-color:var(--amber);}
  .module-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:22px;}
  .module-code{
    font-family:'JetBrains Mono',monospace;font-weight:700;
    font-size:13px;padding:5px 10px;border-radius:6px;
    color:#fff;letter-spacing:0.05em;
  }
  .module-card.loan .module-code{background:var(--blue);}
  .module-card.maint .module-code{background:var(--amber);}
  .module-icon{width:44px;height:44px;display:flex;align-items:center;justify-content:center;
    border-radius:12px;background:var(--bg-soft);}
  .module-title{
    font-family:'Barlow Condensed',sans-serif;font-weight:700;
    font-size:30px;text-transform:uppercase;margin:0 0 10px;
  }
  .module-desc{font-size:14.5px;line-height:1.55;color:var(--ink-soft);margin:0 0 24px;max-width:44ch;}
  .module-meta{
    display:flex;gap:20px;margin-bottom:24px;padding-top:18px;
    border-top:1px solid var(--line);
  }
  .meta-num{font-family:'JetBrains Mono',monospace;font-weight:700;font-size:20px;}
  .meta-label{font-size:11.5px;color:var(--ink-soft);margin-top:2px;}
  .module-cta{
    margin-top:auto;
    display:inline-flex;align-items:center;gap:8px;
    font-weight:600;font-size:14.5px;
  }
  .module-card.loan .module-cta{color:var(--blue);}
  .module-card.maint .module-cta{color:var(--amber);}
  .module-cta svg{transition:transform .18s ease;}
  .module-card:hover .module-cta svg{transform:translateX(4px);}
  
  /* ---------- activity & tables ---------- */
  .activity{max-width:1180px;margin:64px auto 0;padding:0 40px 80px;}
  .activity-list{
    background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden;
  }
  .activity-row{
    display:grid;
    grid-template-columns:110px 1.4fr 1fr 90px 110px;
    align-items:center;
    gap:16px;
    padding:16px 22px;
    font-size:13.5px;
    border-bottom:1px solid var(--line);
  }
  .activity-row.admin-grid {
    grid-template-columns: 110px 1.4fr 1fr 90px 110px 60px !important;
  }
  .activity-row:last-child{border-bottom:none;}
  .activity-row.head{
    font-size:11px;color:var(--ink-soft);font-weight:700;
    text-transform:uppercase;letter-spacing:0.06em;background:var(--bg-soft);
  }
  .mini-plate{
    font-family:'JetBrains Mono',monospace;font-weight:700;font-size:12px;
    background:var(--plate-bg);color:var(--plate-fg);
    padding:3px 7px;border-radius:5px;display:inline-block;letter-spacing:0.03em;
    border: 1px solid rgba(255,255,255,0.1);
  }
  .status-pill{
    font-size:11px;font-weight:700;padding:3px 9px;border-radius:99px;
    display:inline-block;text-align:center;
  }
  .pill-selesai{background:var(--green-soft);color:var(--green);}
  .pill-berjalan{background:var(--blue-soft);color:var(--blue);}
  .pill-servis{background:var(--amber-soft);color:var(--amber);}
  .pill-ditolak{background:var(--red-soft);color:var(--red);}
  .pill-tertunda{background:var(--bg-soft);color:var(--ink-soft);}
  .row-time{color:var(--ink-soft);}
  
  /* ---------- section inside pages ---------- */
  .view-container {
    max-width: 1180px;
    margin: 0 auto;
    padding: 40px;
  }
  .view-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    border-bottom: 2px solid var(--line);
    padding-bottom: 16px;
  }
  .view-title-container h2 {
    font-family: 'Barlow Condensed', sans-serif;
    font-weight: 700;
    font-size: 36px;
    text-transform: uppercase;
    margin: 0 0 6px;
    letter-spacing: 0.01em;
  }
  .view-subtitle {
    color: var(--ink-soft);
    font-size: 15px;
    margin: 0;
  }
  
  /* ---------- control bar ---------- */
  .control-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    gap: 16px;
    flex-wrap: wrap;
  }
  .search-wrapper {
    position: relative;
    flex: 1;
    max-width: 400px;
  }
  .search-input {
    width: 100%;
    padding: 11px 16px 11px 40px;
    border: 1px solid var(--line);
    border-radius: 9px;
    font-size: 14px;
    background: var(--panel);
    color: var(--ink);
    outline: none;
    transition: border-color 0.15s ease;
  }
  .search-input:focus {
    border-color: var(--blue);
  }
  .search-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--ink-soft);
    pointer-events: none;
  }
  .filter-group {
    display: flex;
    gap: 10px;
  }
  .filter-btn {
    background: var(--panel);
    border: 1px solid var(--line);
    padding: 8px 16px;
    font-size: 13.5px;
    font-weight: 600;
    color: var(--ink-soft);
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s ease;
  }
  .filter-btn:hover {
    color: var(--ink);
    border-color: var(--ink-soft);
  }
  .filter-btn.active {
    background: var(--ink);
    color: #fff;
    border-color: var(--ink);
  }
  
  /* ---------- table design ---------- */
  .table-responsive {
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 14px;
    overflow-x: auto;
    overflow-y: hidden;
    -webkit-overflow-scrolling: touch;
    touch-action: pan-x pan-y;
    box-shadow: 0 4px 12px -5px rgba(0,0,0,0.05);
    margin-bottom: 30px;
    position: relative;
  }
  /* thin, visible scrollbar so users know the table can be swiped */
  .table-responsive::-webkit-scrollbar {
    height: 8px;
  }
  .table-responsive::-webkit-scrollbar-track {
    background: var(--bg-soft);
  }
  .table-responsive::-webkit-scrollbar-thumb {
    background: var(--line);
    border-radius: 8px;
  }
  .table-responsive::-webkit-scrollbar-thumb:hover {
    background: var(--ink-soft);
  }
  .table-responsive {
    scrollbar-width: thin;
    scrollbar-color: var(--line) var(--bg-soft);
  }
  table {
    width: 100%;
    min-width: 640px;
    border-collapse: collapse;
    font-size: 14px;
    text-align: left;
  }
  th {
    background: var(--bg-soft);
    padding: 16px 20px;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.06em;
    color: var(--ink-soft);
    border-bottom: 1px solid var(--line);
  }
  td {
    padding: 16px 20px;
    border-bottom: 1px solid var(--line);
    vertical-align: middle;
  }
  tr:last-child td {
    border-bottom: none;
  }
  tr:hover td {
    background-color: rgba(233,237,240,0.3);
  }
  /* Keep the "Aksi" (actions) column always visible on the right while scrolling
     horizontally, instead of being cut off out of view — this is the column that
     was reported as "terputus" / cut off in the loans, returns, fuel, maintenance
     and employees tables. */
  table th:last-child,
  table td:last-child {
    position: sticky;
    right: 0;
    z-index: 2;
    background: var(--panel);
    box-shadow: -2px 0 6px -3px rgba(0,0,0,0.12);
  }
  table thead th:last-child {
    background: var(--bg-soft);
    z-index: 3;
  }
  tr:hover td:last-child {
    background-color: #EEF1F3;
  }
  .action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  }
  .btn-action {
    padding: 6px 12px;
    font-size: 12px;
    font-weight: 600;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    transition: all 0.15s ease;
  }
  .btn-action.approve {
    background: var(--green-soft);
    color: var(--green);
  }
  .btn-action.approve:hover {
    background: var(--green);
    color: #fff;
  }
  .btn-action.reject {
    background: var(--red-soft);
    color: var(--red);
  }
  .btn-action.reject:hover {
    background: var(--red);
    color: #fff;
  }
  .btn-action.complete {
    background: var(--blue-soft);
    color: var(--blue);
  }
  .btn-action.complete:hover {
    background: var(--blue);
    color: #fff;
  }
  .btn-action.edit-btn {
    background: var(--bg-soft);
    color: var(--ink);
  }
  .btn-action.edit-btn:hover {
    background: var(--line);
  }
  
  /* ---------- vehicle grid ---------- */
  .vehicle-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 18px;
    margin-bottom: 40px;
  }
  .vehicle-card {
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 20px;
    display: flex;
    flex-direction: column;
    position: relative;
    transition: all 0.2s ease;
  }
  .vehicle-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px -10px rgba(19,26,36,0.15);
    border-color: var(--ink-soft);
  }
  .vehicle-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 14px;
  }
  .vehicle-type {
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    text-transform: uppercase;
    color: var(--ink-soft);
    background: var(--bg-soft);
    padding: 2px 6px;
    border-radius: 4px;
  }
  .vehicle-body {
    flex: 1;
  }
  .vehicle-name-full {
    font-size: 18px;
    font-weight: 700;
    margin: 0 0 10px;
    color: var(--ink);
  }
  .vehicle-notes {
    font-size: 12.5px;
    color: var(--ink-soft);
    line-height: 1.4;
    margin-bottom: 16px;
  }
  .vehicle-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid var(--line);
    padding-top: 12px;
    margin-top: auto;
  }
  .admin-controls {
    display: none; /* Controlled by JS based on role */
    gap: 8px;
    margin-top: 12px;
    padding-top: 12px;
    border-top: 1px dashed var(--line);
  }
  
  /* ---------- modals & forms ---------- */
  .modal-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(19, 26, 36, 0.6);
    backdrop-filter: blur(4px);
    z-index: 100;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
    animation: fadeIn 0.18s ease-out;
    /* Same GPU-layer fix as header: avoids stale blur artifacts in Chromium browsers */
    transform: translateZ(0);
    will-change: transform;
  }
  .modal-overlay.active {
    display: flex;
  }
  .modal-box {
    background: var(--panel);
    border-radius: 16px;
    width: 100%;
    max-width: 520px;
    box-shadow: 0 24px 48px -12px rgba(19,26,36,0.5);
    border: 1px solid var(--line);
    overflow: hidden;
    animation: slideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  }
  @keyframes slideUp {
    from { transform: translateY(24px) scale(0.96); opacity: 0; }
    to { transform: translateY(0) scale(1); opacity: 1; }
  }
  .modal-header {
    background: var(--bg-soft);
    padding: 18px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--line);
  }
  .modal-title {
    font-family: 'Barlow Condensed', sans-serif;
    font-weight: 700;
    font-size: 24px;
    text-transform: uppercase;
    margin: 0;
    letter-spacing: 0.01em;
  }
  .modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: var(--ink-soft);
    line-height: 1;
    padding: 0;
  }
  .modal-close:hover {
    color: var(--ink);
  }
  .modal-body {
    padding: 24px;
    max-height: 70vh;
    overflow-y: auto;
  }
  .form-group {
    margin-bottom: 18px;
  }
  .form-group:last-child {
    margin-bottom: 0;
  }
  .form-label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 6px;
    color: var(--ink);
  }
  .form-input {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid var(--line);
    border-radius: 8px;
    font-size: 14px;
    color: var(--ink);
    background: #fff;
    outline: none;
    font-family: 'Inter', sans-serif;
    transition: border-color 0.15s ease;
  }
  .form-input:focus {
    border-color: var(--blue);
  }
  select.form-input {
    appearance: none;
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%234B5563' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    background-size: 16px;
    padding-right: 40px;
  }
  textarea.form-input {
    resize: vertical;
    min-height: 80px;
  }
  .modal-footer {
    padding: 16px 24px;
    border-top: 1px solid var(--line);
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    background: rgba(233,237,240,0.4);
  }
  .btn-secondary {
    background: none;
    border: 1px solid var(--line);
    color: var(--ink-soft);
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s ease;
  }
  .btn-secondary:hover {
    background: var(--bg-soft);
    color: var(--ink);
    border-color: var(--ink-soft);
  }
  
  /* Multi-step loan style */
  .step-container {
    display: none;
  }
  .step-container.active {
    display: block;
    animation: fadeIn 0.2s ease-out;
  }
  .step-badge {
    display: inline-block;
    background: var(--blue-soft);
    color: var(--blue);
    font-size: 11px;
    font-weight: 700;
    padding: 3px 8px;
    border-radius: 5px;
    margin-bottom: 12px;
    text-transform: uppercase;
  }
  .info-highlight {
    background: var(--bg-soft);
    border-radius: 8px;
    padding: 12px 16px;
    font-size: 13.5px;
    margin-bottom: 16px;
    line-height: 1.5;
    border-left: 4px solid var(--blue);
  }
  
  /* Lightbox style for large images view */
  .lightbox-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(19, 26, 36, 0.95);
    z-index: 9999;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
  }
  .lightbox-overlay.active {
    display: flex;
  }
  .lightbox-img {
    max-width: 90%;
    max-height: 90%;
    border-radius: 8px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
  }
  .lightbox-close {
    position: absolute;
    top: 20px; right: 20px;
    color: white;
    font-size: 32px;
    cursor: pointer;
    background: none;
    border: none;
  }
  
  /* ---------- toast alerts ---------- */
  .toast-container {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 1000;
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 420px;
    width: 100%;
  }
  .toast {
    background: var(--panel);
    border-left: 5px solid var(--blue);
    border-radius: 8px;
    box-shadow: 0 12px 24px -6px rgba(19,26,36,0.2);
    padding: 16px 20px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    transform: translateX(120%);
    opacity: 0;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .toast.show {
    transform: translateX(0);
    opacity: 1;
  }
  .toast.success {
    border-left-color: var(--green);
  }
  .toast.error {
    border-left-color: var(--red);
  }
  .toast.warning {
    border-left-color: var(--amber);
  }
  .toast-content {
    flex: 1;
  }
  .toast-title {
    font-weight: 700;
    font-size: 14px;
    margin-bottom: 4px;
  }
  .toast-desc {
    font-size: 13px;
    color: var(--ink-soft);
    line-height: 1.4;
    word-break: break-word;
  }
  .toast-close {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    color: var(--ink-soft);
    padding: 0;
  }
  
  footer{
    border-top:1px solid var(--line);
    padding:24px 40px;
    display:flex;justify-content:space-between;align-items:center;
    font-size:12.5px;color:var(--ink-soft);
    max-width:1180px;margin:56px auto 0;
    width: 100%;
  }
  
  /* ---------- responsive details ---------- */
  @media (max-width:860px){
    header{padding:14px 20px; flex-direction:column; gap:12px; align-items:stretch;}
    nav{flex-direction:column; gap:12px; align-items:stretch;}
    nav .links{display:flex; flex-wrap:wrap; gap:10px; justify-content:center;}
    .hero{padding:40px 20px 20px;}
    .cluster{grid-template-columns:repeat(2,1fr);max-width:100%;}
    .module-grid{grid-template-columns:1fr;}
    .modules,.activity,.view-container{padding-left:20px;padding-right:20px;}
    .activity-row{grid-template-columns:70px 1fr 90px;}
    .activity-row .col-tanggal, .activity-row .col-plat{display:none;}
    footer{padding:20px;flex-direction:column;gap:8px;align-items:flex-start;}
    .view-header {flex-direction: column; align-items: flex-start; gap: 14px;}
    .control-bar {flex-direction: column; align-items: stretch;}
    .search-wrapper {max-width: 100%;}
    .filter-group {overflow-x: auto; padding-bottom: 4px;}
    th, td {padding: 12px 14px; white-space: nowrap;}
    .action-buttons {flex-direction: column; gap: 6px;}
    .btn-action {padding: 9px 14px; font-size: 13px; width: 100%; justify-content: center;}

    /* keep the first column visible while swiping, so admin always knows which row/plate this action belongs to */
    table th:first-child, table td:first-child {
      position: sticky;
      left: 0;
      z-index: 2;
      background: var(--panel);
      box-shadow: 2px 0 6px -3px rgba(0,0,0,0.12);
    }
    table thead th:first-child { background: var(--bg-soft); z-index: 3; }

    /* swipe hint bar shown above scrollable tables on mobile */
    .swipe-hint {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      font-size: 12px;
      font-weight: 600;
      color: var(--ink-soft);
      background: var(--bg-soft);
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 8px 10px;
      margin-bottom: 8px;
      animation: swipeHintPulse 1.6s ease-in-out infinite;
    }
    .swipe-hint.hide { display: none; }
    @keyframes swipeHintPulse {
      0%, 100% { opacity: 0.65; transform: translateX(0); }
      50% { opacity: 1; transform: translateX(3px); }
    }
  }
  @media (min-width: 861px){
    .swipe-hint { display: none !important; }
  }
</style>
</head>
<body>

<header>
  <div class="brand">
    <img src="static/images/logo.png" alt="Logo Potensi Bumi Sakti" class="brand-logo" />
    <div class="brand-text">
      <div class="brand-name">SIMKEN</div>
      <div class="brand-sub">Sistem Informasi Manajemen Kendaraan</div>
    </div>
  </div>
  <nav>
    <div class="links">
      <a onclick="switchSection('dashboard')" id="nav-dashboard" class="active">Beranda</a>
      <a onclick="switchSection('loans')" id="nav-loans">Peminjaman</a>
      <a onclick="switchSection('returns')" id="nav-returns">Pengembalian</a>
      <a onclick="switchSection('maint')" id="nav-maint">Maintenance</a>
      <a onclick="switchSection('vehicles')" id="nav-vehicles">Armada</a>
      <a href="https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=tux_1ityk0a_EGaQOEupG634kUJEeqNJvtZFAAGOOFRUMFNXWUpTWjlMNk1TTjlCNEdPVkZLQ1hTWC4u&amp;origin=Invitation&amp;channel=0" target="_blank" id="nav-p2h">P2H</a>
      <a onclick="switchSection('employees')" id="nav-employees" style="display:none;">Karyawan</a> <!-- GA Only -->
    </div>
    <div style="display:flex; align-items:center;">
      <span class="admin-banner" id="ga-badge" title="Klik untuk Edit Profil GA Saya" onclick="openProfileModal()">GA Admin</span>
      <button class="btn-primary" id="btn-request-loan" onclick="openModal('loan-modal')" style="margin-right:10px;">+ Ajukan Peminjaman</button>
      <button class="btn-secondary-dark" id="btn-login-toggle" onclick="toggleGALoginState()">Login GA</button>
    </div>
  </nav>
</header>

<main>
  <!-- ==================== VIEW 1: DASHBOARD ==================== -->
  <section class="content-section active" id="sec-dashboard">
    <div class="hero">
      <div class="eyebrow">Dasbor Armada Internal</div>
      <h1>Satu dasbor untuk seluruh armada kendaraan perusahaan</h1>
      <p class="lede">Pantau ketersediaan kendaraan, kelola pengajuan peminjaman, dan jadwalkan perawatan berkala — semua dari satu tempat, tanpa bolak-balik grup WhatsApp atau lembar Excel.</p>
      
      <div class="cluster">
        <div class="gauge">
          <div class="plate" id="cnt-total">0</div>
          <div class="gauge-label">Total Kendaraan</div>
          <span class="gauge-tag tag-total">Seluruh Armada</span>
        </div>
        <div class="gauge status-ready">
          <div class="plate" id="cnt-ready">0</div>
          <div class="gauge-label">Siap Dipinjam</div>
          <span class="gauge-tag tag-ready">Tersedia</span>
        </div>
        <div class="gauge status-loan">
          <div class="plate" id="cnt-loaned">0</div>
          <div class="gauge-label">Sedang Dipinjam</div>
          <span class="gauge-tag tag-loan">Berjalan</span>
        </div>
        <div class="gauge status-maint">
          <div class="plate" id="cnt-maint">0</div>
          <div class="gauge-label">Dalam Maintenance</div>
          <span class="gauge-tag tag-maint">Bengkel</span>
        </div>
      </div>
    </div>
    
    <div class="lane"><div class="lane-line"></div></div>
    
    <div class="modules">
      <div class="section-head">
        <div class="section-title">Dua Modul Utama</div>
        <div class="section-note">Pilih modul untuk mengelola operasional armada</div>
      </div>
      
      <div class="module-grid">
        <div class="module-card loan" onclick="switchSection('loans')">
          <div class="module-top">
            <span class="module-code">PJM</span>
            <div class="module-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#2A5FA8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13l1.5-4.5A2 2 0 0 1 6.4 7h11.2a2 2 0 0 1 1.9 1.5L21 13"/><rect x="2" y="13" width="20" height="6" rx="1.5"/><circle cx="7" cy="19.5" r="1.5"/><circle cx="17" cy="19.5" r="1.5"/></svg>
            </div>
          </div>
          <h3 class="module-title">Peminjaman Kendaraan</h3>
          <p class="module-desc">Ajukan peminjaman kendaraan dinas, cek jadwal ketersediaan, dan lihat status persetujuan secara real-time.</p>
          <div class="module-meta">
            <div><div class="meta-num" id="card-loan-active">0</div><div class="meta-label">Peminjaman aktif</div></div>
            <div><div class="meta-num" id="card-loan-pending">0</div><div class="meta-label">Menunggu persetujuan</div></div>
          </div>
          <span class="module-cta">Buka modul peminjaman
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </span>
        </div>
        
        <div class="module-card maint" onclick="switchSection('maint')">
          <div class="module-top">
            <span class="module-code">SVC</span>
            <div class="module-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#C3630A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 1-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 1 5.4-5.4l-2.6 2.6-2-2z"/></svg>
            </div>
          </div>
          <h3 class="module-title">Maintenance Kendaraan</h3>
          <p class="module-desc">Jadwalkan servis berkala, catat laporan kerusakan, dan lacak riwayat perawatan tiap kendaraan.</p>
          <div class="module-meta">
            <div><div class="meta-num" id="card-maint-active">0</div><div class="meta-label">Sedang diservis</div></div>
            <div><div class="meta-num">30</div><div class="meta-label">Hari garansi servis</div></div>
          </div>
          <span class="module-cta">Buka modul maintenance
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </span>
        </div>
      </div>
    </div>
    
    <div class="activity" id="aktivitas">
      <div class="section-head" style="align-items:center;">
        <div style="display:flex; flex-direction:column;">
          <div class="section-title">Aktivitas Terbaru</div>
          <div class="section-note">Log aktivitas sistem operasional kendaraan</div>
        </div>
        <button class="btn-primary ga-only" id="btn-clear-activities" onclick="clearAllActivities()" style="background-color:var(--red); font-size:12px; padding:6px 12px; display:none;">
          🗑️ Bersihkan Semua Log
        </button>
      </div>
      <div class="activity-list" id="activity-feed">
        <div class="activity-row head">
          <div class="col-plat">Plat</div>
          <div>Kendaraan &amp; Aktivitas</div>
          <div>PIC</div>
          <div>Status</div>
          <div class="col-tanggal">Waktu</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ==================== VIEW 2: PEMINJAMAN ==================== -->
  <section class="content-section" id="sec-loans">
    <div class="view-container">
      <div class="view-header">
        <div class="view-title-container">
          <h2>Modul Peminjaman</h2>
          <p class="view-subtitle">Kelola pengajuan peminjaman kendaraan operasional internal</p>
        </div>
        <button class="btn-primary" onclick="openModal('loan-modal')">+ Ajukan Peminjaman</button>
      </div>
      
      <!-- Filter and Recap Control Card Widget -->
      <div class="control-bar" style="background:var(--panel); border:1px solid var(--line); padding:20px; border-radius:12px; margin-bottom:25px; display:flex; flex-direction:column; gap:16px;">
        <!-- Row 1: Search & Status Filter pills -->
        <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; width:100%; flex-wrap:wrap;">
          <div class="search-wrapper" style="margin-bottom:0; flex:1; max-width:400px;">
            <span class="search-icon">🔍</span>
            <input type="text" class="search-input" id="loan-search" placeholder="Cari nama, divisi, plat, atau tujuan sewa..." oninput="filterLoans()">
          </div>
          <div class="filter-group">
            <button class="filter-btn active" onclick="filterLoanStatus('ALL', this)">Semua Status</button>
            <button class="filter-btn" onclick="filterLoanStatus('Pending', this)">Menunggu</button>
            <button class="filter-btn" onclick="filterLoanStatus('Approved', this)">Berjalan</button>
            <button class="filter-btn" onclick="filterLoanStatus('Completed', this)">Selesai</button>
            <button class="filter-btn" onclick="filterLoanStatus('Rejected', this)">Ditolak</button>
          </div>
        </div>
        
        <!-- Row 2: Date Filters & Export Buttons (Only visible when GA is logged in!) -->
        <div class="ga-only" id="admin-export-panel" style="display:none; border-top:1px dashed var(--line); padding-top:16px; width:100%;">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap; width:100%;">
            <!-- Date range inputs -->
            <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
              <span style="font-size:13px; font-weight:700; color:var(--ink);">Rekap Laporan (Tanggal Mulai):</span>
              <input type="date" id="loan-filter-start" class="form-input" style="width:140px; padding:6px 12px; font-size:13px;" onchange="filterLoans()">
              <span style="font-size:13px; color:var(--ink-soft);">s/d</span>
              <input type="date" id="loan-filter-end" class="form-input" style="width:140px; padding:6px 12px; font-size:13px;" onchange="filterLoans()">
              <button class="btn-secondary" onclick="clearDateFilters()" style="padding:6px 12px; font-size:13px; height: 34px;">Reset</button>
            </div>
            
            <!-- Export buttons with nice brand colors -->
            <div style="display:flex; gap:10px;">
              <button class="btn-primary" onclick="exportToExcel()" style="background-color:#1B8A55; font-size:13px; padding:8px 16px; height: 34px;">
                📊 Export ke Excel
              </button>
              <button class="btn-primary" onclick="exportToPDF()" style="background-color:#DC2626; font-size:13px; padding:8px 16px; height: 34px;">
                📄 Export ke PDF
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Plat</th>
              <th>Kendaraan</th>
              <th>Peminjam (PIC)</th>
              <th>Keperluan / Tujuan</th>
              <th>Waktu Pinjam</th>
              <th>Estimasi Selesai</th>
              <th>Pengembalian</th>
              <th>Info BBM</th>
              <th>Status</th>
              <th style="width: 150px;" class="col-actions-header">Aksi Admin</th>
            </tr>
          </thead>
          <tbody id="loans-table-body">
            <!-- Loaded dynamically -->
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- ==================== VIEW 2B: PENGEMBALIAN & PENGISIAN BBM ==================== -->
  <section class="content-section" id="sec-returns">
    <div class="view-container">
      <div class="view-header">
        <div class="view-title-container">
          <h2>Modul Pengembalian &amp; Pengisian BBM</h2>
          <p class="view-subtitle">Proses pengembalian kendaraan yang sedang dipinjam beserta catatan pengisian BBM</p>
        </div>
      </div>

      <div class="control-bar">
        <div class="search-wrapper">
          <span class="search-icon">🔍</span>
          <input type="text" class="search-input" id="return-search" placeholder="Cari nama peminjam, plat, atau kendaraan..." oninput="renderReturns()">
        </div>
      </div>

      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Plat</th>
              <th>Kendaraan</th>
              <th>Peminjam (PIC)</th>
              <th>Keperluan / Tujuan</th>
              <th>Waktu Pinjam</th>
              <th>Estimasi Selesai</th>
              <th style="width: 170px;">Aksi</th>
            </tr>
          </thead>
          <tbody id="returns-table-body">
            <!-- Loaded dynamically: daftar peminjaman berstatus Berjalan -->
          </tbody>
        </table>
      </div>

      <div class="section-head" style="margin-top:40px; align-items:center;">
        <div style="display:flex; flex-direction:column;">
          <div class="section-title">Riwayat Pengisian BBM</div>
          <div class="section-note">Catatan pengisian bahan bakar setiap kendaraan operasional</div>
        </div>
      </div>

      <div class="control-bar" style="margin-top:16px;">
        <div class="search-wrapper">
          <span class="search-icon">🔍</span>
          <input type="text" class="search-input" id="fuel-search" placeholder="Cari nama, plat, atau lokasi pengisian..." oninput="renderFuelFillings()">
        </div>
      </div>

      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Plat</th>
              <th>Kendaraan</th>
              <th>Peminjam / PIC</th>
              <th>Jenis BBM</th>
              <th>Liter</th>
              <th>Harga/Liter</th>
              <th>Total Harga</th>
              <th>Lokasi / Nota</th>
              <th>Paraf Atasan</th>
              <th style="width: 90px;" class="col-actions-fuel-header">Aksi</th>
            </tr>
          </thead>
          <tbody id="fuel-table-body">
            <!-- Loaded dynamically -->
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- ==================== VIEW 3: MAINTENANCE ==================== -->
  <section class="content-section" id="sec-maint">
    <div class="view-container">
      <div class="view-header">
        <div class="view-title-container">
          <h2>Modul Maintenance</h2>
          <p class="view-subtitle">Jadwalkan perawatan berkala dan perbaikan kerusakan armada (Halaman GA)</p>
        </div>
        <button class="btn-primary ga-only" onclick="openModal('maint-modal')">+ Kirim ke Bengkel</button>
      </div>
      
      <div class="control-bar">
        <div class="search-wrapper">
          <span class="search-icon">🔍</span>
          <input type="text" class="search-input" id="maint-search" placeholder="Cari kendaraan, bengkel, atau keluhan..." oninput="filterMaintenances()">
        </div>
        <div class="filter-group">
          <button class="filter-btn active" onclick="filterMaintStatus('ALL', this)">Semua</button>
          <button class="filter-btn" onclick="filterMaintStatus('Ongoing', this)">Sedang Servis</button>
          <button class="filter-btn" onclick="filterMaintStatus('Completed', this)">Selesai Servis</button>
        </div>
      </div>
      
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Plat</th>
              <th>Kendaraan</th>
              <th>Nama Bengkel</th>
              <th>Deskripsi Masalah / Servis</th>
              <th>Biaya Servis</th>
              <th>Mulai</th>
              <th>Selesai</th>
              <th>Status</th>
              <th style="width: 130px;" class="col-actions-maint-header">Aksi</th>
            </tr>
          </thead>
          <tbody id="maint-table-body">
            <!-- Loaded dynamically -->
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- ==================== VIEW 4: VEHICLES FLEET ==================== -->
  <section class="content-section" id="sec-vehicles">
    <div class="view-container">
      <div class="view-header">
        <div class="view-title-container">
          <h2>Daftar Armada Kendaraan</h2>
          <p class="view-subtitle">Manajemen seluruh jajaran aset kendaraan perusahaan</p>
        </div>
        <button class="btn-primary ga-only" onclick="openModal('vehicle-modal')">+ Tambah Unit</button>
      </div>
      
      <div class="control-bar">
        <div class="search-wrapper">
          <span class="search-icon">🔍</span>
          <input type="text" class="search-input" id="vehicle-search" placeholder="Cari plat, merk, model, tipe..." oninput="filterVehicles()">
        </div>
        <div class="filter-group">
          <button class="filter-btn active" onclick="filterVehicleStatus('ALL', this)">Semua</button>
          <button class="filter-btn" onclick="filterVehicleStatus('Ready', this)">Ready</button>
          <button class="filter-btn" onclick="filterVehicleStatus('Loaned', this)">Dipinjam</button>
          <button class="filter-btn" onclick="filterVehicleStatus('Maintenance', this)">Bengkel</button>
        </div>
      </div>
      
      <div class="vehicle-grid" id="vehicles-grid-container">
        <!-- Loaded dynamically -->
      </div>
    </div>
  </section>

  <!-- ==================== VIEW 5: EMPLOYEES LIST (GA ONLY) ==================== -->
  <section class="content-section" id="sec-employees">
    <div class="view-container">
      <div class="view-header">
        <div class="view-title-container">
          <h2>Daftar Karyawan (Menu GA)</h2>
          <p class="view-subtitle">Kelola data karyawan internal penerima hak peminjaman kendaraan</p>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button class="btn-secondary" onclick="resequenceEmployees()" title="Rapikan kembali nomor #EMP-1, #EMP-2, dst tanpa ada nomor yang terlompat">🔀 Urutkan Ulang ID</button>
          <button class="btn-secondary" onclick="openModal('import-employee-modal')">📥 Import Excel</button>
          <button class="btn-primary" onclick="openModal('employee-modal')">+ Tambah Karyawan</button>
        </div>
      </div>
      
      <div class="control-bar">
        <div class="search-wrapper">
          <span class="search-icon">🔍</span>
          <input type="text" class="search-input" id="employee-search" placeholder="Cari nama, NIK, divisi, atau email..." oninput="filterEmployees()">
        </div>
      </div>

      <div id="employee-bulk-bar" style="display:none; align-items:center; justify-content:space-between; background:var(--blue-soft); border:1px solid var(--blue); border-radius:10px; padding:10px 16px; margin-bottom:14px;">
        <span id="employee-bulk-count" style="font-weight:600; color:var(--blue);">0 karyawan dipilih</span>
        <div style="display:flex; gap:8px;">
          <button type="button" class="btn-secondary" onclick="clearEmployeeSelection()">Batalkan</button>
          <button type="button" class="btn-action reject" onclick="bulkDeleteEmployees()">🗑️ Hapus Terpilih</button>
        </div>
      </div>
      
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th style="width:40px;"><input type="checkbox" id="employee-select-all" onchange="toggleSelectAllEmployees(this)"></th>
              <th>ID Karyawan</th>
              <th>Nama Karyawan</th>
              <th>NIK</th>
              <th>Divisi / Departemen</th>
              <th>Email Kantor</th>
              <th style="width: 150px;">Aksi</th>
            </tr>
          </thead>
          <tbody id="employees-table-body">
            <!-- Loaded dynamically -->
          </tbody>
        </table>
      </div>
    </div>
  </section>
</main>

<!-- ==================== MODALS ==================== -->

<!-- Modal: Login GA -->
<div class="modal-overlay" id="login-modal">
  <div class="modal-box" style="max-width:400px;">
    <div class="modal-header">
      <h3 class="modal-title">Login Admin GA</h3>
      <button class="modal-close" onclick="closeModal('login-modal')">&times;</button>
    </div>
    <form id="form-login" onsubmit="submitGALogin(event)">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label" for="login-user">Username</label>
          <input type="text" id="login-user" class="form-input" placeholder="Masukkan username..." required>
        </div>
        <div class="form-group">
          <label class="form-label" for="login-pass">Password</label>
          <input type="password" id="login-pass" class="form-input" placeholder="Masukkan password..." required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('login-modal')">Batal</button>
        <button type="submit" class="btn-primary">Masuk</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Edit Profil GA -->
<div class="modal-overlay" id="profile-modal">
  <div class="modal-box" style="max-width:450px;">
    <div class="modal-header">
      <h3 class="modal-title">Edit Profil GA Saya</h3>
      <button class="modal-close" onclick="closeModal('profile-modal')">&times;</button>
    </div>
    <form id="form-profile" onsubmit="submitProfileUpdate(event)">
      <div class="modal-body">
        <p class="view-subtitle" style="margin-bottom:18px;">Ubah data No HP (WhatsApp) dan email Anda untuk memperbarui target notifikasi reminder sewa.</p>
        <div class="form-group">
          <label class="form-label" for="prof-username">Username (Sistem)</label>
          <input type="text" id="prof-username" class="form-input mono" style="background-color:var(--bg-soft);" readonly>
        </div>
        <div class="form-group">
          <label class="form-label" for="prof-name">Nama Lengkap GA</label>
          <input type="text" id="prof-name" class="form-input" placeholder="Masukkan nama lengkap..." required>
        </div>
        <div class="form-group">
          <label class="form-label" for="prof-phone">No HP (WhatsApp Notifikasi)</label>
          <input type="text" id="prof-phone" class="form-input mono" placeholder="Contoh: 081234567890" required>
        </div>
        <div class="form-group">
          <label class="form-label" for="prof-email">Email Notifikasi</label>
          <input type="email" id="prof-email" class="form-input" placeholder="Contoh: ga@potensibumi.co.id" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('profile-modal')">Batal</button>
        <button type="submit" class="btn-primary">Simpan Profil</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal 1: Ajukan Peminjaman (Sederhana, Langsung Gabung & Tanpa SN/OTP! 🚀✅) -->
<div class="modal-overlay" id="loan-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 class="modal-title" id="loan-modal-title">Form Peminjaman Kendaraan</h3>
      <button class="modal-close" onclick="closeModal('loan-modal')">&times;</button>
    </div>
    
    <!-- Step 1: Direct Form (Bebas Stuck, Digabung & Tanpa OTP) -->
    <div id="loan-step-1" class="step-container active">
      <form id="form-loan" onsubmit="submitLoan(event)">
        <div class="modal-body">
          <span class="step-badge" style="background:var(--blue-soft); color:var(--blue);">Formulir Pengajuan Sewa</span>
          <p class="view-subtitle" style="margin-bottom:20px;">Silakan lengkapi rincian peminjam, armada, supir, tujuan, dan jadwal peminjaman di bawah ini. KM awal dan foto kondisi kendaraan diisi setelah pengajuan melalui Modul Peminjaman.</p>
          
          <div class="form-group">
            <label class="form-label" for="loan-employee-search">Nama Karyawan (Peminjam)</label>
            <div style="position:relative;">
              <input type="text" id="loan-employee-search" class="form-input" placeholder="Ketik nama karyawan (misal: Abdul)..." oninput="onEmployeeSearchInput()" autocomplete="off" required>
              <input type="hidden" id="loan-employee-id" value="">
              
              <!-- Autocomplete Suggestions Dropdown -->
              <div id="employee-suggestions" style="position:absolute; top:100%; left:0; right:0; background:white; border:1px solid var(--line); border-radius:8px; box-shadow:0 10px 25px -10px rgba(0,0,0,0.15); z-index:999; display:none; max-height:200px; overflow-y:auto; margin-top:4px;">
                <!-- Dynamic suggestions are inserted here -->
              </div>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="loan-vehicle">Pilih Kendaraan (Hanya Unit Tersedia)</label>
            <select id="loan-vehicle" class="form-input" required>
              <option value="" disabled selected>⏳ Memuat kendaraan tersedia...</option>
            </select>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap:12px;">
            <div class="form-group">
              <label class="form-label" for="loan-driver">Opsi Driver / Supir</label>
              <select id="loan-driver" class="form-input" onchange="onDriverSelectChange()" required>
                <option value="Bawa Sendiri">Bawa Sendiri (Tanpa Driver)</option>
                <option value="Dengan Driver">Dengan Driver Perusahaan</option>
                <option value="Ketik Manual">Ketik Manual Nama Supir...</option>
              </select>
              <input type="text" id="loan-driver-name" class="form-input" placeholder="Nama supir (misal: Budi)..." style="display:none; margin-top:8px;" required>
            </div>

          </div>

          <div class="form-group">
            <label class="form-label" for="loan-purpose">Keperluan / Tujuan Peminjaman</label>
            <textarea id="loan-purpose" class="form-input" placeholder="Contoh: Perjalanan dinas peninjauan proyek luar kota..." required></textarea>
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap:12px;">
            <div class="form-group">
              <label class="form-label" for="loan-start">Waktu Mulai Pinjam</label>
              <input type="datetime-local" id="loan-start" class="form-input" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="loan-end">Estimasi Kembali</label>
              <input type="datetime-local" id="loan-end" class="form-input" required>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn-secondary" onclick="closeModal('loan-modal')">Batal</button>
          <button type="submit" class="btn-primary">Kirim Pengajuan Peminjaman</button>
        </div>
      </form>
    </div>

    <!-- Step 3: Success Screen with WhatsApp Contact Buttons -->
    <div id="loan-step-3" class="step-container">
      <div class="modal-body" style="text-align:center; padding: 32px 24px;">
        <div style="font-size: 56px; margin-bottom: 16px;">✅</div>
        <h3 class="modal-title" style="margin-bottom: 8px; font-size:24px; font-family:'Barlow Condensed',sans-serif;">Pengajuan Sukses!</h3>
        <p class="view-subtitle" style="margin-bottom: 24px; font-size:14.5px; line-height:1.5;">Peminjaman Anda berhasil diajukan dan sekarang berstatus <strong style="color:var(--amber);">Menunggu Approval dari Tim GA</strong>.</p>
        
        <div style="border-top:1px solid var(--line); padding-top:20px; margin-top:20px; text-align:left;">
          <label class="form-label" style="text-align:center; display:block; font-size:13.5px; margin-bottom:16px; font-weight:700; color:var(--ink);">
            📱 Hubungi Staf GA via WhatsApp untuk Approval Cepat:
          </label>
          <div id="wa-buttons-container" style="display:flex; flex-direction:column; gap:10px;">
            <!-- Generated dynamically -->
          </div>
        </div>
      </div>
      <div class="modal-footer" style="justify-content:center; background:none; border-top:none;">
        <button type="button" class="btn-primary" onclick="closeModal('loan-modal')" style="width:100%;">Selesai &amp; Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Edit KM Awal & Foto Peminjaman (Bisa diedit sendiri oleh peminjam, tanpa perlu admin) -->
<div class="modal-overlay" id="edit-loan-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 class="modal-title">Tulis KM Awal &amp; Foto KM atau Kondisi Kendaraan</h3>
      <button class="modal-close" onclick="closeModal('edit-loan-modal')">&times;</button>
    </div>
    <form id="form-edit-loan" onsubmit="submitEditLoan(event)">
      <div class="modal-body">
        <p class="view-subtitle" style="margin-bottom:20px; font-size:13px; line-height:1.5;">
          Belum ambil kendaraannya atau baru sempat ambil foto belakangan? Kamu bisa perbarui sendiri KM awal &amp; foto kondisi di sini, tidak perlu menunggu admin GA.
        </p>
        <input type="hidden" id="edit-loan-id" value="">

        <div class="form-group">
          <label class="form-label" for="edit-loan-initial-km">KM Awal Kendaraan</label>
          <input type="number" id="edit-loan-initial-km" class="form-input" placeholder="Masukkan KM awal..." min="0" required>
        </div>

        <div class="form-group">
          <label class="form-label">Foto KM atau Kondisi Fisik Mobil</label>
          <div class="photo-upload-container">
            <label class="photo-trigger-btn" for="edit-loan-photos-uploader" title="Pilih File atau Gunakan Kamera">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
              <span>Ambil / Upload</span>
            </label>
            <input type="file" id="edit-loan-photos-uploader" accept="image/*" multiple onchange="handleEditPhotoUpload(event)" style="display:none;">
            <div id="edit-photos-preview-grid" class="photos-preview-grid"></div>
          </div>
          <p style="font-size:11px; color:var(--ink-soft); margin-top:6px; line-height:1.4;">
            ⚡ Foto lama tetap tersimpan kecuali kamu hapus manual. Foto baru otomatis dikompres agar ringan.
          </p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('edit-loan-modal')">Batal</button>
        <button type="submit" class="btn-primary">Simpan Perubahan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Form Pengembalian Kendaraan + Pengisian BBM -->
<div class="modal-overlay" id="return-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 class="modal-title">Form Pengembalian Kendaraan</h3>
      <button class="modal-close" onclick="closeModal('return-modal')">&times;</button>
    </div>
    <form id="form-return" onsubmit="submitReturn(event)">
      <input type="hidden" id="return-loan-id" value="">
      <div class="modal-body">
        <span class="step-badge" style="background:var(--blue-soft); color:var(--blue);">Formulir Pengembalian</span>

        <!-- Ringkasan Peminjaman -->
        <div id="return-loan-summary" style="background:var(--bg-soft); border:1px solid var(--line); border-radius:10px; padding:14px 16px; margin:16px 0; font-size:13px; line-height:1.6;">
          <!-- Diisi via JS -->
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap:12px;">
          <div class="form-group">
            <label class="form-label" for="return-final-km">KM Akhir Kendaraan</label>
            <input type="number" id="return-final-km" class="form-input" placeholder="Masukkan KM saat kembali..." min="0">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="return-notes">Catatan Kondisi Kendaraan Saat Kembali</label>
          <textarea id="return-notes" class="form-input" placeholder="Contoh: Kondisi baik, tidak ada kerusakan..."></textarea>
        </div>

        <div class="form-group">
          <label class="form-label">Foto Kondisi Kendaraan Saat Kembali (Opsional)</label>
          <div class="photo-upload-container">
            <label class="photo-trigger-btn" for="return-photos-uploader" title="Pilih File atau Gunakan Kamera">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
              <span>Ambil / Upload</span>
            </label>
            <input type="file" id="return-photos-uploader" accept="image/*" multiple onchange="handleReturnPhotoUpload(event)" style="display:none;">
            <div id="return-photos-preview-grid" class="photos-preview-grid"></div>
          </div>
        </div>

        <!-- ============ Pengisian BBM ============ -->
        <div style="border-top:1px dashed var(--line); margin:22px 0 16px; padding-top:16px;">
          <label style="display:flex; align-items:center; gap:8px; font-weight:700; font-size:14px; color:var(--ink); cursor:pointer;">
            <input type="checkbox" id="return-include-fuel" onchange="toggleFuelSection()" style="width:16px; height:16px;">
            ⛽ Sertakan Data Pengisian BBM
          </label>
          <p class="view-subtitle" style="margin-top:6px; margin-bottom:0;">Centang jika kendaraan diisi bahan bakar sebelum/selama peminjaman ini dikembalikan.</p>
        </div>

        <div id="fuel-fields-container" style="display:none;">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap:12px;">
            <div class="form-group">
              <label class="form-label" for="fuel-liter">Jumlah Liter</label>
              <input type="number" id="fuel-liter" class="form-input" placeholder="Contoh: 12" min="0" step="0.01" oninput="computeFuelTotal()">
            </div>
            <div class="form-group">
              <label class="form-label" for="fuel-price">Jumlah Harga per Liter (Rp)</label>
              <input type="number" id="fuel-price" class="form-input" placeholder="Contoh: 12000" min="0" oninput="computeFuelTotal()">
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap:12px;">
            <div class="form-group">
              <label class="form-label" for="fuel-type">Jenis BBM</label>
              <select id="fuel-type" class="form-input">
                <option value="" disabled selected>-- Pilih jenis BBM --</option>
                <option value="1">1. Pertalite</option>
                <option value="2">2. Pertamax</option>
                <option value="3">3. Solar</option>
                <option value="4">4. Dex</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Total Harga</label>
              <input type="text" id="fuel-total-display" class="form-input mono" value="Rp 0" readonly style="background-color:var(--bg-soft); font-weight:700;">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="fuel-location">Lokasi Pengisian BBM / Nota</label>
            <input type="text" id="fuel-location" class="form-input" placeholder="Contoh: SPBU Pertamina Jl. Sudirman No.12">
          </div>

          <div class="form-group">
            <label class="form-label">Foto Nota Pengisian BBM (Opsional)</label>
            <div class="photo-upload-container">
              <label class="photo-trigger-btn" for="fuel-receipt-uploader" title="Pilih File atau Gunakan Kamera">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
                <span>Ambil / Upload Nota</span>
              </label>
              <input type="file" id="fuel-receipt-uploader" accept="image/*" onchange="handleFuelReceiptUpload(event)" style="display:none;">
              <div id="fuel-receipt-preview-grid" class="photos-preview-grid"></div>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="fuel-approver-name">Paraf Atasan</label>
            <input type="text" id="fuel-approver-name" class="form-input" placeholder="Nama atasan (boleh dikosongkan)...">
            <p style="font-size:11px; color:var(--ink-soft); margin-top:6px; line-height:1.4;">
              ℹ️ Boleh dikosongkan — akan diparaf secara elektronik / langsung oleh atasan terkait kemudian.
            </p>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('return-modal')">Batal</button>
        <button type="submit" class="btn-primary">Simpan Pengembalian</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal 2: Jadwal Maintenance -->
<div class="modal-overlay" id="maint-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 class="modal-title">Form Kirim Kendaraan ke Bengkel</h3>
      <button class="modal-close" onclick="closeModal('maint-modal')">&times;</button>
    </div>
    <form id="form-maint" onsubmit="submitMaint(event)">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label" for="maint-vehicle">Pilih Unit Kendaraan</label>
          <select id="maint-vehicle" class="form-input" required>
            <option value="" disabled selected>-- Pilih unit kendaraan --</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="maint-workshop">Nama Bengkel Rekanan</label>
          <input type="text" id="maint-workshop" class="form-input" placeholder="Masukkan nama bengkel..." required>
        </div>
        <div class="form-group">
          <label class="form-label" for="maint-desc">Deskripsi Perbaikan / Masalah</label>
          <textarea id="maint-desc" class="form-input" placeholder="Contoh: Ganti oli mesin, cek kebocoran radiator, ganti filter AC..." required></textarea>
        </div>
        <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap:12px;">
          <div class="form-group">
            <label class="form-label" for="maint-start">Waktu Masuk Bengkel</label>
            <input type="datetime-local" id="maint-start" class="form-input" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="maint-cost">Estimasi Biaya (Rp)</label>
            <input type="number" id="maint-cost" class="form-input" placeholder="0" min="0">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('maint-modal')">Batal</button>
        <button type="submit" class="btn-primary">Kirim Perawatan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal 3: Tambah Kendaraan -->
<div class="modal-overlay" id="vehicle-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 class="modal-title" id="vehicle-modal-title">Form Tambah Armada Baru</h3>
      <button class="modal-close" onclick="closeModal('vehicle-modal')">&times;</button>
    </div>
    <form id="form-vehicle" onsubmit="submitVehicle(event)">
      <input type="hidden" id="veh-edit-id" value="">
      
      <div class="modal-body">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap:12px;">
          <div class="form-group">
            <label class="form-label" for="veh-plate">Nomor Pelat (Plate)</label>
            <input type="text" id="veh-plate" class="form-input" placeholder="Contoh: B 4321 SAK" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="veh-type">Tipe Kendaraan</label>
            <select id="veh-type" class="form-input" required>
              <optgroup label="🚗 Mobil">
                <option value="MPV">MPV</option>
                <option value="SUV">SUV</option>
                <option value="Sedan">Sedan</option>
                <option value="Hatchback">Hatchback</option>
                <option value="Pickup">Pickup</option>
                <option value="Double Cabin">Double Cabin (4x4)</option>
                <option value="Minibus">Minibus</option>
                <option value="Van">Van</option>
                <option value="Box">Mobil Box</option>
                <option value="Truck">Truk</option>
                <option value="Mobil Listrik">Mobil Listrik (EV)</option>
              </optgroup>
              <optgroup label="🏍️ Motor">
                <option value="Motor Bebek">Motor Bebek</option>
                <option value="Motor Matic">Motor Matic</option>
                <option value="Motor Sport">Motor Sport</option>
                <option value="Motor Trail">Motor Trail</option>
                <option value="Motor Cruiser">Motor Cruiser</option>
                <option value="Motor Touring">Motor Touring</option>
                <option value="Motor Listrik">Motor Listrik (EV)</option>
              </optgroup>
            </select>
          </div>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap:12px;">
          <div class="form-group">
            <label class="form-label" for="veh-brand">Merk</label>
            <input type="text" id="veh-brand" class="form-input" placeholder="Contoh: Toyota" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="veh-model">Model / Seri</label>
            <input type="text" id="veh-model" class="form-input" placeholder="Contoh: Yaris Cross" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="veh-notes">Keterangan / Catatan Kondisi</label>
          <textarea id="veh-notes" class="form-input" placeholder="Masukkan detail kondisi awal kendaraan..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('vehicle-modal')">Batal</button>
        <button type="submit" class="btn-primary" id="btn-vehicle-submit">Tambah Armada</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal 4: Tambah/Edit Karyawan -->
<div class="modal-overlay" id="employee-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 class="modal-title" id="employee-modal-title">Form Tambah Karyawan Baru</h3>
      <button class="modal-close" onclick="closeModal('employee-modal')">&times;</button>
    </div>
    <form id="form-employee" onsubmit="submitEmployee(event)">
      <input type="hidden" id="emp-edit-id" value="">
      
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label" for="emp-name">Nama Lengkap Karyawan</label>
          <input type="text" id="emp-name" class="form-input" placeholder="Masukkan nama lengkap..." required>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap:12px;">
          <div class="form-group">
            <label class="form-label" for="emp-nik">NIK (Karyawan)</label>
            <input type="text" id="emp-nik" class="form-input" placeholder="Contoh: 12345022" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="emp-div">Divisi / Departemen</label>
            <input type="text" id="emp-div" class="form-input" placeholder="Contoh: Sales, IT, HR..." required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="emp-email">Email Perusahaan</label>
          <input type="email" id="emp-email" class="form-input" placeholder="Contoh: karyawan@potensibumi.co.id" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('employee-modal')">Batal</button>
        <button type="submit" class="btn-primary" id="btn-employee-submit">Simpan Karyawan</button>
      </div>
    </form>
  </div>
</div>

<!-- Import Karyawan (Excel) Modal -->
<div class="modal-overlay" id="import-employee-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h3 class="modal-title">Import Data Karyawan dari Excel</h3>
      <button class="modal-close" onclick="closeModal('import-employee-modal')">&times;</button>
    </div>
    <form id="form-import-employee" onsubmit="submitImportEmployees(event)">
      <div class="modal-body">
        <p class="view-subtitle" style="margin-bottom:14px;">
          Unggah file Excel (.xlsx) berisi banyak data karyawan sekaligus. Belum punya filenya?
          <a href="static/template_karyawan.xlsx" download style="color:var(--blue); font-weight:600; text-decoration:underline;">Unduh Template Excel</a>
          dulu, isi datanya, lalu unggah kembali di sini.
        </p>
        <div class="form-group">
          <label class="form-label" for="import-employee-file">Pilih File Excel (.xlsx)</label>
          <input type="file" id="import-employee-file" class="form-input" accept=".xlsx" required>
        </div>
        <div style="background:var(--bg-soft); border-radius:8px; padding:10px 14px; font-size:13px; color:var(--ink-soft); line-height:1.6;">
          <strong>Ketentuan format:</strong> gunakan kolom <strong>Nama</strong>, <strong>NIK</strong>, <strong>Divisi</strong>, dan <strong>Email</strong> sesuai template. NIK yang sudah terdaftar otomatis dilewati agar tidak duplikat.
        </div>
        <div id="import-skipped-details" style="display:none; margin-top:12px; background:#fff8ec; border:1px solid #f0d999; border-radius:8px; padding:10px 14px; max-height:180px; overflow-y:auto;"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-secondary" onclick="closeModal('import-employee-modal')">Batal</button>
        <button type="submit" class="btn-primary" id="btn-import-employee-submit">📥 Import Sekarang</button>
      </div>
    </form>
  </div>
</div>

<!-- Lightbox Modal Overlay -->
<div class="lightbox-overlay" id="lightbox" onclick="closeLightbox()">
  <button class="lightbox-close">&times;</button>
  <img id="lightbox-img" class="lightbox-img" src="" alt="View Large" onclick="event.stopPropagation()">
</div>

<!-- ==================== TOAST NOTIFICATIONS ==================== -->
<div class="toast-container" id="toast-box"></div>

<footer>
  <span>SIMKEN — Sistem Informasi Manajemen Kendaraan</span>
  <span>Bumi Sakti Armada · v1.5 (detail-pengembalian-bbm) · GA Team Access Portal</span>
</footer>

<!-- ==================== JAVASCRIPT LOGIC ==================== -->
<script>
  // Global Data Store
  let globalVehicles = [];
  let globalLoans = [];
  let globalMaintenances = [];
  let globalEmployees = [];
  let globalActivities = [];
  let globalFuelFillings = [];
  let filterVehicleState = 'ALL'; // default: tampilkan semua unit tanpa perlu klik tombol filter dulu
  let filterLoanState = 'ALL';    // default: tampilkan semua peminjaman tanpa perlu klik tombol filter dulu
  let filterMaintState = 'ALL';   // default: tampilkan semua data maintenance tanpa perlu klik tombol filter dulu
  
  // Store filtered loans for accurate exporting
  let globalFilteredLoansForExport = [];
  
  // Store Compressed Base64 Photo Uploads
  let loanPhotosBase64 = [];
  let editLoanId = null;
  let editLoanExistingPhotos = []; // kept paths already saved on the server
  let editLoanNewPhotosBase64 = []; // freshly picked photos, not yet uploaded
  let returnPhotosBase64 = [];
  let fuelReceiptPhotoBase64 = null;
  
  // GA Admin Role Authentication State
  let isGALoggedIn = localStorage.getItem('ga_logged_in') === 'true';

  // Section Switching (SPA Router)
  function switchSection(targetId) {
    document.querySelectorAll('.content-section').forEach(sec => {
      sec.classList.remove('active');
    });
    document.querySelectorAll('nav .links a').forEach(link => {
      link.classList.remove('active');
    });
    
    const targetSec = document.getElementById(`sec-${targetId}`);
    if (targetSec) {
      targetSec.classList.add('active');
    }
    
    const targetNavLink = document.getElementById(`nav-${targetId}`);
    if (targetNavLink) {
      targetNavLink.classList.add('active');
    }
    
    window.location.hash = targetId;
    refreshData();
  }

  // Check URL Hash on Load (Robust & Defensive!)
  window.addEventListener('DOMContentLoaded', () => {
    applyGARoleUI();
    const hash = window.location.hash.replace('#', '');
    if (['dashboard', 'loans', 'returns', 'maint', 'vehicles', 'employees'].includes(hash)) {
      if (hash === 'employees' && !isGALoggedIn) {
        switchSection('dashboard');
      } else {
        switchSection(hash);
      }
    } else {
      switchSection('dashboard');
    }
    
    const now = new Date();
    const tzOffset = now.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(now - tzOffset)).toISOString().slice(0, 16);
    
    document.querySelectorAll('input[type="datetime-local"]').forEach(inp => {
      inp.value = localISOTime;
    });

    setupMobileTableSwipeHints();
  });

  // ---------- Mobile table swipe hints ----------
  // Adds a small "← geser →" hint above every scrollable table so users on HP
  // know they can swipe left/right to reach columns/buttons (e.g. Setuju/Tolak)
  // that don't fit on a small screen. Hint disappears after the user swipes once.
  function setupMobileTableSwipeHints() {
    const isMobile = () => window.matchMedia('(max-width:860px)').matches;

    document.querySelectorAll('.table-responsive').forEach(wrapper => {
      if (wrapper.dataset.swipeHintReady) return;
      wrapper.dataset.swipeHintReady = '1';

      const hint = document.createElement('div');
      hint.className = 'swipe-hint';
      hint.innerHTML = '⟵ Geser tabel untuk lihat kolom lainnya (termasuk tombol Aksi) ⟶';
      wrapper.parentNode.insertBefore(hint, wrapper);

      const updateHintVisibility = () => {
        const scrollable = wrapper.scrollWidth > wrapper.clientWidth + 4;
        hint.classList.toggle('hide', !isMobile() || !scrollable);
      };

      wrapper.addEventListener('scroll', () => {
        hint.classList.add('hide');
      }, { passive: true });

      window.addEventListener('resize', updateHintVisibility);
      // Re-check after data finishes rendering into the table (widths can change)
      const observer = new MutationObserver(updateHintVisibility);
      observer.observe(wrapper, { childList: true, subtree: true });

      updateHintVisibility();
    });
  }

  // Modal Open/Close (Updated with full try-catch safety!)
  function openModal(id, isEdit = false) {
    try {
      document.getElementById(id).classList.add('active');
      
if (id === 'loan-modal') {
  resetLoanSteps();
  populateLoanVehicleDropdown();
  // Muat ulang data karyawan setiap kali modal dibuka, jangan andalkan
  // data lama dari load halaman awal yang bisa gagal diam-diam.
  fetchEmployees().catch(() => {
    showToast("Gagal Memuat Karyawan ⚠️", "Data karyawan gagal dimuat. Coba tutup form dan buka lagi, atau refresh halaman.", "error");
  });
}
      if (id === 'maint-modal') populateMaintDropdown();
      
      // Only reset to "add" mode when NOT opened for editing (isEdit=false).
      // This prevents edit forms from being wiped out right after being populated.
      if (id === 'vehicle-modal' && !isEdit) {
        document.getElementById('veh-edit-id').value = "";
        document.getElementById('form-vehicle').reset();
        document.getElementById('vehicle-modal-title').innerText = "Form Tambah Armada Baru";
        document.getElementById('btn-vehicle-submit').innerText = "Tambah Armada";
      }
      if (id === 'employee-modal' && !isEdit) {
        document.getElementById('emp-edit-id').value = "";
        document.getElementById('form-employee').reset();
        document.getElementById('employee-modal-title').innerText = "Form Tambah Karyawan Baru";
        document.getElementById('btn-employee-submit').innerText = "Simpan Karyawan";
      }
      if (id === 'import-employee-modal') {
        document.getElementById('form-import-employee').reset();
        const skippedBox = document.getElementById('import-skipped-details');
        if (skippedBox) { skippedBox.style.display = 'none'; skippedBox.innerHTML = ''; }
      }
    } catch (err) {
      console.error("Error in openModal:", err);
    }
  }
  
  function closeModal(id) {
    try {
      document.getElementById(id).classList.remove('active');
    } catch (err) {
      console.error("Error in closeModal:", err);
    }
  }

  // Lightbox View Large Image
  function viewLargeImage(src) {
    const box = document.getElementById('lightbox');
    const boxImg = document.getElementById('lightbox-img');
    boxImg.src = src;
    box.classList.add('active');
  }
  function closeLightbox() {
    document.getElementById('lightbox').classList.remove('active');
  }

  // GA Admin Role Authentication Toggle
  function toggleGALoginState() {
    if (isGALoggedIn) {
      fetch('api.php?action=ga_logout')
        .then(() => {
          isGALoggedIn = false;
          localStorage.removeItem('ga_logged_in');
          localStorage.removeItem('ga_name');
          applyGARoleUI();
          showToast("Logout Berhasil", "Anda sekarang berada di Mode Pengguna biasa.", "success");
          if (window.location.hash === '#employees') {
            switchSection('dashboard');
          } else {
            refreshData();
          }
        });
    } else {
      openModal('login-modal');
    }
  }

  async function submitGALogin(e) {
    e.preventDefault();
    const payload = {
      username: document.getElementById('login-user').value,
      password: document.getElementById('login-pass').value
    };
    
    try {
      const res = await fetch('api.php?action=ga_login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      
      if (res.ok) {
        isGALoggedIn = true;
        localStorage.setItem('ga_logged_in', 'true');
        localStorage.setItem('ga_name', data.user.name);
        applyGARoleUI();
        closeModal('login-modal');
        document.getElementById('form-login').reset();
        showToast("Login Berhasil", `Selamat datang kembali, ${data.user.name}!`, "success");
        refreshData();
      } else {
        showToast("Login Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server untuk autentikasi", "error");
    }
  }

  // GA Self-Profile Editing
  async function openProfileModal() {
    try {
      const res = await fetch('api.php?action=get_current_ga', { cache: 'no-store' });
      const ga = await res.json();
      
      if (res.ok) {
        document.getElementById('prof-username').value = ga.username;
        document.getElementById('prof-name').value = ga.name;
        document.getElementById('prof-phone').value = ga.phone;
        document.getElementById('prof-email').value = ga.email;
        
        openModal('profile-modal');
      } else {
        showToast("Gagal", "Gagal memuat profil GA Anda", "error");
      }
    } catch (e) {
      showToast("Error", "Terjadi kesalahan koneksi profil", "error");
    }
  }

  async function submitProfileUpdate(e) {
    e.preventDefault();
    const payload = {
      name: document.getElementById('prof-name').value,
      phone: document.getElementById('prof-phone').value,
      email: document.getElementById('prof-email').value
    };
    
    try {
      const res = await fetch('api.php?action=update_ga_profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      
      if (res.ok) {
        showToast("Profil Diperbarui ✅", data.message, "success");
        localStorage.setItem('ga_name', payload.name);
        applyGARoleUI();
        closeModal('profile-modal');
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal mengirim pembaruan profil", "error");
    }
  }

  // Adjust Interface Elements depending on role state (GA Admin vs. Regular Borrower)
  function applyGARoleUI() {
    const banner = document.getElementById('ga-badge');
    const toggleBtn = document.getElementById('btn-login-toggle');
    const employeesNavLink = document.getElementById('nav-employees');
    const exportPanel = document.getElementById('admin-export-panel');
    
    if (isGALoggedIn) {
      const name = localStorage.getItem('ga_name') || 'GA Admin';
      banner.innerHTML = `👤 ${name}`;
      banner.style.display = 'inline-block';
      toggleBtn.innerText = 'Logout';
      toggleBtn.className = 'btn-secondary-dark btn-danger';
      employeesNavLink.style.display = 'inline-block';
      
      if (exportPanel) exportPanel.style.display = 'block';
      
      document.querySelectorAll('.ga-only').forEach(el => el.style.display = 'inline-block');
      
      const actHeader = document.querySelector('.col-actions-header');
      if (actHeader) actHeader.style.display = 'table-cell';
      const maintActHeader = document.querySelector('.col-actions-maint-header');
      if (maintActHeader) maintActHeader.style.display = 'table-cell';
    } else {
      banner.style.display = 'none';
      toggleBtn.innerText = 'Login GA';
      toggleBtn.className = 'btn-secondary-dark';
      employeesNavLink.style.display = 'none';
      
      if (exportPanel) exportPanel.style.display = 'none';
      
      document.querySelectorAll('.ga-only').forEach(el => el.style.display = 'none');
    }
  }

  // Toast Alerts (Supports HTML formatting)
  function showToast(title, desc, type = 'success', persistTime = 0) {
    const container = document.getElementById('toast-box');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    toast.innerHTML = `
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        <div class="toast-desc">${desc}</div>
      </div>
      <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    `;
    
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 50);
    
    const timeout = persistTime || (type === 'success' && desc.includes('WhatsApp') ? 15000 : 4500);
    setTimeout(() => {
      if (toast && toast.parentElement) {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
      }
    }, timeout);
  }

  // Fetch Data Methods
  async function refreshData() {
    await fetchDashboard();
    await fetchVehicles();
    await fetchLoans();
    await fetchMaintenances();
    await fetchEmployees();
    await fetchFuelFillings();
    applyGARoleUI();
  }

  async function fetchDashboard() {
    try {
      const res = await fetch('api.php?action=dashboard', { cache: 'no-store' });
      const data = await res.json();
      
      document.getElementById('cnt-total').innerText = String(data.counts.total).padStart(2, '0');
      document.getElementById('cnt-ready').innerText = String(data.counts.ready).padStart(2, '0');
      document.getElementById('cnt-loaned').innerText = String(data.counts.loaned).padStart(2, '0');
      document.getElementById('cnt-maint').innerText = String(data.counts.maintenance).padStart(2, '0');
      
      document.getElementById('card-loan-active').innerText = data.counts.loaned;
      document.getElementById('card-loan-pending').innerText = data.pending_loans_count;
      document.getElementById('card-maint-active').innerText = data.counts.maintenance;
      
      const feed = document.getElementById('activity-feed');
      if (!feed) return;
      
      const gridClass = isGALoggedIn ? 'admin-grid' : '';
      let rowsHTML = `
        <div class="activity-row head ${gridClass}">
          <div class="col-plat">Plat</div>
          <div>Kendaraan &amp; Aktivitas</div>
          <div>PIC</div>
          <div>Status</div>
          <div class="col-tanggal">Waktu</div>
          ${isGALoggedIn ? '<div>Aksi</div>' : ''}
        </div>
      `;
      
      data.activities.forEach(act => {
        let pillClass = 'pill-tertunda';
        let actionLabel = 'Umum';
        
        if (act.action_type.includes('Loan Approved')) {
          pillClass = 'pill-berjalan';
          actionLabel = 'Berjalan';
        } else if (act.action_type.includes('Loan Completed')) {
          pillClass = 'pill-selesai';
          actionLabel = 'Selesai';
        } else if (act.action_type.includes('Loan Rejected')) {
          pillClass = 'pill-ditolak';
          actionLabel = 'Ditolak';
        } else if (act.action_type.includes('Maintenance')) {
          pillClass = 'pill-servis';
          actionLabel = 'Servis';
        }
        
        rowsHTML += `
          <div class="activity-row ${gridClass}">
            <div class="col-plat"><span class="mini-plate">${act.plate_number}</span></div>
            <div><strong>${act.vehicle_name}</strong> — ${act.description}</div>
            <div>${act.pic_name}</div>
            <div><span class="status-pill ${pillClass}">${actionLabel}</span></div>
            <div class="col-tanggal row-time">${act.timestamp}</div>
            ${isGALoggedIn ? `<div style="text-align:center;"><button class="btn-action reject" onclick="deleteActivity(event, ${act.id})" style="padding:4px 8px; justify-content:center; display:inline-flex;" title="Hapus Log">🗑️</button></div>` : ''}
          </div>
        `;
      });
      
      feed.innerHTML = rowsHTML;
      globalActivities = data.activities;
    } catch (e) {
      console.error("Gagal memuat dashboard:", e);
    }
  }

  async function fetchVehicles() {
    try {
      const res = await fetch('api.php?action=vehicles', { cache: 'no-store' });
      globalVehicles = await res.json();
      renderVehicles();
    } catch (e) {
      console.error("Gagal memuat kendaraan:", e);
    }
  }

  async function fetchLoans() {
    try {
      const res = await fetch('api.php?action=loans', { cache: 'no-store' });
      globalLoans = await res.json();
      renderLoans();
    } catch (e) {
      console.error("Gagal memuat peminjaman:", e);
    }
  }

  async function fetchMaintenances() {
    try {
      const res = await fetch('api.php?action=maintenances', { cache: 'no-store' });
      globalMaintenances = await res.json();
      renderMaintenances();
    } catch (e) {
      console.error("Gagal memuat log maintenance:", e);
    }
  }

  async function fetchEmployees() {
    try {
      const res = await fetch('api.php?action=employees', { cache: 'no-store' });
      globalEmployees = await res.json();
      renderEmployees();
    } catch (e) {
      console.error("Gagal memuat karyawan:", e);
    }
  }

  async function fetchFuelFillings() {
    try {
      const res = await fetch('api.php?action=fuel_fillings', { cache: 'no-store' });
      globalFuelFillings = await res.json();
      renderReturns();
      renderFuelFillings();
    } catch (e) {
      console.error("Gagal memuat data pengisian BBM:", e);
    }
  }

  // Auto-Complete Searchable Employee Input (BARU & KUAT! ✅)
  function onEmployeeSearchInput() {
    try {
      const input = document.getElementById('loan-employee-search');
      if (!input) return;
      
      const val = input.value.trim().toLowerCase();
      const suggestions = document.getElementById('employee-suggestions');
      
      if (document.getElementById('loan-employee-id')) {
        document.getElementById('loan-employee-id').value = "";
      }
      
      if (!val) {
        if (suggestions) suggestions.style.display = 'none';
        return;
      }
      
      if (!Array.isArray(globalEmployees)) {
        globalEmployees = [];
      }
      
      const matches = globalEmployees.filter(emp => 
        (emp.name && emp.name.toLowerCase().includes(val)) || 
        (emp.nik && emp.nik.toLowerCase().includes(val)) ||
        (emp.division && emp.division.toLowerCase().includes(val))
      );
      
      if (matches.length === 0) {
        if (suggestions) {
          suggestions.innerHTML = '<div style="padding:12px; font-size:13px; text-align:center; color:var(--ink-soft);">Karyawan tidak ditemukan. Hubungi tim GA!</div>';
          suggestions.style.display = 'block';
        }
        return;
      }
      
      let html = '';
      matches.forEach(emp => {
        html += `
          <div class="autocomplete-item" onclick="selectEmployeeSuggestion(${emp.id}, '${emp.name}')" style="display:flex; align-items:center; gap:12px; background:var(--panel);">
            <div style="background: var(--blue-soft); border-radius: 50%; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; color: var(--blue); font-size: 16px; flex-shrink: 0;">
              👤
            </div>
            <div style="flex:1; text-align:left;">
              <div style="font-weight:600; color:var(--ink); font-size:14px; line-height:1.2;">${emp.name}</div>
              <div style="font-size:11.5px; color:var(--ink-soft); margin-top:4px; font-family:'Inter', sans-serif;">
                🏢 ${emp.division || 'Umum'} &bull; 🆔 NIK: <span class="mono" style="font-size:11px; font-weight:600; color:var(--blue);">${emp.nik}</span>
              </div>
            </div>
          </div>
        `;
      });
      
      if (suggestions) {
        suggestions.innerHTML = html;
        suggestions.style.display = 'block';
      }
    } catch (err) {
      console.error("Error in onEmployeeSearchInput:", err);
    }
  }

  function selectEmployeeSuggestion(empId, empName) {
    try {
      const input = document.getElementById('loan-employee-search');
      if (input) input.value = empName;
      
      const idEl = document.getElementById('loan-employee-id');
      if (idEl) idEl.value = empId;
      
      const suggestions = document.getElementById('employee-suggestions');
      if (suggestions) suggestions.style.display = 'none';
    } catch (err) {
      console.error("Error in selectEmployeeSuggestion:", err);
    }
  }

  // Client-Side Image Auto-Compression & Handling
  function handleCompressedPhotoUpload(e) {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    
    files.forEach(file => {
      if (!file.type.match('image.*')) {
        showToast("Error", "File harus berupa format gambar!", "error");
        return;
      }
      
      const reader = new FileReader();
      reader.onload = function(event) {
        const img = new Image();
        img.onload = function() {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const MAX_WIDTH = 1024;
          const MAX_HEIGHT = 1024;
          
          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          const compressedB64 = canvas.toDataURL('image/jpeg', 0.75);
          loanPhotosBase64.push(compressedB64);
          
          renderPhotoPreviews();
        };
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    });
    
    e.target.value = "";
  }

  function renderPhotoPreviews() {
    const grid = document.getElementById('photos-preview-grid');
    if (!grid) return;
    grid.innerHTML = '';
    
    loanPhotosBase64.forEach((b64, idx) => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      item.innerHTML = `
        <img src="${b64}" alt="Preview" onclick="viewLargeImage('${b64}')" style="cursor:zoom-in;">
        <button type="button" class="remove-btn" onclick="removePhoto(${idx})" title="Hapus">&times;</button>
      `;
      grid.appendChild(item);
    });
  }

  function removePhoto(idx) {
    loanPhotosBase64.splice(idx, 1);
    renderPhotoPreviews();
  }

  // ---- Edit Loan (KM Awal & Foto) — self-service, no admin needed ----
  function openEditLoanModal(loanId) {
    const loan = globalLoans.find(l => l.id === loanId);
    if (!loan) {
      showToast("Error", "Data peminjaman tidak ditemukan.", "error");
      return;
    }
    editLoanId = loanId;
    editLoanExistingPhotos = Array.isArray(loan.photos) ? [...loan.photos] : [];
    editLoanNewPhotosBase64 = [];

    document.getElementById('edit-loan-id').value = loanId;
    document.getElementById('edit-loan-initial-km').value = loan.initial_km || '';
    renderEditPhotoPreviews();

    openModal('edit-loan-modal');
  }

  function handleEditPhotoUpload(e) {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    files.forEach(file => {
      if (!file.type.match('image.*')) {
        showToast("Error", "File harus berupa format gambar!", "error");
        return;
      }

      const reader = new FileReader();
      reader.onload = function(event) {
        const img = new Image();
        img.onload = function() {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          const MAX_WIDTH = 1024;
          const MAX_HEIGHT = 1024;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);

          const compressedB64 = canvas.toDataURL('image/jpeg', 0.75);
          editLoanNewPhotosBase64.push(compressedB64);

          renderEditPhotoPreviews();
        };
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    });

    e.target.value = "";
  }

  function renderEditPhotoPreviews() {
    const grid = document.getElementById('edit-photos-preview-grid');
    if (!grid) return;
    grid.innerHTML = '';

    editLoanExistingPhotos.forEach((path, idx) => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      item.innerHTML = `
        <img src="${path}" alt="Preview" onclick="viewLargeImage('${path}')" style="cursor:zoom-in;">
        <button type="button" class="remove-btn" onclick="removeEditExistingPhoto(${idx})" title="Hapus">&times;</button>
      `;
      grid.appendChild(item);
    });

    editLoanNewPhotosBase64.forEach((b64, idx) => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      item.innerHTML = `
        <img src="${b64}" alt="Preview" onclick="viewLargeImage('${b64}')" style="cursor:zoom-in;">
        <button type="button" class="remove-btn" onclick="removeEditNewPhoto(${idx})" title="Hapus">&times;</button>
      `;
      grid.appendChild(item);
    });
  }

  function removeEditExistingPhoto(idx) {
    editLoanExistingPhotos.splice(idx, 1);
    renderEditPhotoPreviews();
  }

  function removeEditNewPhoto(idx) {
    editLoanNewPhotosBase64.splice(idx, 1);
    renderEditPhotoPreviews();
  }

  async function submitEditLoan(e) {
    e.preventDefault();
    const loanId = parseInt(document.getElementById('edit-loan-id').value, 10);
    const initialKmVal = document.getElementById('edit-loan-initial-km').value;

    const payload = {
      loan_id: loanId,
      initial_km: initialKmVal,
      photos: [...editLoanExistingPhotos, ...editLoanNewPhotosBase64]
    };

    try {
      const res = await fetch('api.php?action=edit_loan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (res.ok) {
        showToast("Tersimpan ✅", data.message || "KM awal & foto berhasil diperbarui.", "success");
        closeModal('edit-loan-modal');
        fetchLoans();
      } else {
        showToast("Error", data.error || "Gagal memperbarui data.", "error");
      }
    } catch (err) {
      showToast("Error", "Gagal menghubungi server.", "error");
    }
  }

  // Reset Steps (Fixed & Simplified!)
  function resetLoanSteps() {
    try {
      const step3 = document.getElementById('loan-step-3');
      const step1 = document.getElementById('loan-step-1');
      if (step3) step3.classList.remove('active');
      if (step1) step1.classList.add('active');
      
      const empSearch = document.getElementById('loan-employee-search');
      if (empSearch) empSearch.value = "";
      
      const empId = document.getElementById('loan-employee-id');
      if (empId) empId.value = "";
      
      // Reset Custom Driver Input if visible
      const customDriverInput = document.getElementById('loan-driver-name');
      if (customDriverInput) {
        customDriverInput.style.display = 'none';
        customDriverInput.required = false;
        customDriverInput.value = "";
      }
      
      // Reset Opsi Driver Select
      const driverSelect = document.getElementById('loan-driver');
      if (driverSelect) driverSelect.value = "Bawa Sendiri";
      
      // KM awal & foto kendaraan sekarang diisi melalui Modul Peminjaman setelah pengajuan.
    } catch (err) {
      console.error("Error in resetLoanSteps:", err);
    }
  }

  // Dynamic vehicles loading directly
  async function populateLoanVehicleDropdown() {
    const sel = document.getElementById('loan-vehicle');
    if (!sel) return;
    sel.innerHTML = '<option value="" disabled selected>⏳ Memuat kendaraan tersedia...</option>';
    
    try {
      const res = await fetch('api.php?action=vehicles', { cache: 'no-store' });
      const vehicles = await res.json();
      globalVehicles = vehicles;
      
      sel.innerHTML = '<option value="" disabled selected>-- Pilih unit tersedia --</option>';
      const readyVehicles = vehicles.filter(v => v.status === 'Ready');
      
      if (readyVehicles.length === 0) {
        sel.innerHTML = '<option value="" disabled>Semua armada sedang terpakai/diservis</option>';
        return;
      }
      
      readyVehicles.forEach(v => {
        const opt = document.createElement('option');
        opt.value = v.id;
        opt.innerText = `${v.brand} ${v.model} (${v.plate_number}) - [${v.type}]`;
        sel.appendChild(opt);
      });
    } catch (e) {
      console.error(e);
      sel.innerHTML = '<option value="" disabled>❌ Gagal memuat unit kendaraan. Hubungi IT!</option>';
    }
  }

  function populateMaintDropdown() {
    const sel = document.getElementById('maint-vehicle');
    if (!sel) return;
    sel.innerHTML = '<option value="" disabled selected>-- Pilih unit kendaraan --</option>';
    
    const eligibleVehicles = globalVehicles.filter(v => v.status !== 'Maintenance');
    
    eligibleVehicles.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.id;
      opt.innerText = `${v.brand} ${v.model} (${v.plate_number}) - [Status: ${v.status}]`;
      sel.appendChild(opt);
    });
  }

  // Format currency
  function formatIDR(num) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(num);
  }

  // Handle driver custom selection change
  function onDriverSelectChange() {
    const select = document.getElementById('loan-driver');
    const customInput = document.getElementById('loan-driver-name');
    
    if (select.value === 'Ketik Manual') {
      customInput.style.display = 'block';
      customInput.required = true;
      customInput.focus();
    } else {
      customInput.style.display = 'none';
      customInput.required = false;
      customInput.value = "";
    }
  }

  // Render Functions
  function renderVehicles() {
    const grid = document.getElementById('vehicles-grid-container');
    if (!grid) return;
    const searchVal = document.getElementById('vehicle-search').value.toLowerCase();
    grid.innerHTML = '';
    
    let filtered = globalVehicles;
    if (filterVehicleState !== 'ALL') {
      filtered = filtered.filter(v => v.status === filterVehicleState);
    }
    
    if (searchVal) {
      filtered = filtered.filter(v => 
        v.plate_number.toLowerCase().includes(searchVal) ||
        v.brand.toLowerCase().includes(searchVal) ||
        v.model.toLowerCase().includes(searchVal) ||
        v.type.toLowerCase().includes(searchVal)
      );
    }
    
    if (filtered.length === 0) {
      grid.innerHTML = '<div style="grid-column: 1/-1; padding: 40px; text-align: center; color: var(--ink-soft); font-weight: 500;">Tidak ada kendaraan yang cocok dengan filter atau pencarian.</div>';
      return;
    }
    
    filtered.forEach(v => {
      let statusClass = 'tag-ready';
      let statusLabel = 'Tersedia';
      if (v.status === 'Loaned') {
        statusClass = 'tag-loan';
        statusLabel = 'Sedang Dipinjam';
      } else if (v.status === 'Maintenance') {
        statusClass = 'tag-maint';
        statusLabel = 'Di Bengkel';
      }
      
      const card = document.createElement('div');
      card.className = 'vehicle-card';
      
      const controlsStyle = isGALoggedIn ? 'display:flex;' : 'display:none;';
      
      card.innerHTML = `
        <div class="vehicle-header">
          <span class="mini-plate">${v.plate_number}</span>
          <span class="vehicle-type">${v.type}</span>
        </div>
        <div class="vehicle-body">
          <h4 class="vehicle-name-full">${v.brand} ${v.model}</h4>
          <p class="vehicle-notes">${v.notes || '<em>Tidak ada catatan kondisi khusus.</em>'}</p>
        </div>
        <div class="vehicle-footer">
          <span class="gauge-tag ${statusClass}">${statusLabel}</span>
          <span style="font-size: 11px; font-weight:600; color:var(--ink-soft);">ID Unit: #${v.id}</span>
        </div>
        <div class="admin-controls" style="${controlsStyle}">
          <button class="btn-action edit-btn" style="flex:1; justify-content:center;" onclick="editVehicleForm(${v.id})">✏️ Edit</button>
          <button class="btn-action reject" style="flex:1; justify-content:center;" onclick="deleteVehicle(${v.id})">🗑️ Hapus</button>
        </div>
      `;
      grid.appendChild(card);
    });
  }

  // Render Loans with Advanced Multi-Filter
  function renderLoans() {
    const body = document.getElementById('loans-table-body');
    if (!body) return;
    const searchVal = document.getElementById('loan-search').value.toLowerCase();
    const startDateVal = document.getElementById('loan-filter-start').value;
    const endDateVal = document.getElementById('loan-filter-end').value;
    
    body.innerHTML = '';
    
    let filtered = globalLoans;
    
    // 1. Status Filter
    if (filterLoanState !== 'ALL') {
      filtered = filtered.filter(l => l.status === filterLoanState);
    }
    
    // 2. Search Text Query Filter
    if (searchVal) {
      filtered = filtered.filter(l => 
        l.pic_name.toLowerCase().includes(searchVal) ||
        l.plate_number.toLowerCase().includes(searchVal) ||
        l.vehicle_name.toLowerCase().includes(searchVal) ||
        l.purpose.toLowerCase().includes(searchVal) ||
        (l.pic_div && l.pic_div.toLowerCase().includes(searchVal))
      );
    }
    
    // 3. Date Range Filter (Y-M-D)
    if (startDateVal) {
      filtered = filtered.filter(l => l.start_time.substring(0, 10) >= startDateVal);
    }
    if (endDateVal) {
      filtered = filtered.filter(l => l.start_time.substring(0, 10) <= endDateVal);
    }
    
    globalFilteredLoansForExport = filtered;
    
    const actionsHeader = document.querySelector('.col-actions-header');
    if (actionsHeader) {
      actionsHeader.style.display = isGALoggedIn ? 'table-cell' : 'none';
    }
    
    if (filtered.length === 0) {
      body.innerHTML = `<tr><td colspan="${isGALoggedIn ? 10 : 9}" style="text-align: center; padding: 30px; color: var(--ink-soft);">Tidak ada peminjaman ditemukan sesuai filter.</td></tr>`;
      return;
    }
    
    filtered.forEach(l => {
      let statClass = 'pill-tertunda';
      let statLabel = 'Menunggu';
      let actionButtons = '';
      
      if (l.status === 'Pending') {
        statClass = 'pill-tertunda';
        statLabel = 'Menunggu';
        if (isGALoggedIn) {
          actionButtons = `
            <button class="btn-action approve" onclick="handleLoanAction(${l.id}, 'approve')">Setuju</button>
            <button class="btn-action reject" onclick="handleLoanAction(${l.id}, 'reject')">Tolak</button>
          `;
        } else {
          actionButtons = '<span style="font-size: 11px; color:var(--ink-soft); font-weight:600;">Menunggu Admin</span>';
        }
      } else if (l.status === 'Approved') {
        statClass = 'pill-berjalan';
        statLabel = 'Berjalan';
        if (isGALoggedIn) {
          actionButtons = `
            <button class="btn-action complete" onclick="openReturnModal(${l.id})">Kembalikan</button>
          `;
        } else {
          actionButtons = '<span style="font-size: 11px; color:var(--blue); font-weight:600;">Aktif</span>';
        }
      } else if (l.status === 'Completed') {
        statClass = 'pill-selesai';
        statLabel = 'Selesai';
        actionButtons = '<span style="font-size: 11px; color:var(--green); font-weight:600;">Selesai &amp; Kembali</span>';
      } else if (l.status === 'Rejected') {
        statClass = 'pill-ditolak';
        statLabel = 'Ditolak';
        actionButtons = '<span style="font-size: 11px; color:var(--red); font-weight:600;">Ditolak</span>';
      }
      
      if (isGALoggedIn) {
        actionButtons += `<button class="btn-action reject" onclick="deleteLoan(${l.id})" style="margin-left:4px;" title="Hapus Catatan">🗑️ Hapus</button>`;
      }
      
      const formattedStart = l.start_time.substring(0, 16);
      const formattedEnd = l.end_time.substring(0, 16);
      
      const initialKm = (l.initial_km !== null && l.initial_km !== undefined && l.initial_km !== '') ? Number(l.initial_km) : null;

      let photosHtml = '';
      if (l.photos && l.photos.length > 0) {
        photosHtml = '<div style="display:flex; gap:6px; margin-top:8px; flex-wrap:wrap;">';
        l.photos.forEach(path => {
          photosHtml += `<img src="${path}" onclick="viewLargeImage('${path}')" style="width:36px; height:36px; object-fit:cover; border-radius:6px; cursor:zoom-in; border:1px solid var(--line); transition: transform 0.15s ease;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" />`;
        });
        photosHtml += '</div>';
      }

      // Pengembalian (return) cell: KM akhir, jarak tempuh, waktu kembali, catatan, foto
      let returnCellHtml = '<span style="font-size:11px; color:var(--ink-soft);">—</span>';
      if (l.final_km !== null && l.final_km !== undefined) {
        const distance = initialKm !== null ? (Number(l.final_km) - initialKm) : null;
        let returnPhotosHtml = '';
        if (l.return_photos && l.return_photos.length > 0) {
          returnPhotosHtml = '<div style="display:flex; gap:6px; margin-top:6px; flex-wrap:wrap;">';
          l.return_photos.forEach(path => {
            returnPhotosHtml += `<img src="${path}" onclick="viewLargeImage('${path}')" style="width:32px; height:32px; object-fit:cover; border-radius:6px; cursor:zoom-in; border:1px solid var(--line);" />`;
          });
          returnPhotosHtml += '</div>';
        }
        returnCellHtml = `
          <div style="font-weight:600; font-size:12px;">📈 ${Number(l.final_km).toLocaleString('id-ID')} KM ${distance !== null && distance >= 0 ? `(+${distance.toLocaleString('id-ID')} KM)` : ''}</div>
          ${l.returned_at ? `<div style="font-size:11px; color:var(--ink-soft); margin-top:2px;">🕒 ${l.returned_at.substring(0,16)}</div>` : ''}
          ${l.return_notes ? `<div style="font-size:11px; color:var(--ink-soft); margin-top:2px; max-width:180px;">📝 ${l.return_notes}</div>` : ''}
          ${returnPhotosHtml}
        `;
      }

      // Info BBM cell: total liter, jenis, total harga, lokasi
      let fuelCellHtml = '<span style="font-size:11px; color:var(--ink-soft);">—</span>';
      if (l.fuel_total_liter && l.fuel_total_liter > 0) {
        fuelCellHtml = `
          <div style="font-weight:600; font-size:12px;">⛽ ${l.fuel_total_liter.toLocaleString('id-ID')} L</div>
          ${l.fuel_types ? `<div style="font-size:11px; color:var(--ink-soft); margin-top:2px;">${l.fuel_types}</div>` : ''}
          <div style="font-size:11px; color:var(--ink-soft); margin-top:2px;">Rp ${l.fuel_total_price.toLocaleString('id-ID')}</div>
          ${l.fuel_locations ? `<div style="font-size:11px; color:var(--ink-soft); margin-top:2px; max-width:150px;">📍 ${l.fuel_locations}</div>` : ''}
        `;
      }

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><span class="mini-plate">${l.plate_number}</span></td>
        <td>
          <strong>${l.vehicle_name}</strong>
          <div style="font-size:11px; color:var(--ink-soft); margin-top:2px;">
            🚦 ${l.driver_status} | 📈 KM Awal: ${initialKm !== null ? initialKm.toLocaleString('id-ID') + ' KM' : '<span style="color:var(--amber); font-weight:700;">Belum diisi</span>'}
          </div>
          ${photosHtml}
          ${(l.status === 'Pending' || l.status === 'Approved') ? `<button type="button" onclick="openEditLoanModal(${l.id})" style="margin-top:8px; font-size:11px; font-weight:600; color:var(--blue); background:var(--blue-soft); border:none; border-radius:6px; padding:4px 8px; cursor:pointer; display:inline-flex; align-items:center; gap:4px;" title="Peminjam bisa mengedit KM awal & foto sendiri, tanpa perlu admin">✏️ Tulis KM &amp; Foto</button>` : ''}
        </td>
        <td>
          <div style="font-weight:600;">${l.pic_name}</div>
          <div style="font-size:11px; color:var(--ink-soft); margin-top:2px;">
            🏢 Divisi: ${l.pic_div || 'Umum'}<br>🆔 NIK: ${l.pic_nik}
          </div>
        </td>
        <td>${l.purpose}</td>
        <td class="row-time">${formattedStart}</td>
        <td class="row-time">${formattedEnd}</td>
        <td>${returnCellHtml}</td>
        <td>${fuelCellHtml}</td>
        <td><span class="status-pill ${statClass}">${statLabel}</span></td>
        ${isGALoggedIn ? `<td><div class="action-buttons">${actionButtons}</div></td>` : ''}
      `;
      body.appendChild(tr);
    });
  }

  function renderMaintenances() {
    const body = document.getElementById('maint-table-body');
    if (!body) return;
    const searchVal = document.getElementById('maint-search').value.toLowerCase();
    body.innerHTML = '';
    
    let filtered = globalMaintenances;
    if (filterMaintState !== 'ALL') {
      filtered = filtered.filter(m => m.status === filterMaintState);
    }
    
    if (searchVal) {
      filtered = filtered.filter(m => 
        m.vehicle_name.toLowerCase().includes(searchVal) ||
        m.plate_number.toLowerCase().includes(searchVal) ||
        m.workshop.toLowerCase().includes(searchVal) ||
        m.description.toLowerCase().includes(searchVal)
      );
    }
    
    const actionsMaintHeader = document.querySelector('.col-actions-maint-header');
    if (actionsMaintHeader) {
      actionsMaintHeader.style.display = isGALoggedIn ? 'table-cell' : 'none';
    }
    
    if (filtered.length === 0) {
      body.innerHTML = `<tr><td colspan="${isGALoggedIn ? 9 : 8}" style="text-align: center; padding: 30px; color: var(--ink-soft);">Tidak ada log perawatan ditemukan.</td></tr>`;
      return;
    }
    
    filtered.forEach(m => {
      let statClass = 'pill-servis';
      let statLabel = 'Servis';
      let actionBtn = '';
      
      if (m.status === 'Ongoing') {
        statClass = 'pill-servis';
        statLabel = 'Servis';
        if (isGALoggedIn) {
          actionBtn = `<button class="btn-action complete" onclick="handleMaintAction(${m.id}, 'complete')">Selesai Servis</button>`;
        } else {
          actionBtn = '<span style="font-size: 11px; color:var(--amber); font-weight:600;">Bengkel</span>';
        }
      } else {
        statClass = 'pill-selesai';
        statLabel = 'Selesai';
        actionBtn = '<span style="font-size: 11px; color:var(--green); font-weight:600;">Selesai Perawatan</span>';
      }
      
      if (isGALoggedIn) {
        actionBtn += `<button class="btn-action reject" onclick="deleteMaintenance(${m.id})" style="margin-left:4px;" title="Hapus Catatan">🗑️ Hapus</button>`;
      }
      
      const formattedCost = formatIDR(m.cost);
      
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><span class="mini-plate">${m.plate_number}</span></td>
        <td><strong>${m.vehicle_name}</strong></td>
        <td>${m.workshop}</td>
        <td>${m.description}</td>
        <td class="mono" style="font-weight:600; color:var(--amber);">${formattedCost}</td>
        <td class="row-time">${m.start_time}</td>
        <td class="row-time">${m.end_time}</td>
        <td><span class="status-pill ${statClass}">${statLabel}</span></td>
        ${isGALoggedIn ? `<td><div class="action-buttons">${actionBtn}</div></td>` : ''}
      `;
      body.appendChild(tr);
    });
  }

  // Tracks which employee IDs are checked for bulk actions; survives re-renders (search/refresh)
  let selectedEmployeeIds = new Set();

  function renderEmployees() {
    const body = document.getElementById('employees-table-body');
    if (!body) return;
    const searchVal = document.getElementById('employee-search').value.toLowerCase();
    body.innerHTML = '';
    
    let filtered = globalEmployees;
    if (!Array.isArray(filtered)) {
      filtered = [];
    }
    
    if (searchVal) {
      filtered = filtered.filter(e => 
        (e.name && e.name.toLowerCase().includes(searchVal)) ||
        (e.nik && e.nik.toLowerCase().includes(searchVal)) ||
        (e.division && e.division.toLowerCase().includes(searchVal)) ||
        (e.email && e.email.toLowerCase().includes(searchVal))
      );
    }

    // Drop selections for employees no longer present (e.g. deleted elsewhere)
    const currentIds = new Set(globalEmployees.map(e => String(e.id)));
    selectedEmployeeIds.forEach(id => { if (!currentIds.has(id)) selectedEmployeeIds.delete(id); });
    
    if (filtered.length === 0) {
      body.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 30px; color: var(--ink-soft);">Tidak ada karyawan ditemukan.</td></tr>';
      updateEmployeeBulkBar();
      return;
    }
    
    filtered.forEach(e => {
      const tr = document.createElement('tr');
      const checked = selectedEmployeeIds.has(String(e.id)) ? 'checked' : '';
      tr.innerHTML = `
        <td><input type="checkbox" class="employee-row-checkbox" data-id="${e.id}" ${checked} onchange="toggleSelectEmployee(${e.id}, this)"></td>
        <td><code class="mono" style="font-weight:600;">#EMP-${e.id}</code></td>
        <td><strong>${e.name}</strong></td>
        <td class="mono" style="font-weight:600; color:var(--ink-soft);">${e.nik}</td>
        <td><span style="background:var(--blue-soft); color:var(--blue); font-size:12px; padding:4px 10px; border-radius:6px; font-weight:600;">${e.division || 'Umum'}</span></td>
        <td><a href="mailto:${e.email}" style="color:var(--blue); text-decoration:underline;">${e.email}</a></td>
        <td>
          <div class="action-buttons">
            <button class="btn-action edit-btn" onclick="editEmployeeForm(${e.id})">✏️ Edit</button>
            <button class="btn-action reject" onclick="deleteEmployee(${e.id})">🗑️ Hapus</button>
          </div>
        </td>
      `;
      body.appendChild(tr);
    });

    updateEmployeeBulkBar();
  }

  // ==================== EMPLOYEE BULK SELECTION ====================

  function toggleSelectEmployee(id, checkbox) {
    if (checkbox.checked) {
      selectedEmployeeIds.add(String(id));
    } else {
      selectedEmployeeIds.delete(String(id));
      const selectAll = document.getElementById('employee-select-all');
      if (selectAll) selectAll.checked = false;
    }
    updateEmployeeBulkBar();
  }

  function toggleSelectAllEmployees(checkbox) {
    document.querySelectorAll('#employees-table-body .employee-row-checkbox').forEach(cb => {
      cb.checked = checkbox.checked;
      if (checkbox.checked) {
        selectedEmployeeIds.add(cb.dataset.id);
      } else {
        selectedEmployeeIds.delete(cb.dataset.id);
      }
    });
    updateEmployeeBulkBar();
  }

  function clearEmployeeSelection() {
    selectedEmployeeIds.clear();
    const selectAll = document.getElementById('employee-select-all');
    if (selectAll) selectAll.checked = false;
    renderEmployees();
  }

  function updateEmployeeBulkBar() {
    const bar = document.getElementById('employee-bulk-bar');
    const countLabel = document.getElementById('employee-bulk-count');
    if (!bar || !countLabel) return;
    const count = selectedEmployeeIds.size;
    if (count > 0) {
      bar.style.display = 'flex';
      countLabel.innerText = `${count} karyawan dipilih`;
    } else {
      bar.style.display = 'none';
    }
  }

  async function bulkDeleteEmployees() {
    const ids = Array.from(selectedEmployeeIds).map(id => parseInt(id, 10));
    if (ids.length === 0) return;

    if (!confirm(`Apakah Anda yakin ingin menghapus ${ids.length} karyawan terpilih? Riwayat peminjaman yang terkait dengan karyawan ini juga akan ikut terhapus. Tindakan ini tidak dapat dibatalkan.`)) return;

    try {
      const res = await fetch('api.php?action=bulk_delete_employees', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
      });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        selectedEmployeeIds.clear();
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server", "error");
    }
  }

  // ==================== RESEQUENCE / URUTKAN ULANG ID KARYAWAN ====================

  async function resequenceEmployees() {
    if (!confirm("Urutkan ulang ID Karyawan?\n\nSemua ID akan dirapikan ulang menjadi #EMP-1, #EMP-2, dst secara berurutan tanpa nomor yang terlompat, mengikuti urutan data saat ini. Riwayat peminjaman akan otomatis disesuaikan mengikuti ID baru. Tindakan ini tidak dapat dibatalkan.")) return;

    try {
      const res = await fetch('api.php?action=resequence_employees', { method: 'POST' });
      const data = await res.json();
      selectedEmployeeIds.clear();
      // Always refresh, even on error: some DB engines partially commit DDL statements
      // before an error surfaces, so the UI must reflect the real current state either way.
      await refreshData();
      if (res.ok) {
        showToast("Sukses", data.message, "success");
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server", "error");
    }
  }

  // ==================== IMPORT KARYAWAN VIA EXCEL ====================

  async function submitImportEmployees(e) {
    e.preventDefault();
    const fileInput = document.getElementById('import-employee-file');
    const file = fileInput.files[0];
    if (!file) {
      showToast("Gagal", "Silakan pilih file Excel (.xlsx) terlebih dahulu.", "error");
      return;
    }

    const btn = document.getElementById('btn-import-employee-submit');
    const originalText = btn.innerText;
    btn.disabled = true;
    btn.innerText = "Mengimpor...";

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('api.php?action=import_employees', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();

      if (res.ok) {
        showToast("Sukses", data.message, "success", 8000);
        if (Array.isArray(data.skipped) && data.skipped.length > 0) {
          showImportSkippedDetails(data.skipped);
        }
        closeModal('import-employee-modal');
        document.getElementById('form-import-employee').reset();
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (err) {
      showToast("Error", "Gagal menghubungi server", "error");
    } finally {
      btn.disabled = false;
      btn.innerText = originalText;
    }
  }

  function showImportSkippedDetails(skippedList) {
    const box = document.getElementById('import-skipped-details');
    if (!box) return;
    box.style.display = 'block';
    box.innerHTML = '<strong>Baris yang dilewati:</strong><ul style="margin:6px 0 0 18px; padding:0;">' +
      skippedList.map(s => `<li style="font-size:13px; color:var(--ink-soft); margin-bottom:2px;">${s}</li>`).join('') +
      '</ul>';
  }

  // Filters Controls
  function filterLoanStatus(status, btn) {
    filterLoanState = status;
    btn.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderLoans();
  }
  function filterLoans() {
    renderLoans();
  }

  function clearDateFilters() {
    document.getElementById('loan-filter-start').value = "";
    document.getElementById('loan-filter-end').value = "";
    filterLoans();
  }

  function filterMaintStatus(status, btn) {
    filterMaintState = status;
    btn.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderMaintenances();
  }
  function filterMaintenances() {
    renderMaintenances();
  }

  function filterVehicleStatus(status, btn) {
    filterVehicleState = status;
    btn.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderVehicles();
  }
  function filterVehicles() {
    renderVehicles();
  }

  function filterEmployees() {
    renderEmployees();
  }

  // Loans Approve / Reject Actions Handlers
  async function handleLoanAction(loanId, action) {
    try {
      const res = await fetch(`api.php?action=${action}_loan&id=${loanId}`, { method: 'POST' });
      const data = await res.json();
      
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal melakukan aksi peminjaman", "error");
    }
  }

  async function handleMaintAction(maintId, action) {
    try {
      const res = await fetch(`api.php?action=complete_maintenance&id=${maintId}`, { method: 'POST' });
      const data = await res.json();
      
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menyelesaikan perawatan", "error");
    }
  }

  // Delete Loan Record
  async function deleteLoan(loanId) {
    if (!confirm("Apakah Anda yakin ingin menghapus catatan peminjaman ini? Jika peminjaman aktif, status kendaraan akan otomatis dikembalikan menjadi Ready.")) return;
    try {
      const res = await fetch(`api.php?action=delete_loan&id=${loanId}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses Hapus 🗑️", data.message, "success");
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server untuk menghapus peminjaman", "error");
    }
  }

  // ==================== PENGEMBALIAN & PENGISIAN BBM ====================

  function renderReturns() {
    const body = document.getElementById('returns-table-body');
    if (!body) return;
    const searchInput = document.getElementById('return-search');
    const searchVal = searchInput ? searchInput.value.toLowerCase() : '';

    let filtered = globalLoans.filter(l => l.status === 'Approved');

    if (searchVal) {
      filtered = filtered.filter(l =>
        l.pic_name.toLowerCase().includes(searchVal) ||
        l.plate_number.toLowerCase().includes(searchVal) ||
        l.vehicle_name.toLowerCase().includes(searchVal)
      );
    }

    body.innerHTML = '';

    if (filtered.length === 0) {
      body.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 30px; color: var(--ink-soft);">Tidak ada kendaraan yang sedang dipinjam dan menunggu pengembalian.</td></tr>`;
      return;
    }

    filtered.forEach(l => {
      const formattedStart = l.start_time.substring(0, 16);
      const formattedEnd = l.end_time.substring(0, 16);

      const actionCell = `<button class="btn-action complete" onclick="openReturnModal(${l.id})">↩️ Proses Pengembalian</button>`;

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><span class="mini-plate">${l.plate_number}</span></td>
        <td>
          <strong>${l.vehicle_name}</strong>
          <div style="font-size:11px; color:var(--ink-soft); margin-top:2px;">
            🚦 ${l.driver_status} | 📈 ${l.initial_km !== null && l.initial_km !== undefined ? Number(l.initial_km).toLocaleString('id-ID') + ' KM Awal' : '<span style="color:var(--amber); font-weight:700;">KM Awal belum diisi</span>'}
          </div>
        </td>
        <td>
          <div style="font-weight:600;">${l.pic_name}</div>
          <div style="font-size:11px; color:var(--ink-soft); margin-top:2px;">🏢 Divisi: ${l.pic_div || 'Umum'}</div>
        </td>
        <td>${l.purpose}</td>
        <td class="row-time">${formattedStart}</td>
        <td class="row-time">${formattedEnd}</td>
        <td><div class="action-buttons">${actionCell}</div></td>
      `;
      body.appendChild(tr);
    });
  }

  function renderFuelFillings() {
    const body = document.getElementById('fuel-table-body');
    if (!body) return;
    const searchInput = document.getElementById('fuel-search');
    const searchVal = searchInput ? searchInput.value.toLowerCase() : '';

    const actHeader = document.querySelector('.col-actions-fuel-header');
    if (actHeader) actHeader.style.display = isGALoggedIn ? 'table-cell' : 'none';

    let filtered = globalFuelFillings;
    if (searchVal) {
      filtered = filtered.filter(f =>
        f.pic_name.toLowerCase().includes(searchVal) ||
        f.plate_number.toLowerCase().includes(searchVal) ||
        (f.location_or_receipt && f.location_or_receipt.toLowerCase().includes(searchVal))
      );
    }

    body.innerHTML = '';

    if (filtered.length === 0) {
      body.innerHTML = `<tr><td colspan="${isGALoggedIn ? 11 : 10}" style="text-align: center; padding: 30px; color: var(--ink-soft);">Belum ada catatan pengisian BBM.</td></tr>`;
      return;
    }

    filtered.forEach(f => {
      const parafHtml = f.approver_name
        ? `<span style="color:var(--green); font-weight:600;">✅ ${f.approver_name}</span>`
        : `<span style="color:var(--ink-soft);">⏳ Belum diparaf</span>`;

      const notaHtml = f.receipt_photo
        ? `<div>${f.location_or_receipt || '-'}</div><img src="${f.receipt_photo}" onclick="viewLargeImage('${f.receipt_photo}')" style="width:32px; height:32px; object-fit:cover; border-radius:6px; cursor:zoom-in; border:1px solid var(--line); margin-top:4px;" />`
        : (f.location_or_receipt || '-');

      const actionCell = isGALoggedIn
        ? `<button class="btn-action reject" onclick="deleteFuelFilling(${f.id})" title="Hapus Catatan">🗑️</button>`
        : '';

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="row-time">${f.created_at}</td>
        <td><span class="mini-plate">${f.plate_number}</span></td>
        <td>${f.vehicle_name}</td>
        <td>${f.pic_name}</td>
        <td>${f.fuel_type}</td>
        <td>${f.liter_amount.toLocaleString('id-ID')} L</td>
        <td>${formatIDR(f.price_per_liter)}</td>
        <td><strong>${formatIDR(f.total_price)}</strong></td>
        <td>${notaHtml}</td>
        <td>${parafHtml}</td>
        ${isGALoggedIn ? `<td><div class="action-buttons">${actionCell}</div></td>` : ''}
      `;
      body.appendChild(tr);
    });
  }

  function openReturnModal(loanId) {
    const loan = globalLoans.find(l => l.id === loanId);
    if (!loan) {
      showToast("Error", "Data peminjaman tidak ditemukan.", "error");
      return;
    }

    if (loan.initial_km === null || loan.initial_km === undefined || loan.initial_km === '') {
      showToast("KM Awal Belum Diisi ⚠️", "Silakan isi KM awal dan foto kondisi kendaraan terlebih dahulu melalui tombol Edit KM & Foto pada Modul Peminjaman.", "warning");
      openEditLoanModal(loanId);
      return;
    }

    document.getElementById('return-loan-id').value = loanId;
    document.getElementById('return-loan-summary').innerHTML = `
      <div><strong>${loan.vehicle_name}</strong> (<span class="mini-plate">${loan.plate_number}</span>)</div>
      <div>👤 Peminjam: <strong>${loan.pic_name}</strong> — 🏢 ${loan.pic_div || 'Umum'}</div>
      <div>🎯 Keperluan: ${loan.purpose}</div>
      <div>📈 KM Awal: ${loan.initial_km !== null && loan.initial_km !== undefined ? Number(loan.initial_km).toLocaleString('id-ID') + ' KM' : '<strong style="color:var(--amber);">Belum diisi</strong>'}</div>
    `;

    document.getElementById('return-final-km').value = '';
    document.getElementById('return-final-km').min = Number(loan.initial_km) || 0;
    document.getElementById('return-notes').value = '';
    returnPhotosBase64 = [];
    renderReturnPhotoPreviews();

    document.getElementById('return-include-fuel').checked = false;
    document.getElementById('fuel-fields-container').style.display = 'none';
    document.getElementById('fuel-liter').value = '';
    document.getElementById('fuel-price').value = '';
    document.getElementById('fuel-type').value = '';
    document.getElementById('fuel-total-display').value = 'Rp 0';
    document.getElementById('fuel-location').value = '';
    document.getElementById('fuel-approver-name').value = '';
    fuelReceiptPhotoBase64 = null;
    document.getElementById('fuel-receipt-preview-grid').innerHTML = '';

    document.getElementById('return-modal').classList.add('active');
  }

  function toggleFuelSection() {
    const checked = document.getElementById('return-include-fuel').checked;
    document.getElementById('fuel-fields-container').style.display = checked ? 'block' : 'none';
  }

  function computeFuelTotal() {
    const liter = parseFloat(document.getElementById('fuel-liter').value) || 0;
    const price = parseFloat(document.getElementById('fuel-price').value) || 0;
    const total = liter * price;
    document.getElementById('fuel-total-display').value = formatIDR(total);
  }

  // Reuse the same compression logic as loan photos, targeted at return photos
  function handleReturnPhotoUpload(e) {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    files.forEach(file => {
      if (!file.type.match('image.*')) {
        showToast("Error", "File harus berupa format gambar!", "error");
        return;
      }
      const reader = new FileReader();
      reader.onload = function(event) {
        const img = new Image();
        img.onload = function() {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_WIDTH = 1024;
          const MAX_HEIGHT = 1024;
          if (width > height) {
            if (width > MAX_WIDTH) { height *= MAX_WIDTH / width; width = MAX_WIDTH; }
          } else {
            if (height > MAX_HEIGHT) { width *= MAX_HEIGHT / height; height = MAX_HEIGHT; }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          const compressedB64 = canvas.toDataURL('image/jpeg', 0.75);
          returnPhotosBase64.push(compressedB64);
          renderReturnPhotoPreviews();
        };
        img.src = event.target.result;
      };
      reader.readAsDataURL(file);
    });
    e.target.value = "";
  }

  function renderReturnPhotoPreviews() {
    const grid = document.getElementById('return-photos-preview-grid');
    if (!grid) return;
    grid.innerHTML = '';
    returnPhotosBase64.forEach((b64, idx) => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      item.innerHTML = `
        <img src="${b64}" alt="Preview" onclick="viewLargeImage('${b64}')" style="cursor:zoom-in;">
        <button type="button" class="remove-btn" onclick="removeReturnPhoto(${idx})" title="Hapus">&times;</button>
      `;
      grid.appendChild(item);
    });
  }

  function removeReturnPhoto(idx) {
    returnPhotosBase64.splice(idx, 1);
    renderReturnPhotoPreviews();
  }

  function handleFuelReceiptUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.match('image.*')) {
      showToast("Error", "File harus berupa format gambar!", "error");
      return;
    }
    const reader = new FileReader();
    reader.onload = function(event) {
      const img = new Image();
      img.onload = function() {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const MAX_WIDTH = 1024;
        const MAX_HEIGHT = 1024;
        if (width > height) {
          if (width > MAX_WIDTH) { height *= MAX_WIDTH / width; width = MAX_WIDTH; }
        } else {
          if (height > MAX_HEIGHT) { width *= MAX_HEIGHT / height; height = MAX_HEIGHT; }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        fuelReceiptPhotoBase64 = canvas.toDataURL('image/jpeg', 0.75);
        renderFuelReceiptPreview();
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  }

  function renderFuelReceiptPreview() {
    const grid = document.getElementById('fuel-receipt-preview-grid');
    if (!grid) return;
    grid.innerHTML = '';
    if (!fuelReceiptPhotoBase64) return;
    const item = document.createElement('div');
    item.className = 'preview-item';
    item.innerHTML = `
      <img src="${fuelReceiptPhotoBase64}" alt="Preview Nota" onclick="viewLargeImage('${fuelReceiptPhotoBase64}')" style="cursor:zoom-in;">
      <button type="button" class="remove-btn" onclick="removeFuelReceipt()" title="Hapus">&times;</button>
    `;
    grid.appendChild(item);
  }

  function removeFuelReceipt() {
    fuelReceiptPhotoBase64 = null;
    renderFuelReceiptPreview();
  }

  async function submitReturn(e) {
    e.preventDefault();
    const loanId = document.getElementById('return-loan-id').value;
    const includeFuel = document.getElementById('return-include-fuel').checked;

    if (includeFuel) {
      const liter = parseFloat(document.getElementById('fuel-liter').value) || 0;
      const price = parseFloat(document.getElementById('fuel-price').value) || 0;
      const type = document.getElementById('fuel-type').value;
      if (liter <= 0 || price <= 0 || !type) {
        showToast("Error", "Lengkapi jumlah liter, harga per liter, dan jenis BBM terlebih dahulu.", "error");
        return;
      }
    }

    const payload = {
      loan_id: loanId,
      final_km: document.getElementById('return-final-km').value,
      return_notes: document.getElementById('return-notes').value,
      return_photos: returnPhotosBase64,
      include_fuel: includeFuel,
      fuel_liter: document.getElementById('fuel-liter').value,
      fuel_price: document.getElementById('fuel-price').value,
      fuel_type: document.getElementById('fuel-type').value,
      fuel_location: document.getElementById('fuel-location').value,
      fuel_receipt_photo: fuelReceiptPhotoBase64,
      fuel_approver_name: document.getElementById('fuel-approver-name').value
    };

    try {
      const res = await fetch('api.php?action=process_return', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        closeModal('return-modal');
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (err) {
      showToast("Error", "Gagal menghubungi server untuk memproses pengembalian.", "error");
    }
  }

  async function deleteFuelFilling(fuelId) {
    if (!confirm("Apakah Anda yakin ingin menghapus catatan pengisian BBM ini?")) return;
    try {
      const res = await fetch(`api.php?action=delete_fuel_filling&id=${fuelId}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses Hapus 🗑️", data.message, "success");
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server untuk menghapus data BBM", "error");
    }
  }

  // Delete Maintenance Record
  async function deleteMaintenance(maintId) {
    if (!confirm("Apakah Anda yakin ingin menghapus catatan perawatan ini? Jika perawatan sedang berjalan, status kendaraan akan otomatis dikembalikan menjadi Ready.")) return;
    try {
      const res = await fetch(`api.php?action=delete_maintenance&id=${maintId}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses Hapus 🗑️", data.message, "success");
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server untuk menghapus perawatan", "error");
    }
  }

  // Delete Recent Activity Log
  async function deleteActivity(event, actId) {
    event.stopPropagation();
    if (!confirm("Apakah Anda yakin ingin menghapus baris log aktivitas terbaru ini dari dasbor?")) return;
    try {
      const res = await fetch(`api.php?action=delete_activity&id=${actId}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses Hapus 🗑️", data.message, "success");
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server untuk menghapus log aktivitas", "error");
    }
  }

  // Employee Edit & Delete Admin Controls
  function editEmployeeForm(empId) {
    const emp = globalEmployees.find(e => e.id == empId);
    if (!emp) return;
    
    document.getElementById('emp-edit-id').value = emp.id;
    document.getElementById('emp-name').value = emp.name;
    document.getElementById('emp-nik').value = emp.nik;
    document.getElementById('emp-email').value = emp.email;
    document.getElementById('emp-div').value = emp.division || "Umum";
    
    document.getElementById('employee-modal-title').innerText = "Form Edit Karyawan";
    document.getElementById('btn-employee-submit').innerText = "Simpan Perubahan";
    
    openModal('employee-modal', true);
  }

  async function deleteEmployee(empId) {
    if (!confirm("Apakah Anda yakin ingin menghapus data karyawan ini?")) return;
    
    try {
      const res = await fetch(`api.php?action=delete_employee&id=${empId}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server", "error");
    }
  }

  // Vehicle Edit & Delete Admin Controls
  function editVehicleForm(vehId) {
    const v = globalVehicles.find(item => item.id == vehId);
    if (!v) return;
    
    document.getElementById('veh-edit-id').value = v.id;
    document.getElementById('veh-plate').value = v.plate_number;
    document.getElementById('veh-brand').value = v.brand;
    document.getElementById('veh-model').value = v.model;
    document.getElementById('veh-type').value = v.type;
    document.getElementById('veh-notes').value = v.notes || "";
    
    document.getElementById('vehicle-modal-title').innerText = "Form Edit Armada";
    document.getElementById('btn-vehicle-submit').innerText = "Simpan Perubahan";
    
    openModal('vehicle-modal', true);
  }

  async function deleteVehicle(vehId) {
    if (!confirm("Apakah Anda yakin ingin menghapus unit kendaraan ini dari jajaran armada?")) return;
    
    try {
      const res = await fetch(`api.php?action=delete_vehicle&id=${vehId}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server", "error");
    }
  }

  // ==================== REKAP EXPORT FUNCTIONS ====================

  function exportToExcel() {
    if (globalFilteredLoansForExport.length === 0) {
      showToast("Peringatan ⚠️", "Tidak ada data peminjaman yang cocok untuk diexport!", "warning");
      return;
    }
    
    const sheetData = globalFilteredLoansForExport.map((l, idx) => ({
      'No': idx + 1,
      'Pelat Nomor': l.plate_number,
      'Kendaraan': l.vehicle_name,
      'Supir / Driver': l.driver_status,
      'KM Awal': l.initial_km,
      'KM Akhir': l.final_km !== null && l.final_km !== undefined ? l.final_km : '-',
      'Jarak Tempuh (KM)': (l.final_km !== null && l.final_km !== undefined && l.initial_km !== null && l.initial_km !== undefined) ? (l.final_km - l.initial_km) : '-',
      'Waktu Kembali': l.returned_at ? l.returned_at.substring(0, 16) : '-',
      'Catatan Pengembalian': l.return_notes || '-',
      'Peminjam (PIC)': l.pic_name,
      'NIK': l.pic_nik,
      'Divisi': l.pic_div || 'Umum',
      'Email': l.pic_email,
      'Tujuan / Keperluan': l.purpose,
      'Waktu Mulai': l.start_time,
      'Estimasi Selesai': l.end_time,
      'BBM Liter': l.fuel_total_liter && l.fuel_total_liter > 0 ? l.fuel_total_liter : '-',
      'Jenis BBM': l.fuel_types || '-',
      'Total Harga BBM': l.fuel_total_price && l.fuel_total_price > 0 ? l.fuel_total_price : '-',
      'Lokasi Isi BBM': l.fuel_locations || '-',
      'Status Approval': l.status
    }));
    
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sheetData);
    
    const colsWidth = [
      {wch: 5}, {wch: 15}, {wch: 25}, {wch: 22}, {wch: 12}, {wch: 12}, {wch: 16}, {wch: 18}, {wch: 28},
      {wch: 22}, {wch: 12}, {wch: 20}, {wch: 25}, {wch: 35}, 
      {wch: 20}, {wch: 20}, {wch: 12}, {wch: 14}, {wch: 16}, {wch: 22}, {wch: 15}
    ];
    ws['!cols'] = colsWidth;
    
    XLSX.utils.book_append_sheet(wb, ws, "Rekap Sewa SIMKEN");
    
    const fileName = `Rekap_Sewa_SIMKEN_${new Date().toISOString().slice(0,10)}.xlsx`;
    XLSX.writeFile(wb, fileName);
    showToast("Sukses Export 📊", `Berhasil mendownload Excel: ${fileName}`, "success");
  }

  function exportToPDF() {
    if (globalFilteredLoansForExport.length === 0) {
      showToast("Peringatan ⚠️", "Tidak ada data peminjaman yang cocok untuk diexport!", "warning");
      return;
    }
    
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('landscape', 'pt', 'a4');
    
    doc.setFont("Inter", "bold");
    doc.setFontSize(18);
    doc.setTextColor(19, 26, 36);
    doc.text("SISTEM INFORMASI MANAJEMEN KENDARAAN (SIMKEN)", 40, 45);
    
    doc.setFontSize(10);
    doc.setFont("Inter", "normal");
    doc.setTextColor(75, 85, 99);
    doc.text(`LAPORAN REKAPITULASI PEMINJAMAN ARMADA INTERNAL — TANGGAL CETAK: ${new Date().toLocaleDateString('id-ID')}`, 40, 65);
    
    doc.setDrawColor(203, 211, 217);
    doc.line(40, 75, doc.internal.pageSize.width - 40, 75);
    
    const headers = [['No', 'Plat', 'Kendaraan', 'Peminjam', 'Divisi', 'Supir', 'KM Awal', 'KM Akhir', 'BBM (L)', 'Total BBM', 'Tujuan', 'Mulai', 'Selesai', 'Status']];
    
    const rows = globalFilteredLoansForExport.map((l, idx) => [
      idx + 1,
      l.plate_number,
      l.vehicle_name,
      l.pic_name,
      l.pic_div || 'Umum',
      l.driver_status,
      (l.initial_km !== null && l.initial_km !== undefined) ? Number(l.initial_km).toLocaleString('id-ID') + " KM" : '-',
      (l.final_km !== null && l.final_km !== undefined) ? l.final_km.toLocaleString('id-ID') + " KM" : '-',
      (l.fuel_total_liter && l.fuel_total_liter > 0) ? l.fuel_total_liter.toLocaleString('id-ID') : '-',
      (l.fuel_total_price && l.fuel_total_price > 0) ? 'Rp ' + l.fuel_total_price.toLocaleString('id-ID') : '-',
      l.purpose,
      l.start_time.substring(0, 16),
      l.end_time.substring(0, 16),
      l.status
    ]);
    
    doc.autoTable({
      head: headers,
      body: rows,
      startY: 90,
      theme: 'grid',
      styles: { fontSize: 7, font: 'Inter', cellPadding: 5 },
      headStyles: { fillColor: [19, 26, 36], textColor: [255, 255, 255], fontStyle: 'bold' },
      columnStyles: {
        0: { cellWidth: 18 },
        1: { cellWidth: 55 },
        2: { cellWidth: 75 },
        3: { cellWidth: 70 },
        4: { cellWidth: 60 },
        5: { cellWidth: 55 },
        6: { cellWidth: 45 },
        7: { cellWidth: 45 },
        8: { cellWidth: 40 },
        9: { cellWidth: 55 },
        10: { cellWidth: 100 },
        11: { cellWidth: 70 },
        12: { cellWidth: 70 },
        13: { cellWidth: 45 }
      }
    });
    
    const fileName = `Rekap_Sewa_SIMKEN_${new Date().toISOString().slice(0,10)}.pdf`;
    doc.save(fileName);
    showToast("Sukses Export 📄", `Berhasil mendownload PDF: ${fileName}`, "success");
  }

  // Helper: Format phone standard for WhatsApp API link
  function formatPhoneForWA(phone) {
    if (!phone) return "";
    let cleaned = phone.replace(/[^0-9]/g, '');
    if (cleaned.startsWith('0')) {
      cleaned = '62' + cleaned.substring(1);
    } else if (cleaned.startsWith('8')) {
      cleaned = '62' + cleaned;
    }
    return cleaned;
  }

  // Clear All Activity Logs (BARU!)
  async function clearAllActivities() {
    if (!confirm("Apakah Anda yakin ingin membersihkan SELURUH log aktivitas dari dasbor?")) return;
    try {
      const res = await fetch('api.php?action=clear_all_activities', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast("Sukses Bersih 🗑️", data.message, "success");
        refreshData();
      } else {
        showToast("Error", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server untuk membersihkan log aktivitas", "error");
    }
  }

  // Form Submissions Handlers (100% FOOLPROOF DIRECT SUBMIT!) (GABUNG GAYAL! ✅)
  async function submitLoan(e) {
    e.preventDefault();
    const empId = document.getElementById('loan-employee-id').value;
    const empName = document.getElementById('loan-employee-search').value.trim();
    
    if (!empId) {
      showToast("Peringatan ⚠️", "Silakan ketik nama dan pilih nama peminjam yang valid dari daftar pilihan!", "warning");
      return;
    }
    
    const vehicleSelect = document.getElementById('loan-vehicle');
    const vehicleText = vehicleSelect.options[vehicleSelect.selectedIndex].text;
    const purposeText = document.getElementById('loan-purpose').value;
    const startTimeVal = document.getElementById('loan-start').value;
    const endTimeVal = document.getElementById('loan-end').value;
    
    let driverStatusVal = document.getElementById('loan-driver').value;
    if (driverStatusVal === 'Ketik Manual') {
      const customName = document.getElementById('loan-driver-name').value.trim();
      driverStatusVal = customName ? `Supir: ${customName}` : 'Bawa Sendiri';
    }
    const payload = {
      vehicle_id: vehicleSelect.value,
      employee_id: empId,
      purpose: purposeText,
      start_time: startTimeVal,
      end_time: endTimeVal,
      driver_status: driverStatusVal
    };
    
    try {
      const res = await fetch('api.php?action=request_loan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      
      if (res.ok) {
        showToast("Pengajuan Sukses ✅", "Tinggal menunggu approval dari tim GA.", "success");
        
        // Generate WhatsApp buttons
        const container = document.getElementById('wa-buttons-container');
        container.innerHTML = '';
        
        // Find division
        const emp = globalEmployees.find(item => item.id == empId);
        const peminjamDiv = emp ? (emp.division || 'Umum') : 'Umum';
        
        if (data.notifications && data.notifications.length > 0) {
          data.notifications.forEach(notif => {
            const textRaw = `Permisi Bapak ${notif.ga_name},\n\n` +
                            `Saya *${empName}* (Divisi: *${peminjamDiv}*) baru saja mengajukan peminjaman kendaraan di SIMKEN untuk:\n` +
                            `🚗 Unit: *${vehicleText.split(' - ')[0]}*\n` +
                            `🚦 Driver: *${driverStatusVal}*\n` +
                            `📈 KM Awal & Foto Kendaraan: *Diisi melalui Modul Peminjaman setelah kendaraan diambil*\n` +
                            `🎯 Keperluan: *${purposeText}*\n` +
                            `📅 Jadwal: *${startTimeVal.replace('T', ' ')}* s/d *${endTimeVal.replace('T', ' ')}*\n\n` +
                            `Mohon bantuannya untuk melakukan persetujuan (approval) ya di web https://potensibumisakti.com/simken/ 
                            Terima kasih! 🙏`;
            
            const waUrl = `https://wa.me/${formatPhoneForWA(notif.ga_phone)}?text=${encodeURIComponent(textRaw)}`;
            
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn-wa';
            btn.onclick = () => window.open(waUrl, '_blank');
            btn.innerHTML = `
              <svg width="18" height="18" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.005 5.319 5.4 0 12.045 0c3.21.001 6.232 1.253 8.513 3.535 2.28 2.281 3.53 5.305 3.527 8.514-.005 6.728-5.398 12.047-12.046 12.047-1.992-.002-3.955-.5-5.697-1.448L0 24zm6.59-4.846c1.6.95 3.498 1.45 5.438 1.451 5.64 0 10.23-4.59 10.233-10.23.002-2.73-1.062-5.3-2.997-7.238C17.329 1.2 14.76 1.15 12.05 1.15c-5.64 0-10.23 4.59-10.234 10.23-.001 2.02.531 3.99 1.542 5.73l-.997 3.63 3.73-.978zm12.115-7.143c-.328-.164-1.94-.958-2.24-1.07-.3-.11-.518-.163-.734.163-.217.327-.84.958-1.03 1.17-.19.213-.38.24-.708.075-.328-.163-1.385-.51-2.637-1.626-.975-.87-1.633-1.946-1.824-2.274-.19-.327-.02-.504.145-.668.148-.148.328-.38.492-.57.164-.19.219-.327.328-.545.11-.218.055-.408-.027-.57-.082-.164-.734-1.77-.101-1.954-.3-.172-.614-.245-.92-.218-.328.026-.856.12-1.311.53-.455.412-1.745 1.705-1.745 4.157 0 2.45 1.785 4.815 2.03 5.14.246.327 3.51 5.358 8.5 7.502 1.19.512 2.116.82 2.84 1.05.195.062.39.053.58.022.486-.072 1.94-.793 2.215-1.56.273-.765.273-1.423.19-1.56-.083-.136-.3-.218-.628-.382z"/></svg>
              Hubungi ${notif.ga_name}
            `;
            container.appendChild(btn);
          });
        }
        
        // Hide Step 1 and show Step 3 (Success + WhatsApp)
        document.getElementById('loan-step-1').classList.remove('active');
        document.getElementById('loan-step-3').classList.add('active');
        
        document.getElementById('form-loan').reset();
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      console.error("DEBUG SUBMIT ERROR:", e);
      showToast("Error", "Gagal mengirim formulir peminjaman: " + e.message, "error");
    }
  }

  async function submitMaint(e) {
    e.preventDefault();
    const payload = {
      vehicle_id: document.getElementById('maint-vehicle').value,
      workshop: document.getElementById('maint-workshop').value,
      description: document.getElementById('maint-desc').value,
      start_time: document.getElementById('maint-start').value,
      cost: document.getElementById('maint-cost').value,
    };
    
    try {
      const res = await fetch('api.php?action=schedule_maintenance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      
      if (res.ok) {
        showToast("Berhasil dikirim", data.message, "success");
        closeModal('maint-modal');
        document.getElementById('form-maint').reset();
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal mengirim formulir maintenance", "error");
    }
  }

  async function submitVehicle(e) {
    e.preventDefault();
    const editId = document.getElementById('veh-edit-id').value;
    const payload = {
      plate_number: document.getElementById('veh-plate').value,
      type: document.getElementById('veh-type').value,
      brand: document.getElementById('veh-brand').value,
      model: document.getElementById('veh-model').value,
      notes: document.getElementById('veh-notes').value,
    };
    
    const url = editId ? `api.php?action=edit_vehicle&id=${editId}` : 'api.php?action=add_vehicle';
    
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        closeModal('vehicle-modal');
        document.getElementById('form-vehicle').reset();
        document.getElementById('veh-edit-id').value = "";
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server", "error");
    }
  }

  async function submitEmployee(e) {
    e.preventDefault();
    const editId = document.getElementById('emp-edit-id').value;
    const payload = {
      name: document.getElementById('emp-name').value,
      nik: document.getElementById('emp-nik').value,
      email: document.getElementById('emp-email').value,
      division: document.getElementById('emp-div').value,
    };
    
    const url = editId ? `api.php?action=edit_employee&id=${editId}` : 'api.php?action=add_employee';
    
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      
      if (res.ok) {
        showToast("Sukses", data.message, "success");
        closeModal('employee-modal');
        document.getElementById('form-employee').reset();
        document.getElementById('emp-edit-id').value = "";
        refreshData();
      } else {
        showToast("Gagal", data.error, "error");
      }
    } catch (e) {
      showToast("Error", "Gagal menghubungi server", "error");
    }
  }

  // Initial load execution
  refreshData();
</script>
</body>
</html>