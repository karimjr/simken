<?php
// config.php - Database & SMTP Configuration for SIMKEN (Local Dev)
define('DB_HOST', 'localhost');
define('DB_NAME', 'potensib_simken');
define('DB_USER', 'potensib_pbs');
define('DB_PASS', 'arsari-group');

// 📧 KONFIGURASI EMAIL SMTP GMAIL RIIL (ASLI) (SUDAH DI-UPDATE DENGAN SANDI BARU! ✅)
// Sandi Aplikasi Google yang baru Anda buat, ditulis rapat tanpa spasi!
define('SMTP_USER', 'itpbs500@gmail.com'); 
define('SMTP_PASS', 'emitebhjhkvnteen'); // Diubah dengan Sandi Aplikasi baru Anda: 'emitebhjhkvnteen'

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => "Koneksi database gagal: " . $e->getMessage()]);
    exit;
}
