<?php
// api.php - Simplified Backend API Handler for SIMKEN (No SMTP/Emails, Direct WA Redirection)
// v1.6 (performance-optimized): loans query pakai LEFT JOIN agregat (bukan 4 correlated
// subquery per baris), dashboard counts digabung jadi 1 query, syncVehicleStatuses()
// tidak lagi dipanggil dobel (dashboard + vehicles) supaya tidak ada UPDATE ganda tiap refresh.
header('Content-Type: application/json');
// Anti-Cache Headers - mencegah browser menyimpan cache response JSON
// (root cause tampilan "terpotong" setelah approve/reject/return: browser
// menyajikan response api.php lama dari cache, bukan data terbaru dari server)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
require_once 'config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Helper: format relative time
function formatRelativeTime($dateTimeStr) {
    if (!$dateTimeStr) return '-';
    try {
        $dt = new DateTime($dateTimeStr);
        $now = new DateTime();
        
        $today = new DateTime($now->format('Y-m-d'));
        $item_day = new DateTime($dt->format('Y-m-d'));
        $diff = $today->diff($item_day);
        
        $days = $diff->days;
        if ($diff->invert) {
            $days = -$days;
        }
        
        if ($days == 0) {
            return "Hari ini, " . $dt->format('H.i');
        } elseif ($days == -1) {
            return "Kemarin, " . $dt->format('H.i');
        } elseif ($days < -1) {
            return abs($days) . " hari lalu";
        } else {
            return $dt->format('d M Y, H.i');
        }
    } catch (Exception $e) {
        return $dateTimeStr;
    }
}

// Helper: log activity
function logActivity($pdo, $vehicleId, $actionType, $picName, $description) {
    $stmt = $pdo->prepare("SELECT plate_number, brand, model FROM vehicles WHERE id = ?");
    $stmt->execute([$vehicleId]);
    $vehicle = $stmt->fetch();
    
    if ($vehicle) {
        $plate = $vehicle['plate_number'];
        $v_name = $vehicle['brand'] . " " . $vehicle['model'];
    } else {
        $plate = "-";
        $v_name = "Kendaraan Umum";
    }
    
    $stmt = $pdo->prepare("INSERT INTO activities (vehicle_id, plate_number, vehicle_name, pic_name, action_type, description, timestamp) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$vehicleId, $plate, $v_name, $picName, $actionType, $description]);
}

// Helper: Read a simple .xlsx file (first sheet) into a 0-indexed array of rows/columns.
// Pure PHP, no external library required (uses built-in ZipArchive + SimpleXML).
function readSimpleXlsx($filePath) {
    if (!class_exists('ZipArchive')) {
        throw new Exception('Ekstensi PHP "zip" tidak aktif di server. Aktifkan ekstensi php-zip untuk memakai fitur import Excel.');
    }
    $zip = new ZipArchive();
    if ($zip->open($filePath) !== true) {
        throw new Exception('Gagal membuka file. Pastikan file berformat .xlsx yang valid dan tidak rusak.');
    }

    // 1. Load shared strings (Excel stores repeated text values in a shared pool)
    $sharedStrings = [];
    $ssXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssXml !== false) {
        $ss = simplexml_load_string($ssXml);
        if ($ss !== false) {
            foreach ($ss->si as $si) {
                if (isset($si->t)) {
                    $sharedStrings[] = (string)$si->t;
                } else {
                    $text = '';
                    foreach ($si->r as $r) {
                        $text .= (string)$r->t;
                    }
                    $sharedStrings[] = $text;
                }
            }
        }
    }

    // 2. Locate the first worksheet
    $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
    if ($sheetXml === false) {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (preg_match('#^xl/worksheets/sheet\d+\.xml$#', $name)) {
                $sheetXml = $zip->getFromName($name);
                break;
            }
        }
    }
    $zip->close();

    if ($sheetXml === false) {
        throw new Exception('Tidak ditemukan data sheet di dalam file Excel.');
    }

    $sheet = simplexml_load_string($sheetXml);
    if ($sheet === false || !isset($sheet->sheetData)) {
        throw new Exception('Gagal membaca isi file Excel.');
    }

    $rows = [];
    foreach ($sheet->sheetData->row as $row) {
        $rowData = [];
        foreach ($row->c as $c) {
            $ref = (string)$c['r'];
            if (!preg_match('/^([A-Z]+)(\d+)$/', $ref, $m)) continue;
            $colLetters = $m[1];
            $colIndex = 0;
            for ($i = 0; $i < strlen($colLetters); $i++) {
                $colIndex = $colIndex * 26 + (ord($colLetters[$i]) - ord('A') + 1);
            }
            $colIndex -= 1; // 0-based

            $type = (string)$c['t'];
            $value = '';
            if ($type === 's') {
                $idx = (int)$c->v;
                $value = $sharedStrings[$idx] ?? '';
            } elseif ($type === 'inlineStr') {
                $value = isset($c->is->t) ? (string)$c->is->t : '';
            } else {
                $value = isset($c->v) ? (string)$c->v : '';
            }
            $rowData[$colIndex] = trim($value);
        }
        $rows[] = $rowData;
    }

    return $rows;
}

// Helper: Save Base64 Compressed Image to Uploads Directory
function saveBase64Image($base64Str) {
    return saveBase64ImageTo($base64Str, 'uploads/loans/', 'loan');
}

// Helper: Cari jadwal peminjaman lain (Pending/Approved) untuk kendaraan yang sama
// yang waktunya bentrok (overlap) dengan rentang waktu yang diminta.
// Loan yang statusnya Rejected/Completed tidak dihitung karena sudah tidak "menempati" jadwal.
// $excludeLoanId dipakai saat approve, supaya loan yang sedang diproses tidak membandingkan dengan dirinya sendiri.
//
// Catatan khusus: kalau ada peminjaman berstatus Approved yang jam selesainya sudah lewat
// tapi BELUM ditandai selesai/dikembalikan (telat kembali), kendaraan itu dianggap masih
// "dipegang" sampai sekarang — supaya tidak bisa di-double booking untuk waktu saat ini —
// tapi tidak menghalangi pengajuan untuk jadwal di masa depan yang jelas belum tentu bentrok.
function findScheduleConflict($pdo, $vehicleId, $startTime, $endTime, $excludeLoanId = null, $statuses = ['Pending', 'Approved']) {
    $placeholders = implode(',', array_fill(0, count($statuses), '?'));
    $sql = "SELECT id, pic_name, start_time, end_time, status FROM loans
            WHERE vehicle_id = ?
              AND status IN ($placeholders)";
    $params = array_merge([$vehicleId], $statuses);

    if ($excludeLoanId) {
        $sql .= " AND id != ?";
        $params[] = $excludeLoanId;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $candidates = $stmt->fetchAll();

    $now = time();
    $reqStart = strtotime($startTime);
    $reqEnd = strtotime($endTime);

    foreach ($candidates as $c) {
        $existStart = strtotime($c['start_time']);
        $existEnd = strtotime($c['end_time']);

        // Approved tapi telat kembali -> anggap masih dipegang sampai detik ini
        if ($c['status'] === 'Approved' && $existEnd < $now) {
            $existEnd = $now;
        }

        if ($existStart < $reqEnd && $existEnd > $reqStart) {
            return $c;
        }
    }

    return null;
}

// Helper: Save Base64 Compressed Image to a given uploads subfolder (reusable for returns/fuel receipts)
function saveBase64ImageTo($base64Str, $dir, $prefix = 'img') {
    if (!$base64Str) return null;
    
    if (preg_match('/^data:image\/(\w+);base64,/', $base64Str, $type)) {
        $base64Str = substr($base64Str, strpos($base64Str, ',') + 1);
        $ext = strtolower($type[1]);
        if ($ext === 'jpeg') $ext = 'jpg';
    } else {
        $ext = 'jpg';
    }
    
    $data = base64_decode($base64Str);
    if ($data === false) return null;
    
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    $filename = $dir . $prefix . '_' . uniqid() . '_' . rand(100, 999) . '.' . $ext;
    file_put_contents($filename, $data);
    return $filename;
}

// Helper: Map fuel type code (1-4) sent from the client dropdown to its label
function mapFuelTypeCode($code) {
    $map = [
        '1' => 'Pertalite',
        '2' => 'Pertamax',
        '3' => 'Solar',
        '4' => 'Dex',
    ];
    return $map[(string)$code] ?? null;
}

// Helper: Sinkronkan status kendaraan (Ready <-> Loaned) berdasarkan jadwal peminjaman Approved yang sedang berjalan SEKARANG.
// Kendaraan yang statusnya Maintenance tidak disentuh (itu diatur manual lewat alur bengkel).
// Ini dipanggil di endpoint yang menampilkan status kendaraan, supaya status selalu akurat
// walau peminjaman yang di-approve untuk jadwal mendatang (misal besok) baru "aktif" saat waktunya tiba.
//
// PERFORMANCE NOTE: sengaja HANYA dipanggil dari endpoint 'vehicles', tidak lagi dari
// 'dashboard'. Sebelumnya dipanggil di kedua endpoint itu, padahal frontend selalu
// memanggil fetchDashboard() lalu fetchVehicles() setiap refresh — jadi 4 UPDATE query
// ini sempat jalan dua kali beruntun tiap kali pindah tab / refresh. Cukup sekali saja,
// datanya tetap sinkron karena 'vehicles' selalu ikut di-fetch bersamaan.
function syncVehicleStatuses($pdo) {
    $now = date('Y-m-d H:i:s');
    
    // Kendaraan yang punya peminjaman Approved yang sudah mulai (start_time <= sekarang) dan
    // belum ditandai selesai/dikembalikan -> Loaned. Ini juga otomatis menutupi kasus telat kembali
    // (end_time sudah lewat tapi belum di-complete), karena yang jadi patokan "masih dipakai"
    // adalah statusnya masih Approved, bukan end_time yang direncanakan.
    $stmt = $pdo->prepare("
        UPDATE vehicles v
        SET v.status = 'Loaned'
        WHERE v.status = 'Ready'
          AND EXISTS (
              SELECT 1 FROM loans l
              WHERE l.vehicle_id = v.id
                AND l.status = 'Approved'
                AND l.start_time <= ?
          )
    ");
    $stmt->execute([$now]);
    
    // Kendaraan yang tadinya Loaned tapi sudah tidak ada peminjaman Approved yang sedang berjalan -> Ready
    $stmt = $pdo->prepare("
        UPDATE vehicles v
        SET v.status = 'Ready'
        WHERE v.status = 'Loaned'
          AND NOT EXISTS (
              SELECT 1 FROM loans l
              WHERE l.vehicle_id = v.id
                AND l.status = 'Approved'
                AND l.start_time <= ?
          )
    ");
    $stmt->execute([$now]);
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'ga_login':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $username = trim($input['username'] ?? '');
        $password = trim($input['password'] ?? '');
        
        if (!$username || !$password) {
            http_response_code(400);
            echo json_encode(['error' => 'Username dan Password wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM ga_users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['ga_logged_in'] = true;
                $_SESSION['ga_user_id'] = $user['id'];
                $_SESSION['ga_username'] = $user['username'];
                $_SESSION['ga_name'] = $user['name'];
                
                echo json_encode([
                    'message' => 'Login Berhasil!',
                    'user' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'name' => $user['name']
                    ]
                ]);
            } else {
                http_response_code(401);
                echo json_encode(['error' => 'Username atau Password salah!']);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'ga_logout':
        session_destroy();
        echo json_encode(['message' => 'Logout Berhasil!']);
        break;

    case 'get_current_ga':
        if (!isset($_SESSION['ga_logged_in']) || !$_SESSION['ga_logged_in']) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            break;
        }
        try {
            $stmt = $pdo->prepare("SELECT id, username, name, phone, email FROM ga_users WHERE id = ?");
            $stmt->execute([$_SESSION['ga_user_id']]);
            $user = $stmt->fetch();
            echo json_encode($user);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'update_ga_profile':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        if (!isset($_SESSION['ga_logged_in']) || !$_SESSION['ga_logged_in']) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $name = trim($input['name'] ?? '');
        $phone = trim($input['phone'] ?? '');
        $email = trim($input['email'] ?? '');
        
        if (!$name || !$phone || !$email) {
            http_response_code(400);
            echo json_encode(['error' => 'Nama, No HP, dan Email wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE ga_users SET name = ?, phone = ?, email = ? WHERE id = ?");
            $stmt->execute([$name, $phone, $email, $_SESSION['ga_user_id']]);
            
            $_SESSION['ga_name'] = $name;
            
            echo json_encode(['message' => 'Profil GA Anda berhasil diperbarui!']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'dashboard':
        try {
            // PERFORMANCE: syncVehicleStatuses() TIDAK dipanggil lagi di sini.
            // Endpoint 'vehicles' sudah memanggilnya dan frontend selalu fetch
            // vehicles bersamaan dengan dashboard tiap refresh, jadi cukup sekali.
            
            // PERFORMANCE: 4 query COUNT terpisah digabung jadi 1 query.
            $countsRow = $pdo->query("
                SELECT 
                    COUNT(*) as total,
                    SUM(status = 'Ready') as ready,
                    SUM(status = 'Loaned') as loaned,
                    SUM(status = 'Maintenance') as maintenance
                FROM vehicles
            ")->fetch();
            
            $total = (int)($countsRow['total'] ?? 0);
            $ready = (int)($countsRow['ready'] ?? 0);
            $loaned = (int)($countsRow['loaned'] ?? 0);
            $maint = (int)($countsRow['maintenance'] ?? 0);
            
            // Pending loans
            $pendingLoansCount = $pdo->query("SELECT COUNT(*) FROM loans WHERE status = 'Pending'")->fetchColumn();
            
            // Recent activities
            $stmt = $pdo->query("SELECT * FROM activities ORDER BY id DESC LIMIT 10");
            $activities = [];
            while ($row = $stmt->fetch()) {
                $activities[] = [
                    'id' => $row['id'],
                    'vehicle_id' => $row['vehicle_id'],
                    'plate_number' => $row['plate_number'],
                    'vehicle_name' => $row['vehicle_name'],
                    'pic_name' => $row['pic_name'],
                    'action_type' => $row['action_type'],
                    'description' => $row['description'],
                    'timestamp' => formatRelativeTime($row['timestamp'])
                ];
            }
            
            echo json_encode([
                'counts' => [
                    'total' => $total,
                    'ready' => $ready,
                    'loaned' => $loaned,
                    'maintenance' => $maint
                ],
                'pending_loans_count' => (int)$pendingLoansCount,
                'activities' => $activities
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'vehicles':
        try {
            syncVehicleStatuses($pdo);
            
            $statusFilter = $_GET['status'] ?? '';
            if ($statusFilter) {
                $stmt = $pdo->prepare("SELECT * FROM vehicles WHERE status = ? ORDER BY brand, model");
                $stmt->execute([$statusFilter]);
            } else {
                $stmt = $pdo->query("SELECT * FROM vehicles ORDER BY brand, model");
            }
            $vehicles = $stmt->fetchAll();
            echo json_encode($vehicles);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'add_vehicle':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $plate = trim(strtoupper($input['plate_number'] ?? ''));
        $brand = trim($input['brand'] ?? '');
        $model = trim($input['model'] ?? '');
        $type = trim($input['type'] ?? 'MPV');
        $notes = trim($input['notes'] ?? '');
        
        if (!$plate || !$brand || !$model) {
            http_response_code(400);
            echo json_encode(['error' => 'Pelat, Merk, dan Model kendaraan wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("INSERT INTO vehicles (plate_number, brand, model, type, status, notes) VALUES (?, ?, ?, ?, 'Ready', ?)");
            $stmt->execute([$plate, $brand, $model, $type, $notes]);
            $newId = $pdo->lastInsertId();
            
            logActivity($pdo, $newId, 'Vehicle Added', 'GA Team', "Kendaraan baru ditambahkan ke armada: $brand $model ($plate)");
            
            echo json_encode(['message' => 'Kendaraan berhasil ditambahkan!', 'id' => $newId]);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                http_response_code(400);
                echo json_encode(['error' => "Kendaraan dengan nomor pelat $plate sudah terdaftar!"]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
        }
        break;

    case 'edit_vehicle':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        $vehicleId = $_GET['id'] ?? null;
        if (!$vehicleId) {
            http_response_code(400);
            echo json_encode(['error' => 'ID kendaraan wajib disediakan!']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $plate = trim(strtoupper($input['plate_number'] ?? ''));
        $brand = trim($input['brand'] ?? '');
        $model = trim($input['model'] ?? '');
        $type = trim($input['type'] ?? 'MPV');
        $notes = trim($input['notes'] ?? '');
        
        if (!$plate || !$brand || !$model) {
            http_response_code(400);
            echo json_encode(['error' => 'Pelat, Merk, dan Model kendaraan wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE vehicles SET plate_number = ?, brand = ?, model = ?, type = ?, notes = ? WHERE id = ?");
            $stmt->execute([$plate, $brand, $model, $type, $notes, $vehicleId]);
            
            logActivity($pdo, $vehicleId, 'Vehicle Updated', 'GA Team', "Data kendaraan diperbarui: $brand $model ($plate)");
            echo json_encode(['message' => 'Data kendaraan berhasil diperbarui!']);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                http_response_code(400);
                echo json_encode(['error' => "Kendaraan dengan nomor pelat $plate sudah terdaftar!"]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
        }
        break;

    case 'delete_vehicle':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        $vehicleId = $_GET['id'] ?? null;
        if (!$vehicleId) {
            http_response_code(400);
            echo json_encode(['error' => 'ID kendaraan wajib disediakan!']);
            break;
        }
        try {
            $stmt = $pdo->prepare("SELECT plate_number, brand, model FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicleId]);
            $vehicle = $stmt->fetch();
            
            if ($vehicle) {
                $stmt = $pdo->prepare("DELETE FROM vehicles WHERE id = ?");
                $stmt->execute([$vehicleId]);
                logActivity($pdo, null, 'Vehicle Deleted', 'GA Team', "Kendaraan dihapus dari armada: {$vehicle['brand']} {$vehicle['model']} ({$vehicle['plate_number']})");
                echo json_encode(['message' => 'Kendaraan berhasil dihapus!']);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Kendaraan tidak ditemukan!']);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'employees':
        try {
            $stmt = $pdo->query("SELECT * FROM employees ORDER BY name");
            $employees = $stmt->fetchAll();
            echo json_encode($employees);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'add_employee':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        $input = json_decode(file_get_contents('php://input'), true);
        $name = trim($input['name'] ?? '');
        $nik = trim($input['nik'] ?? '');
        $email = trim($input['email'] ?? '');
        $division = trim($input['division'] ?? 'Umum');
        
        if (!$name || !$nik || !$email) {
            http_response_code(400);
            echo json_encode(['error' => 'Nama, NIK, dan Email karyawan wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("INSERT INTO employees (name, nik, email, division) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $nik, $email, $division]);
            $newId = $pdo->lastInsertId();
            
            echo json_encode(['message' => "Karyawan $name ($division) berhasil didaftarkan!", 'id' => $newId]);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                http_response_code(400);
                echo json_encode(['error' => "Karyawan dengan NIK $nik sudah terdaftar!"]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
        }
        break;

    case 'edit_employee':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        $id = $_GET['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID karyawan wajib disediakan!']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $name = trim($input['name'] ?? '');
        $nik = trim($input['nik'] ?? '');
        $email = trim($input['email'] ?? '');
        $division = trim($input['division'] ?? 'Umum');
        
        if (!$name || !$nik || !$email) {
            http_response_code(400);
            echo json_encode(['error' => 'Nama, NIK, dan Email karyawan wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE employees SET name = ?, nik = ?, email = ?, division = ? WHERE id = ?");
            $stmt->execute([$name, $nik, $email, $division, $id]);
            echo json_encode(['message' => 'Data karyawan berhasil diperbarui!']);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                http_response_code(400);
                echo json_encode(['error' => "Karyawan dengan NIK $nik sudah terdaftar!"]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
        }
        break;

    case 'delete_employee':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        $id = $_GET['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID karyawan wajib disediakan!']);
            break;
        }
        try {
            $stmt = $pdo->prepare("DELETE FROM employees WHERE id = ?");
            $stmt->execute([$id]);
            echo json_encode(['message' => 'Data karyawan berhasil dihapus!']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'bulk_delete_employees':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        if (!is_array($ids) || count($ids) === 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Tidak ada karyawan yang dipilih untuk dihapus!']);
            break;
        }
        $ids = array_values(array_unique(array_map('intval', $ids)));

        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $pdo->prepare("DELETE FROM employees WHERE id IN ($placeholders)");
            $stmt->execute($ids);
            $deleted = $stmt->rowCount();
            echo json_encode(['message' => "$deleted data karyawan berhasil dihapus sekaligus!"]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'resequence_employees':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        try {
            $stmt = $pdo->query("SELECT id FROM employees ORDER BY id ASC");
            $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $total = count($ids);

            if ($total === 0) {
                echo json_encode(['message' => 'Belum ada data karyawan untuk diurutkan.']);
                break;
            }

            $pdo->beginTransaction();
            $pdo->exec("SET FOREIGN_KEY_CHECKS=0");

            // Two-pass renumber via a temporary high offset to avoid primary-key collisions
            // while compacting gaps (e.g. #EMP-1, #EMP-2, #EMP-16 -> #EMP-1, #EMP-2, #EMP-3).
            // loans.employee_id is updated in lockstep so no peminjaman history is broken.
            $offset = 900000;
            $updEmpTemp = $pdo->prepare("UPDATE employees SET id = ? WHERE id = ?");
            $updLoanTemp = $pdo->prepare("UPDATE loans SET employee_id = ? WHERE employee_id = ?");
            foreach ($ids as $i => $oldId) {
                $tempId = $offset + $i;
                $updEmpTemp->execute([$tempId, $oldId]);
                $updLoanTemp->execute([$tempId, $oldId]);
            }
            foreach ($ids as $i => $oldId) {
                $newId = $i + 1;
                $tempId = $offset + $i;
                $updEmpTemp->execute([$newId, $tempId]);
                $updLoanTemp->execute([$newId, $tempId]);
            }

            $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
            $pdo->commit();

            // IMPORTANT: ALTER TABLE is DDL and triggers an implicit commit in MySQL.
            // It must run AFTER the explicit commit() above, never inside the transaction,
            // otherwise the later commit() fails with "There is no active transaction".
            $nextAutoIncrement = $total + 1;
            $pdo->exec("ALTER TABLE employees AUTO_INCREMENT = $nextAutoIncrement");

            echo json_encode(['message' => "ID Karyawan berhasil diurutkan ulang! Sekarang #EMP-1 s/d #EMP-$total, tanpa nomor yang terlompat."]);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
            http_response_code(500);
            echo json_encode(['error' => 'Gagal mengurutkan ulang ID: ' . $e->getMessage()]);
        }
        break;

    case 'import_employees':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode(['error' => 'File Excel tidak ditemukan atau gagal diupload!']);
            break;
        }

        $origName = $_FILES['file']['name'];
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        if ($ext !== 'xlsx') {
            http_response_code(400);
            echo json_encode(['error' => 'Format file harus .xlsx (Excel 2007+). File .xls lama atau .csv belum didukung.']);
            break;
        }

        try {
            $rows = readSimpleXlsx($_FILES['file']['tmp_name']);
            if (empty($rows)) {
                throw new Exception('File Excel kosong atau tidak terbaca.');
            }

            // Auto-detect header row & columns by name, so the template stays flexible
            // even if the user reorders/adds columns.
            $headerRowIdx = null;
            $colMap = [];
            foreach ($rows as $idx => $r) {
                $rowColMap = [];
                foreach ($r as $colIdx => $val) {
                    $norm = strtolower(trim($val));
                    if ($norm === 'nik') $rowColMap['nik'] = $colIdx;
                    if (strpos($norm, 'nama') !== false) $rowColMap['name'] = $colIdx;
                    if (strpos($norm, 'divisi') !== false || strpos($norm, 'departemen') !== false) $rowColMap['division'] = $colIdx;
                    if (strpos($norm, 'email') !== false) $rowColMap['email'] = $colIdx;
                }
                if (isset($rowColMap['nik']) && isset($rowColMap['name'])) {
                    $headerRowIdx = $idx;
                    $colMap = $rowColMap;
                    break;
                }
            }

            if ($headerRowIdx === null) {
                throw new Exception('Format kolom tidak dikenali. Gunakan file template resmi (kolom: Nama, NIK, Divisi, Email) dan jangan ubah judul kolomnya.');
            }

            $dataRows = array_slice($rows, $headerRowIdx + 1);
            $success = 0;
            $skipped = [];
            $rowNum = $headerRowIdx + 2; // Excel row number is 1-based; data starts right after header

            $checkStmt = $pdo->prepare("SELECT id FROM employees WHERE nik = ?");
            $insertStmt = $pdo->prepare("INSERT INTO employees (name, nik, email, division) VALUES (?, ?, ?, ?)");

            foreach ($dataRows as $r) {
                $name = trim($r[$colMap['name']] ?? '');
                $nik = trim($r[$colMap['nik']] ?? '');
                $email = isset($colMap['email']) ? trim($r[$colMap['email']] ?? '') : '';
                $division = isset($colMap['division']) ? trim($r[$colMap['division']] ?? '') : '';
                if (!$division) $division = 'Umum';

                if (!$name && !$nik && !$email) {
                    $rowNum++;
                    continue; // fully blank row, silently skip
                }
                if (!$name || !$nik || !$email) {
                    $skipped[] = "Baris $rowNum: data tidak lengkap (Nama/NIK/Email wajib diisi)";
                    $rowNum++;
                    continue;
                }

                $checkStmt->execute([$nik]);
                if ($checkStmt->fetch()) {
                    $skipped[] = "Baris $rowNum: NIK $nik ($name) sudah terdaftar, dilewati";
                    $rowNum++;
                    continue;
                }

                try {
                    $insertStmt->execute([$name, $nik, $email, $division]);
                    $success++;
                } catch (PDOException $ex) {
                    $skipped[] = "Baris $rowNum: gagal disimpan ($name)";
                }
                $rowNum++;
            }

            echo json_encode([
                'message' => "$success karyawan berhasil diimpor dari Excel!" . (count($skipped) > 0 ? ' (' . count($skipped) . ' baris dilewati, lihat rincian)' : ''),
                'success_count' => $success,
                'skipped' => $skipped
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'loans':
        try {
            // PERFORMANCE: sebelumnya query ini punya 4 correlated subquery ke tabel
            // fuel_fillings untuk TIAP baris loans (SUM liter, SUM harga, GROUP_CONCAT
            // jenis, GROUP_CONCAT lokasi) — artinya kalau ada 200 baris loans, tabel
            // fuel_fillings ikut di-scan sampai 800 kali. Sekarang diganti jadi satu
            // subquery teragregasi (GROUP BY loan_id) yang di-LEFT JOIN sekali saja,
            // jadi fuel_fillings cuma discan satu kali penuh berapa pun jumlah loans-nya.
            // Nama kolom hasil (fuel_total_liter, fuel_total_price, fuel_types,
            // fuel_locations) sengaja dipertahankan sama supaya kode di bawah tidak
            // perlu diubah sama sekali.
            $stmt = $pdo->query("
                SELECT l.*, v.plate_number, v.brand, v.model, v.type,
                    e.name as emp_name, e.nik as emp_nik, e.email as emp_email, e.division as emp_div,
                    COALESCE(fu.fuel_total_liter, 0) as fuel_total_liter,
                    COALESCE(fu.fuel_total_price, 0) as fuel_total_price,
                    fu.fuel_types,
                    fu.fuel_locations
                FROM loans l
                JOIN vehicles v ON l.vehicle_id = v.id
                JOIN employees e ON l.employee_id = e.id
                LEFT JOIN (
                    SELECT
                        loan_id,
                        SUM(liter_amount) as fuel_total_liter,
                        SUM(total_price) as fuel_total_price,
                        GROUP_CONCAT(DISTINCT fuel_type SEPARATOR ', ') as fuel_types,
                        GROUP_CONCAT(DISTINCT location_or_receipt SEPARATOR ', ') as fuel_locations
                    FROM fuel_fillings
                    GROUP BY loan_id
                ) fu ON fu.loan_id = l.id
                ORDER BY l.id DESC
            ");
            $loans = [];
            while ($r = $stmt->fetch()) {
                $loans[] = [
                    'id' => (int)$r['id'],
                    'vehicle_id' => (int)$r['vehicle_id'],
                    'vehicle_name' => "{$r['brand']} {$r['model']}",
                    'plate_number' => $r['plate_number'],
                    'pic_name' => $r['emp_name'],
                    'pic_nik' => $r['emp_nik'],
                    'pic_email' => $r['emp_email'],
                    'pic_div' => $r['emp_div'],
                    'purpose' => $r['purpose'],
                    'start_time' => $r['start_time'],
                    'end_time' => $r['end_time'],
                    'driver_status' => $r['driver_status'],
                    'initial_km' => (int)$r['initial_km'],
                    'photos' => $r['photos'] ? json_decode($r['photos'], true) : [],
                    'status' => $r['status'],
                    'created_at' => formatRelativeTime($r['created_at']),
                    'final_km' => $r['final_km'] !== null ? (int)$r['final_km'] : null,
                    'return_notes' => $r['return_notes'],
                    'return_photos' => $r['return_photos'] ? json_decode($r['return_photos'], true) : [],
                    'returned_at' => $r['returned_at'],
                    'fuel_total_liter' => (float)$r['fuel_total_liter'],
                    'fuel_total_price' => (int)$r['fuel_total_price'],
                    'fuel_types' => $r['fuel_types'],
                    'fuel_locations' => $r['fuel_locations']
                ];
            }
            echo json_encode($loans);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'request_loan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $vehicleId = $input['vehicle_id'] ?? null;
        $employeeId = $input['employee_id'] ?? null;
        $purpose = trim($input['purpose'] ?? '');
        $startTime = str_replace('T', ' ', $input['start_time'] ?? '');
        $endTime = str_replace('T', ' ', $input['end_time'] ?? '');
        
        $driverStatus = trim($input['driver_status'] ?? 'Bawa Sendiri');
        $initialKm = (int)($input['initial_km'] ?? 0);
        $photosInput = $input['photos'] ?? [];
        
        if (!$vehicleId || !$employeeId || !$purpose || !$startTime || !$endTime) {
            http_response_code(400);
            echo json_encode(['error' => 'Semua field peminjaman wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT name, division FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $emp = $stmt->fetch();
            
            if (!$emp) {
                http_response_code(404);
                echo json_encode(['error' => 'Karyawan tidak terdaftar!']);
                break;
            }
            
            $empName = $emp['name'];
            $empDiv = $emp['division'];
            
            $stmt = $pdo->prepare("SELECT status, brand, model, plate_number FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicleId]);
            $vehicle = $stmt->fetch();
            
            if (!$vehicle) {
                http_response_code(404);
                echo json_encode(['error' => 'Kendaraan tidak ditemukan!']);
                break;
            }
            
            if ($vehicle['status'] === 'Maintenance') {
                http_response_code(400);
                echo json_encode(['error' => "Kendaraan {$vehicle['brand']} {$vehicle['model']} sedang berada di bengkel (Maintenance)!"]);
                break;
            }
            
            $conflict = findScheduleConflict($pdo, $vehicleId, $startTime, $endTime);
            if ($conflict) {
                $conflictStart = date('d M Y, H.i', strtotime($conflict['start_time']));
                $conflictEnd = date('d M Y, H.i', strtotime($conflict['end_time']));
                http_response_code(400);
                echo json_encode(['error' => "Kendaraan {$vehicle['brand']} {$vehicle['model']} sudah dijadwalkan dipinjam oleh {$conflict['pic_name']} pada {$conflictStart} s/d {$conflictEnd}. Silakan pilih jadwal lain yang masih kosong."]);
                break;
            }
            
            $savedPaths = [];
            if (is_array($photosInput)) {
                foreach ($photosInput as $b64) {
                    $path = saveBase64Image($b64);
                    if ($path) {
                        $savedPaths[] = $path;
                    }
                }
            }
            $photosJson = count($savedPaths) > 0 ? json_encode($savedPaths) : null;
            
            $stmt = $pdo->prepare("INSERT INTO loans (vehicle_id, employee_id, pic_name, purpose, start_time, end_time, driver_status, initial_km, photos, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())");
            $stmt->execute([$vehicleId, $employeeId, $empName, $purpose, $startTime, $endTime, $driverStatus, $initialKm, $photosJson]);
            $loanId = $pdo->lastInsertId();
            
            $vFull = "{$vehicle['brand']} {$vehicle['model']}";
            logActivity($pdo, $vehicleId, 'Loan Request', $empName, "Mengajukan peminjaman $vFull ({$vehicle['plate_number']}) — $purpose");
            
            // Get GA users to notify on success screen (WA buttons)
            $stmt_ga = $pdo->query("SELECT name, phone, email FROM ga_users");
            $ga_users = $stmt_ga->fetchAll();
            
            $simulated_notifications = [];
            foreach ($ga_users as $ga) {
                $wa_msg = "Permisi Bapak *{$ga['name']}*, terdapat pengajuan peminjaman kendaraan baru di SIMKEN!\n\n" .
                          "👤 Peminjam: {$empName} (Divisi: {$empDiv})\n" .
                          "🚗 Armada  : {$vFull} ({$vehicle['plate_number']})\n" .
                          "🎯 Keperluan: {$purpose}\n" .
                          "🚦 Driver   : {$driverStatus}\n" .
                          "📈 KM Awal  : " . number_format($initialKm, 0, ',', '.') . " KM\n" .
                          "📅 Jadwal  : {$startTime} s/d {$endTime}\n\n" .
                          "Silakan login ke portal SIMKEN untuk melakukan persetujuan/approval.";
                
                $email_subject = "Pemberitahuan Peminjaman Baru SIMKEN - {$vehicle['plate_number']}";
                
                $simulated_notifications[] = [
                    'ga_name' => $ga['name'],
                    'ga_phone' => $ga['phone'],
                    'ga_email' => $ga['email'],
                    'wa_message' => $wa_msg,
                    'email_subject' => $email_subject
                ];
            }
            
            echo json_encode([
                'message' => 'Peminjaman berhasil diajukan! Menunggu persetujuan admin GA.', 
                'id' => $loanId,
                'notifications' => $simulated_notifications
            ]);
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'edit_loan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $loanId = $input['loan_id'] ?? null;
        $initialKm = isset($input['initial_km']) ? (int)$input['initial_km'] : null;
        $photosInput = $input['photos'] ?? [];

        if (!$loanId || $initialKm === null) {
            http_response_code(400);
            echo json_encode(['error' => 'Data KM awal wajib diisi!']);
            break;
        }

        try {
            $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = ?");
            $stmt->execute([$loanId]);
            $loan = $stmt->fetch();

            if (!$loan) {
                http_response_code(404);
                echo json_encode(['error' => 'Data peminjaman tidak ditemukan!']);
                break;
            }

            // Editing (by the borrower) is only allowed while the loan is still
            // Pending or Approved — once it's Completed/Rejected the record is final.
            if (!in_array($loan['status'], ['Pending', 'Approved'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Peminjaman ini sudah tidak bisa diedit karena statusnya sudah final.']);
                break;
            }

            // Each entry in $photosInput is either an existing saved path
            // (kept as-is) or a new base64 image (gets saved to disk).
            $finalPaths = [];
            if (is_array($photosInput)) {
                foreach ($photosInput as $item) {
                    if (is_string($item) && strpos($item, 'data:image') === 0) {
                        $path = saveBase64Image($item);
                        if ($path) {
                            $finalPaths[] = $path;
                        }
                    } elseif (is_string($item) && strpos($item, 'uploads/loans/') === 0) {
                        $finalPaths[] = $item;
                    }
                }
            }
            $photosJson = count($finalPaths) > 0 ? json_encode($finalPaths) : null;

            $stmt = $pdo->prepare("UPDATE loans SET initial_km = ?, photos = ? WHERE id = ?");
            $stmt->execute([$initialKm, $photosJson, $loanId]);

            logActivity($pdo, $loan['vehicle_id'], 'Loan Edited', $loan['pic_name'], "KM awal & foto kondisi peminjaman #{$loanId} diperbarui oleh peminjam ({$loan['pic_name']})");

            echo json_encode(['message' => 'KM awal & foto peminjaman berhasil diperbarui!']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'approve_loan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $loanId = $_GET['id'] ?? null;
        if (!$loanId) {
            http_response_code(400);
            echo json_encode(['error' => 'ID peminjaman wajib disediakan!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = ?");
            $stmt->execute([$loanId]);
            $loan = $stmt->fetch();
            
            if (!$loan) {
                http_response_code(404);
                echo json_encode(['error' => 'Peminjaman tidak ditemukan!']);
                break;
            }
            
            if ($loan['status'] !== 'Pending') {
                http_response_code(400);
                echo json_encode(['error' => 'Hanya pengajuan berstatus Pending yang dapat disetujui!']);
                break;
            }
            
            $vehicleId = $loan['vehicle_id'];
            
            $stmt = $pdo->prepare("SELECT status, brand, model, plate_number FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicleId]);
            $vehicle = $stmt->fetch();
            
            if (!$vehicle) {
                http_response_code(404);
                echo json_encode(['error' => 'Kendaraan tidak ditemukan!']);
                break;
            }
            
            if ($vehicle['status'] === 'Maintenance') {
                http_response_code(400);
                echo json_encode(['error' => 'Kendaraan sedang masuk bengkel (Maintenance)!']);
                break;
            }
            
            // Hanya bentrok kalau ada peminjaman lain yang SUDAH disetujui (Approved) di jadwal yang sama.
            // Pengajuan Pending lain yang jadwalnya beda tidak masalah, dan tidak menghalangi approval ini.
            $conflict = findScheduleConflict($pdo, $vehicleId, $loan['start_time'], $loan['end_time'], $loanId, ['Approved']);
            if ($conflict) {
                $conflictStart = date('d M Y, H.i', strtotime($conflict['start_time']));
                $conflictEnd = date('d M Y, H.i', strtotime($conflict['end_time']));
                http_response_code(400);
                echo json_encode(['error' => "Jadwal bentrok dengan peminjaman {$conflict['pic_name']} yang sudah disetujui pada {$conflictStart} s/d {$conflictEnd}!"]);
                break;
            }
            
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("UPDATE loans SET status = 'Approved' WHERE id = ?");
            $stmt->execute([$loanId]);
            
            // Tandai kendaraan 'Loaned' hanya jika jadwal peminjaman ini sedang berlangsung sekarang.
            // Kalau jadwalnya masih untuk nanti/besok, kendaraan tetap ditampilkan 'Ready' sampai waktunya tiba,
            // supaya pengajuan lain untuk jadwal yang berbeda (dan tidak bentrok) tetap bisa diajukan/di-approve.
            $now = date('Y-m-d H:i:s');
            if ($loan['start_time'] <= $now && $loan['end_time'] >= $now) {
                $stmt = $pdo->prepare("UPDATE vehicles SET status = 'Loaned' WHERE id = ?");
                $stmt->execute([$vehicleId]);
            }
            
            $pdo->commit();
            
            $vFull = "{$vehicle['brand']} {$vehicle['model']}";
            logActivity($pdo, $vehicleId, 'Loan Approved', $loan['pic_name'], "$vFull — peminjaman disetujui untuk kegiatan: {$loan['purpose']}");
            
            echo json_encode(['message' => 'Peminjaman disetujui, armada siap jalan!']);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'reject_loan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $loanId = $_GET['id'] ?? null;
        if (!$loanId) {
            http_response_code(400);
            echo json_encode(['error' => 'ID peminjaman wajib disediakan!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = ?");
            $stmt->execute([$loanId]);
            $loan = $stmt->fetch();
            
            if (!$loan) {
                http_response_code(404);
                echo json_encode(['error' => 'Peminjaman tidak ditemukan!']);
                break;
            }
            
            if ($loan['status'] !== 'Pending') {
                http_response_code(400);
                echo json_encode(['error' => 'Hanya pengajuan berstatus Pending yang dapat ditolak!']);
                break;
            }
            
            $stmt = $pdo->prepare("UPDATE loans SET status = 'Rejected' WHERE id = ?");
            $stmt->execute([$loanId]);
            
            $stmt = $pdo->prepare("SELECT brand, model, plate_number FROM vehicles WHERE id = ?");
            $stmt->execute([$loan['vehicle_id']]);
            $vehicle = $stmt->fetch();
            $vFull = $vehicle ? "{$vehicle['brand']} {$vehicle['model']}" : "Kendaraan";
            $plate = $vehicle ? $vehicle['plate_number'] : "";
            
            logActivity($pdo, $loan['vehicle_id'], 'Loan Rejected', $loan['pic_name'], "Peminjaman $vFull ($plate) ditolak oleh Admin");
            
            echo json_encode(['message' => 'Peminjaman ditolak.']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'complete_loan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $loanId = $_GET['id'] ?? null;
        if (!$loanId) {
            http_response_code(400);
            echo json_encode(['error' => 'ID peminjaman wajib disediakan!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = ?");
            $stmt->execute([$loanId]);
            $loan = $stmt->fetch();
            
            if (!$loan) {
                http_response_code(404);
                echo json_encode(['error' => 'Peminjaman tidak ditemukan!']);
                break;
            }
            
            if ($loan['status'] !== 'Approved') {
                http_response_code(400);
                echo json_encode(['error' => 'Hanya peminjaman aktif yang dapat diselesaikan!']);
                break;
            }
            
            $vehicleId = $loan['vehicle_id'];
            
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("UPDATE loans SET status = 'Completed' WHERE id = ?");
            $stmt->execute([$loanId]);
            
            $stmt = $pdo->prepare("UPDATE vehicles SET status = 'Ready' WHERE id = ?");
            $stmt->execute([$vehicleId]);
            
            $pdo->commit();
            
            $stmt = $pdo->prepare("SELECT brand, model, plate_number FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicleId]);
            $vehicle = $stmt->fetch();
            
            $vFull = "{$vehicle['brand']} {$vehicle['model']}";
            logActivity($pdo, $vehicleId, 'Loan Completed', $loan['pic_name'], "$vFull ({$vehicle['plate_number']}) — peminjaman selesai, kendaraan kembali dalam kondisi baik");
            
            echo json_encode(['message' => 'Peminjaman selesai, kendaraan telah kembali ke garasi!']);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    // ==================== PENGEMBALIAN KENDARAAN & PENGISIAN BBM ====================
    case 'process_return':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $loanId = $input['loan_id'] ?? null;
        $finalKm = isset($input['final_km']) && $input['final_km'] !== '' ? (int)$input['final_km'] : null;
        $returnNotes = trim($input['return_notes'] ?? '');
        $returnPhotosInput = $input['return_photos'] ?? [];
        
        // Data Pengisian BBM (opsional)
        $includeFuel = !empty($input['include_fuel']);
        $fuelLiter = isset($input['fuel_liter']) ? (float)$input['fuel_liter'] : 0;
        $fuelPrice = isset($input['fuel_price']) ? (int)$input['fuel_price'] : 0;
        $fuelTypeCode = $input['fuel_type'] ?? '';
        $fuelLocation = trim($input['fuel_location'] ?? '');
        $fuelReceiptPhotoInput = $input['fuel_receipt_photo'] ?? null;
        $fuelApproverName = trim($input['fuel_approver_name'] ?? '');
        
        if (!$loanId) {
            http_response_code(400);
            echo json_encode(['error' => 'ID peminjaman wajib disediakan!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = ?");
            $stmt->execute([$loanId]);
            $loan = $stmt->fetch();
            
            if (!$loan) {
                http_response_code(404);
                echo json_encode(['error' => 'Peminjaman tidak ditemukan!']);
                break;
            }
            
            if ($loan['status'] !== 'Approved') {
                http_response_code(400);
                echo json_encode(['error' => 'Hanya peminjaman aktif (Berjalan) yang dapat diproses pengembaliannya!']);
                break;
            }
            
            $vehicleId = $loan['vehicle_id'];
            
            if ($includeFuel) {
                if ($fuelLiter <= 0 || $fuelPrice <= 0) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Jumlah liter dan harga per liter BBM wajib diisi dengan benar!']);
                    break;
                }
                $fuelTypeLabel = mapFuelTypeCode($fuelTypeCode);
                if (!$fuelTypeLabel) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Jenis BBM tidak valid!']);
                    break;
                }
            }
            
            $savedReturnPhotos = [];
            if (is_array($returnPhotosInput)) {
                foreach ($returnPhotosInput as $b64) {
                    $path = saveBase64ImageTo($b64, 'uploads/returns/', 'return');
                    if ($path) {
                        $savedReturnPhotos[] = $path;
                    }
                }
            }
            $returnPhotosJson = count($savedReturnPhotos) > 0 ? json_encode($savedReturnPhotos) : null;
            
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("UPDATE loans SET status = 'Completed', final_km = ?, return_notes = ?, return_photos = ?, returned_at = NOW() WHERE id = ?");
            $stmt->execute([$finalKm, $returnNotes ?: null, $returnPhotosJson, $loanId]);
            
            $stmt = $pdo->prepare("UPDATE vehicles SET status = 'Ready' WHERE id = ?");
            $stmt->execute([$vehicleId]);
            
            $fuelFillingId = null;
            if ($includeFuel) {
                $totalPrice = (int) round($fuelLiter * $fuelPrice);
                $receiptPath = $fuelReceiptPhotoInput ? saveBase64ImageTo($fuelReceiptPhotoInput, 'uploads/fuel/', 'fuel') : null;
                
                $stmt = $pdo->prepare("INSERT INTO fuel_fillings (loan_id, vehicle_id, pic_name, liter_amount, price_per_liter, total_price, fuel_type, location_or_receipt, receipt_photo, approver_name, approver_signature, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NOW())");
                $stmt->execute([$loanId, $vehicleId, $loan['pic_name'], $fuelLiter, $fuelPrice, $totalPrice, $fuelTypeLabel, $fuelLocation ?: null, $receiptPath, $fuelApproverName ?: null]);
                $fuelFillingId = $pdo->lastInsertId();
            }
            
            $pdo->commit();
            
            $stmt = $pdo->prepare("SELECT brand, model, plate_number FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicleId]);
            $vehicle = $stmt->fetch();
            $vFull = "{$vehicle['brand']} {$vehicle['model']}";
            
            $desc = "$vFull ({$vehicle['plate_number']}) — dikembalikan oleh {$loan['pic_name']}";
            if ($finalKm) $desc .= ", KM akhir " . number_format($finalKm, 0, ',', '.');
            if ($includeFuel) $desc .= ", isi BBM {$fuelTypeLabel} " . number_format($fuelLiter, 1, ',', '.') . " L";
            
            logActivity($pdo, $vehicleId, 'Loan Completed', $loan['pic_name'], $desc);
            
            echo json_encode([
                'message' => 'Pengembalian kendaraan berhasil diproses!' . ($includeFuel ? ' Data pengisian BBM tersimpan.' : ''),
                'fuel_filling_id' => $fuelFillingId
            ]);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
    
    case 'fuel_fillings':
        try {
            $stmt = $pdo->query("
                SELECT f.*, v.plate_number, v.brand, v.model
                FROM fuel_fillings f
                JOIN vehicles v ON f.vehicle_id = v.id
                ORDER BY f.id DESC
            ");
            $rows = [];
            while ($r = $stmt->fetch()) {
                $rows[] = [
                    'id' => (int)$r['id'],
                    'loan_id' => $r['loan_id'] ? (int)$r['loan_id'] : null,
                    'vehicle_id' => (int)$r['vehicle_id'],
                    'vehicle_name' => "{$r['brand']} {$r['model']}",
                    'plate_number' => $r['plate_number'],
                    'pic_name' => $r['pic_name'],
                    'liter_amount' => (float)$r['liter_amount'],
                    'price_per_liter' => (int)$r['price_per_liter'],
                    'total_price' => (int)$r['total_price'],
                    'fuel_type' => $r['fuel_type'],
                    'location_or_receipt' => $r['location_or_receipt'],
                    'receipt_photo' => $r['receipt_photo'],
                    'approver_name' => $r['approver_name'],
                    'approver_signature' => $r['approver_signature'],
                    'created_at' => formatRelativeTime($r['created_at'])
                ];
            }
            echo json_encode($rows);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
    
    case 'delete_fuel_filling':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        if (!isset($_SESSION['ga_logged_in']) || !$_SESSION['ga_logged_in']) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            break;
        }
        $id = $_GET['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID data BBM wajib disediakan!']);
            break;
        }
        try {
            $stmt = $pdo->prepare("DELETE FROM fuel_fillings WHERE id = ?");
            $stmt->execute([$id]);
            echo json_encode(['message' => 'Catatan pengisian BBM berhasil dihapus!']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'maintenances':
        try {
            $stmt = $pdo->query("
                SELECT m.*, v.plate_number, v.brand, v.model, v.type 
                FROM maintenances m
                JOIN vehicles v ON m.vehicle_id = v.id
                ORDER BY m.id DESC
            ");
            $maints = [];
            while ($r = $stmt->fetch()) {
                $maints[] = [
                    'id' => (int)$r['id'],
                    'vehicle_id' => (int)$r['vehicle_id'],
                    'vehicle_name' => "{$r['brand']} {$r['model']}",
                    'plate_number' => $r['plate_number'],
                    'workshop' => $r['workshop'],
                    'description' => $r['description'],
                    'cost' => (int)$r['cost'],
                    'start_time' => formatRelativeTime($r['start_time']),
                    'end_time' => $r['end_time'] ? formatRelativeTime($r['end_time']) : '-',
                    'status' => $r['status'],
                    'created_at' => formatRelativeTime($r['created_at'])
                ];
            }
            echo json_encode($maints);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'schedule_maintenance':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $vehicleId = $input['vehicle_id'] ?? null;
        $workshop = trim($input['workshop'] ?? '');
        $description = trim($input['description'] ?? '');
        $cost = (int)($input['cost'] ?? 0);
        $startTime = str_replace('T', ' ', $input['start_time'] ?? '');
        
        if (!$vehicleId || !$workshop || !$description || !$startTime) {
            http_response_code(400);
            echo json_encode(['error' => 'Semua field perawatan wajib diisi!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT status, brand, model, plate_number FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicleId]);
            $vehicle = $stmt->fetch();
            
            if (!$vehicle) {
                http_response_code(404);
                echo json_encode(['error' => 'Kendaraan tidak ditemukan!']);
                break;
            }
            
            if ($vehicle['status'] === 'Maintenance') {
                http_response_code(400);
                echo json_encode(['error' => "Kendaraan {$vehicle['brand']} {$vehicle['model']} sudah berada di bengkel!"]);
                break;
            }
            
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("INSERT INTO maintenances (vehicle_id, workshop, description, cost, start_time, status, created_at) VALUES (?, ?, ?, ?, ?, 'Ongoing', NOW())");
            $stmt->execute([$vehicleId, $workshop, $description, $cost, $startTime]);
            $maintId = $pdo->lastInsertId();
            
            $stmt = $pdo->prepare("UPDATE vehicles SET status = 'Maintenance' WHERE id = ?");
            $stmt->execute([$vehicleId]);
            
            $pdo->commit();
            
            $vFull = "{$vehicle['brand']} {$vehicle['model']}";
            logActivity($pdo, $vehicleId, 'Maintenance Started', $workshop, "$vFull ({$vehicle['plate_number']}) — dikirim ke bengkel untuk perawatan: $description");
            
            echo json_encode(['message' => 'Kendaraan berhasil dikirim ke bengkel perawatan!', 'id' => $maintId]);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'complete_maintenance':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        
        $maintId = $_GET['id'] ?? null;
        if (!$maintId) {
            http_response_code(400);
            echo json_encode(['error' => 'ID perawatan wajib disediakan!']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM maintenances WHERE id = ?");
            $stmt->execute([$maintId]);
            $maint = $stmt->fetch();
            
            if (!$maint) {
                http_response_code(404);
                echo json_encode(['error' => 'Perawatan tidak ditemukan!']);
                break;
            }
            
            if ($maint['status'] !== 'Ongoing') {
                http_response_code(400);
                echo json_encode(['error' => 'Perawatan sudah diselesaikan sebelumnya!']);
                break;
            }
            
            $vehicleId = $maint['vehicle_id'];
            
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("UPDATE maintenances SET status = 'Completed', end_time = NOW() WHERE id = ?");
            $stmt->execute([$maintId]);
            
            $stmt = $pdo->prepare("UPDATE vehicles SET status = 'Ready' WHERE id = ?");
            $stmt->execute([$vehicleId]);
            
            $pdo->commit();
            
            $stmt = $pdo->prepare("SELECT brand, model, plate_number FROM vehicles WHERE id = ?");
            $stmt->execute([$vehicleId]);
            $vehicle = $stmt->fetch();
            
            $vFull = "{$vehicle['brand']} {$vehicle['model']}";
            logActivity($pdo, $vehicleId, 'Maintenance Completed', $maint['workshop'], "$vFull ({$vehicle['plate_number']}) — servis di {$maint['workshop']} selesai, kendaraan kembali siap pakai");
            
            echo json_encode(['message' => 'Perawatan selesai, kendaraan kembali masuk dalam jajaran armada siap pakai!']);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'delete_loan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        if (!isset($_SESSION['ga_logged_in']) || !$_SESSION['ga_logged_in']) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            break;
        }
        $id = $_GET['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID peminjaman wajib disediakan!']);
            break;
        }
        try {
            $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = ?");
            $stmt->execute([$id]);
            $loan = $stmt->fetch();
            
            if ($loan) {
                $pdo->beginTransaction();
                
                if ($loan['status'] === 'Approved' || $loan['status'] === 'Pending') {
                    $stmt = $pdo->prepare("UPDATE vehicles SET status = 'Ready' WHERE id = ?");
                    $stmt->execute([$loan['vehicle_id']]);
                }
                
                $stmt = $pdo->prepare("DELETE FROM loans WHERE id = ?");
                $stmt->execute([$id]);
                
                $pdo->commit();
                
                logActivity($pdo, $loan['vehicle_id'], 'Loan Deleted', 'GA Team', "Menghapus catatan peminjaman ID #{$id} ({$loan['pic_name']})");
                echo json_encode(['message' => 'Catatan peminjaman berhasil dihapus!']);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Catatan peminjaman tidak ditemukan!']);
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'delete_maintenance':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        if (!isset($_SESSION['ga_logged_in']) || !$_SESSION['ga_logged_in']) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            break;
        }
        $id = $_GET['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID perawatan wajib disediakan!']);
            break;
        }
        try {
            $stmt = $pdo->prepare("SELECT * FROM maintenances WHERE id = ?");
            $stmt->execute([$id]);
            $maint = $stmt->fetch();
            
            if ($maint) {
                $pdo->beginTransaction();
                
                if ($maint['status'] === 'Ongoing') {
                    $stmt = $pdo->prepare("UPDATE vehicles SET status = 'Ready' WHERE id = ?");
                    $stmt->execute([$maint['vehicle_id']]);
                }
                
                $stmt = $pdo->prepare("DELETE FROM maintenances WHERE id = ?");
                $stmt->execute([$id]);
                
                $pdo->commit();
                
                logActivity($pdo, $maint['vehicle_id'], 'Maintenance Deleted', 'GA Team', "Menghapus catatan perawatan ID #{$id} di {$maint['workshop']}");
                echo json_encode(['message' => 'Catatan perawatan berhasil dihapus!']);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Catatan perawatan tidak ditemukan!']);
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'delete_activity':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        if (!isset($_SESSION['ga_logged_in']) || !$_SESSION['ga_logged_in']) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            break;
        }
        $id = $_GET['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID aktivitas wajib disediakan!']);
            break;
        }
        try {
            $stmt = $pdo->prepare("DELETE FROM activities WHERE id = ?");
            $stmt->execute([$id]);
            echo json_encode(['message' => 'Log aktivitas berhasil dihapus!']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'clear_all_activities':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            break;
        }
        if (!isset($_SESSION['ga_logged_in']) || !$_SESSION['ga_logged_in']) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            break;
        }
        try {
            $pdo->query("DELETE FROM activities");
            logActivity($pdo, null, 'Activities Cleared', $_SESSION['ga_name'] ?? 'GA Team', "Membersihkan seluruh log aktivitas terbaru dari dasbor");
            echo json_encode(['message' => 'Seluruh log aktivitas berhasil dibersihkan!']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    default:
        http_response_code(404);
        echo json_encode(['error' => 'Action Not Found']);
        break;
}